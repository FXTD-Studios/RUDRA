> **1 Nov 2026, 1.0.3:** public packages carry no model weights (1.0.0–1.0.1
> bundled the non-commercial `sdr2hdr_image_v8`; `tools/check_package_weights.py`
> now refuses that). RUDRA ACES 2 is labelled **preview** until a gate report
> naming its checkpoint is committed (`tools/model_provenance.py`). The shipped
> model is tested in CI by `.github/workflows/shipped_model.yml`. Licence and
> status of every model: [MODELS.md](MODELS.md).

# RUDRA — Training & Research Status

> **1.0 release plan, 29 Oct 2026 (supersedes the 12 Oct steps):** 1.0 ships
> on the analytic reconstruction with the artist in the loop, for Windows x64,
> code under Apache 2.0. The learned ACES 2.0 model is an optional "preview"
> download (it fails its 0 EV grading check: .121 against .0604), loaded by the
> app when installed. The app is feature-complete at 1.0.0 RC 2 (Simple workspace,
> tips, model downloads, About, ACES delivery). What is left, in order:
> [archive/docs/RELEASE_V1.md](../archive/docs/RELEASE_V1.md) "The plan from 29 Oct 2026".

> **Resume point:** read [CURRENT_HANDOFF](../archive/docs/CURRENT_HANDOFF.md) before
> continuing in another model/session. Frozen-checkpoint diagnosis and the
> push-baseline A/B are complete; the current next step is the one at the top
> of CURRENT_HANDOFF.

> **Production roadmap audit, 13 Oct 2026:** local v10 completed 20k steps;
> its clip-first gate **FAIL** was reproduced from existing CSVs, also under
> supplemental scene bootstrap. Earlier "prepared, not run" entries below are
> historical. All 728 real v10 validation rows appeared in v8/v9 training.
> Current weights remain research-only. Master roadmap and current execution:
> [PRODUCTION_PROGRESS](../archive/docs/PRODUCTION_PROGRESS.md),
> [audit](ai/RUDRA_EXECUTION_AUDIT.md).

> **Internal scratch pilot update, 14 Oct 2026:** the approved paired
> pre-clamp preservation experiment completed 200 steps per arm within budget.
> Pushed crushed-region error improved, but real PU21 and clipped highlights
> worsened; neither checkpoint is promoted. See the
> [verified result](ai/PRESERVATION_AB_RESULT.md). The analytic default
> and the internal-only licensing restriction remain.

> **Region-focus pilot, 14 Oct 2026:** both approved 200-step arms completed
> within budget. Highlights improved, but real PU21 and pushed crushed scores
> worsened; neither is promoted. Matched control inputs also exposed numerical
> repeatability limits. [Result and next action](ai/REGION_FOCUS_RESULT.md).

> **Deterministic repeatability, 14 Oct 2026:** the revised pair completed
> 200 steps per arm with exact matching inputs, training records, final model
> tensors and benchmark reports. Independent verification passed; combined
> post-preflight time 18.19 min. Quality still fails the analytic baseline
> (real PU21 -1.29023 dB); no promotion or release clearance.
> [Verified result](ai/REPEATABILITY_MARGIN_RESULT.md).

> **Updated 12 Oct 2026** (the newest entries are dated; the table is from 7 Oct). The snapshot below the line dates from 22 Aug and is
> still accurate for what it covers. Read this section first: the repository
> holds **five separate lines of work** that share a name, and "is RUDRA
> finished?" has a different answer for each.
>
> | line | what it is | state |
> |---|---|---|
> | **A. Production decoders** | distilled log-space VAE decoders, 7 backbones, ComfyUI node | **paused (23 Sep 2026)** — complete and measured; out of product scope, not maintained |
> | **B. Research pipeline (Stages 1-3)** | descriptor + FiLM + DR-gated LoRA + DRE cross-attention, the *original paper's core thesis* | **paused (23 Sep 2026)** — Stage 3 never trained; latent-specific, out of scope |
> | **C. Direct SDR-to-HDR image model** | `rudra/sdr2hdr.py`, v5, RUDRA Studio, the delivery path | **measured and written up** |
> | **D. Temporal (v02)** | rendered camera-move corpus, clip metric, the oracle gate | **CLOSED.** Exact poses +0.60 JOD, RAFT +0.34, DIS −0.07, against a +0.5 threshold fixed in advance. Nothing a plate can supply clears it; no temporal model trained, and that is the result |
>
> | **F. Native desktop app** | `native/`, C++20 / Qt 6 / QRhi / LibTorch + ONNX Runtime, no Python at runtime | **Phase 0 closed 23 Sep 2026: GO on Windows**, macOS conditional (below). **Phase 1: steps 1 to 10 of 11 done 24 Sep**, step 11 (CI on three OSes) waiting on its first run. **Phase 2** (the QRhi viewer): done on Linux and Windows but for the backend matrix. **Phase 3** (the Qt UI): steps 1 to 11 done 24 Sep, the exit scripted and passing on Linux; the Windows run and the by-hand pass are open (below). **Phase 4** (video delivery): steps 1 to 11 done 24 Sep, the exit scripted (`NATIVE_PHASE4_EXIT.ps1`) and passing on Linux; the Windows run is open (below) |
>
> | **E. Corpus programme (v4b, v4c)** | 0 EV re-ingest on `G:\datasets`, gate 3b, the retrain that tests "corpus content was the constraint"; v4c adds the mixed-curve render and the curve head | **CLOSED 7 Oct 2026.** v4b, v4c and v7 (real SDR added, source-curve input) all fail every gate, v7 at 0 of 287 on held-out real frames. Nothing promoted; `sdr2hdr_shadow_v1.pt` stays the optional model. Post-mortem pending: `sweep_val_checkpoints.py`, `bench_by_curve.py` |
> | **G. Model research** | direct regression, real-SDR-first, one bounded attempt after 1.0 | **opened 7 Oct 2026, blocks nothing** (kill rule in the release definition) |
>
> **Release definition (re-scoped 7 Oct 2026; the 24 Sep definition is kept below it).**
> The learned residual is no longer a release blocker. Four models (v4b, v4c, v7,
> shadow_v1) across rendered, out-of-generator and real SDR, and none beats the
> analytic inverse it rides on; v7, trained on 1,830 real pairs, is −4.13 dB on
> all 287 held-out Meridian frames. The one external comparison (HDRTVDM on
> HDRTV1K, +14.66 dB) says the residual-on-inverse design is the limit, not the
> corpus or the label. RUDRA 1.0 ships on the **analytic inverse with the artist
> in the loop** (curve picker, three-click calibration, live peak/knee/region EV,
> reference match, invented-pixel map, DoVi/HDR10+ delivery). `shadow_v1` ships
> as an **optional** model with its measured numbers, never as the default path
> of a master. The model moves to a research track (line G) that blocks nothing.
>
> | # | condition | pass when | status |
> |---|---|---|---|
> | R1 | the inverse path, every bench | its own PU21/CVVDP on `aces`, `oog`, `mix`, `real` published as the floor | measured: 49.00 / 9.77, 26.44 / 8.08, 25.54 / 8.11, 21.69 / 6.42 |
> | R2 | the artist controls (roadmap 3.1 to 3.4) | each control under one frame of latency at 4K, scripted exit passing on Windows | met: 1.08-1.33 ms at 4K on four backends, gated (7 Oct); phase 3 exit and the by-hand pass (9 Oct); re-run on the release candidate |
> | R3 | external comparison (roadmap 2.2, 2.3) | the frozen set through every external method, a table published whatever it says | open-source half in (12-13 Oct, docs/RESULTS.md): on real SDR (Meridian, HDRTV1K) Source = BT.1886, now the default, is +14.0 / +4.2 dB and +2.3 / +2.1 JOD over the ACES inverse and level with BT.2408; v8 level with the inverse, HDRTVDM below |
> | R4 | the native app's open items (README, "Still open") | macOS inference and HDR output, signing, by-hand workflow on Windows, budgets per backend | open |
> | R5 | optional model | the optional model listed with its measured deltas vs the inverse; any model that beats the inverse on `real` with CI excluding zero may join it | `sdr2hdr_image_v8` listed (9 Oct; shadow_v1 retired) |
>
> **Line G, model research (opened 7 Oct 2026, blocks nothing).** One bounded
> attempt, after 1.0: direct regression (SDR in, HDR out, no inverse residual),
> real-SDR-first (Netflix + HDRTV1K), `--eval-batches 0`, selected on full-val
> real rows, benched on Meridian and HDRTV1K test against HDRTVDM. Kill rule,
> written now: stop if the first full-val eval is not above the inverse on real
> rows. The v7 post-mortem (`sweep_val_checkpoints.py`, `bench_by_curve.py`)
> closes line E first.
>
> **The 24 Sep definition, for the record (all of it failed):**
>
> | # | condition | bench | pass when | status |
> |---|---|---|---|---|
> | 1 | clean, well-graded SDR | `aces`, paper 429 clean | not worse than the analytic inverse by more than 0.1 dB / 0.02 JOD | FAIL (v4b −8.09 dB, v4c −21.9 dB, v7 −19.2 dB curve given / −24.1 blind; bf16 check closed 25 Sep, fp32 within 0.04 dB) |
> | 2 | unknown curve + codec | `oog`, `mix` | both metrics above the inverse, CI excluding zero (N3) | FAIL (v4c +1.33 dB but −0.126 JOD; v7 −1.2 dB / −0.82 JOD oog, −2.7 dB / −0.59 JOD mix, −4.1 dB / −0.33 JOD real) |
> | 3 | degraded input | paper 429 hard | at least v5's +1.43 dB / +0.44 JOD, with row 1 held | not run |
> | 4 | clipped highlights | `measure_clipping.py --score`, 0/+1/+2 EV | error in stops on clipped pixels below the inverse's, CI excluding zero | not run |
> | 5 | video | v4b/v4c test clips, clip-mode CVVDP + flicker | clip JOD ≥ per-frame JOD on every test clip (N5) | flicker measured on 5 real clips, 11 Oct (docs/TEMPORAL_RESULTS.md): the holds cut the model's fire flicker 72-80 %; clip-mode CVVDP against the masters, analytic (12 Oct): held >= each frame on 4 clips, level on the 5th (-0.003 JOD); v8 flickers a third to a half as much as shadow_v1 |
> | 6 | commercial weights | `oog`, `mix` | `rudra-studio` within 0.3 dB / 0.03 JOD of the research model (N7) | not trained |
> | 7 | external comparison | N4 set: external SDR→HDR baselines | a table published whatever it says | not run |
>
> Rows 1, 2 and 6 were scored by `training/cp7_verdicts.py`. No model passed row 1 or 2.

> **7 Oct 2026 — v7 (roadmap 1.4, source-curve model on the mixed v4c + Netflix manifest) scored; every N8 gate fails.**
> 50k steps from scratch, `best.pt` = step 3,000, bench at step 3,000 in bf16. Against the analytic
> inverse: `aces` −19.21 dB [−20.15, −18.28] / −0.965 JOD with the curve given, −21.64 dB blind;
> `oog` −1.17 dB / −0.820 JOD (hable given), −1.08 / −0.666 blind, i.e. −2.41 dB under v4c blind;
> `mix` −2.67 dB / −0.590 JOD with each frame's own curve, −1.88 / −0.459 blind. The true curve
> helps only on ACES. **Real SDR (Netflix Meridian, 287 held-out frames, blind): −4.13 dB
> [−4.22, −4.02] / −0.328 JOD, 0 of 287 wins.** The model trained on 1,830 real pairs is worse than
> the analytic inverse on every real frame it was meant to fix. `reports\logs\cp_results_v7.json`. Two measurement defects found on the way, both fixed:
> the bench stage resumed on a half-written export tree (aces/v7_unknown scored on 366 of 537
> frames; the script now resumes on `export_<tree>.json`), and every best.pt from v4 to v7 was
> selected on 8 × 4 = 32 val records (`--eval-batches 0` now scores the whole split, with gains
> split real vs rendered). The training curve peaked at step 1,500 and decayed for 48k steps while
> train loss fell; whether that is overfitting or the 32-record slice is what
> `training/sweep_val_checkpoints.py` answers. `shadow_v1` stays the default.
>
> **13 Oct 2026 — v10 prepared, not run (line G; archive/docs/MODEL_PLAN_V10.md).** What v4 to v9 got wrong, fixed in
> the training: (1) the residual rode on the ACES inverse, while on real SDR the BT.1886 inverse alone is +14 dB
> over it (R3) and is 1.0's default: `--baseline-source` puts it on the Source picker's curve
> (`rudra/source_baseline.py`, the app's 256 knots, held to native to 1e-5; BT.1886 for real and degraded samples,
> a rendered sample's own curve, half of those on BT.1886 anyway, the exposure push on ACES); (2) crushed blacks:
> `--crushed-hold` charges any change there; (3) the real val was an animation: `pipeline/build_v10_manifest.py`
> holds out live-action shots of Nocturne and Sparks, Cosmos Laundromat to train; (4) best.pt was chosen on crops
> in log-PSNR: `--best-metric bench_gain` (`training/bench_val.py`) scores full frames as the gate does (PU21 on
> real and rendered val, the clipped error at +1/+2 EV, the crushed error) against the picker's baseline. Gate
> written first, `training/cp10_verdicts.py`: real above the BT.1886 baseline (PU21 and CVVDP CIs above zero),
> aces/oog/mix not worse, clip rows above the CLIP FILL at +0/+1/+2 EV, crushed not worse anywhere.
> `export_bench_pairs.py --baseline-curve / --picker-baseline` writes the trees. `archive/scripts/run_v10_2026_10_13.ps1`
> (smoke, train 20k from v9 step 20,000, bench; -ClipOnly first). Tests: `tests/test_v10_2026_10_13.py` (8),
> and an end-to-end CPU run on a synthetic corpus (manifest, 30 steps with bench selection, export with the
> picker tree, region scoring). If v10 passes, the app needs the tile graph to take the picker's knots and a
> re-run of inference on a picker change (archive/docs/MODEL_PLAN_V10.md).
>
> **13 Oct 2026, late night — the anchor follows the Source picker; the clip fill ships on (line F, R3).**
> The master's anchor (on by default) put every pixel below its knee on the sRGB reading of its code at
> 203 nits whatever the picker said: an anchored BT.1886 master was the sRGB one below the knee, and the
> calibration and the reference were undone there (R3 scored the unanchored inverse, so the shipped master
> was not the scored one). `core/composite anchor_target_knots`: per 8-bit code, log2 of the picker's curve
> with its calibration or reference (0 EV, no CurveHead) over the sRGB reading; empty for unknown/aces with
> neither, so every golden is unchanged. Taken by `anchor_to_sdr` (master), `anchor_hold` and `render_view`
> (the view and the measure), and composite.frag (`anchor[64]`, `frame.w`; the UBO grows by 1 KB).
> Tests: `tests/test_anchor_target.cpp` (5: BT.1886 is its own display reading, the anchored analytic master
> equals the unanchored one below the knee for bt1886/hable/clip, a calibrated code keeps 60 nits, the view's
> hold is 1); parity view case "anchored BT.1886 1000". Linux: core 249/249, ORT 260/260, app build 305/305;
> qsb bakes all three shaders; render/ needs the Windows build (Gate B). Clip fill decision: ships on at
> glow 0.5, the held-out optimum of its one knob over +0..+2 EV (0.412 stops vs 0.578 flat, 0.568 no dome);
> the +0 EV and fireworks losses are release notes and roadmap 4.2 (archive/docs/RELEASE_V1.md).
>
> **13 Oct 2026, night — v9 at step 20,000 on the clip benches (line G; roadmap 4.2).** `best.pt` was
> selected on an unpushed val split and stayed at step 0 (v8's weights: same crushed rows to the digit), so
> `step_0020000.pt` was benched as `v9s20` (`run_v9_2026_10_12.ps1 -Stage bench -Checkpoint ... -ClipOnly`).
> Inside clipped pixels, 287 Meridian frames, error in stops, positive = candidate better, 95 % CI:
> | | +0 EV | +1 EV | +2 EV |
> |---|---|---|---|
> | clip fill vs the flat inverse | -0.258 [-0.293, -0.222] | **+0.307** [+0.286, +0.326] | **+0.338** [+0.305, +0.366] |
> | v9s20 vs the clip fill (the gate) | **+0.116** [+0.052, +0.175] PASS | -0.054 [-0.112, -0.002] FAIL | -0.066 [-0.125, -0.011] FAIL |
> | v8 vs the flat inverse (9 Oct) | -0.359 | -0.015 | +0.002 |
> The exposure push taught the model the clip (about +0.25 stop over the flat inverse at +1/+2, where v8
> tied), but not past the analytic fill, and at +0 EV it is still below the flat inverse (~-0.14). Crushed
> pixels: 1.59 to 1.63 stops worse than the inverse, 0/287 wins (v8 1.75 to 2.38). **v9 fails the gate on
> the clip rows alone**, so real/aces/oog/mix were not benched; the clip fill stays the default and v8 the
> optional model. Open for 1.0: the fill's +0 EV overshoot (v9 shows a smaller dome is better there).
>
> **13 Oct 2026, later — interactive exposure (line F).** A master exposure in stops (-3 to +3):
> `CompositeParams::exposure_ev` / `MasterRequest::exposure_ev` / `GradeSnapshot::exposure_ev`. Part of the
> grade: the composite multiplies by 2^ev before the Region EV bands (which read the exposed nits) and the
> grade gain includes it, so the view's anchor scales its target and keeps the offset; the master applies it
> in `apply_region_ev` after the anchor; the shader reads `frame.z`. 0 is bit for bit (every golden
> unchanged). Reconstruct card slider (0.05 EV steps, one undo entry per drag, double-click resets),
> Reconstruct > Exposure up / down a third of a stop (Ctrl+Shift+Up / Down), reset (Ctrl+Shift+0), Reset
> reconstruction clears it; projects (`exposure_ev`, older projects 0), request JSON and sidecar
> (`exposure_ev`, only when set), EXR `rudra:exposureEV`. Tests: `tests/test_exposure.cpp` (7), the app's
> controls test, two `rudra-gpu-parity` cases. Core 244/244, ORT 253/253, app 56/56.
>
> **13 Oct 2026 — BT.1886 is the default source (line F; release row R3).** The R3 run showed the ACES
> inverse far below plain BT.2408 placement on real SDR, so the Source picker gained BT.1886
> (`core/source_curve`, `SourceCurve::Bt1886`, id `bt1886`): inverse `oetf709(y)^2.4`, the BT.709 video's
> code to the power 2.4, white at 1.0 (203 nits), exact for RUDRA's reading of BT.709 video (the inverse
> OETF); the knots ride the existing 256-knot path (composite, shader, master, parity: a new
> `rudra-gpu-parity` case). `GradeSnapshot::source` starts on `kDefaultSource` = `bt1886`; projects and
> requests that name none stay `unknown` (the ACES inverse), so saved projects, CLI requests and goldens
> reproduce; the page-parity tests set `unknown` (the page has no picker). Menu: Reconstruct > Source >
> BT.1886. Scored as R1: Meridian 35.61 dB / 8.722 JOD (+13.96 / +2.28 over the ACES inverse; BT.2408 on
> the true BT.709 codes +14.24 / +2.29), HDRTV1K test at 720p (`compare_market.py pairs`, 117 frames) +4.16
> / +2.11 (BT.2408 +4.31 / +2.04). The same curve on the sRGB code was measured and not shipped (-8 dB on
> Meridian). The v4b rendered frames still favour the ACES inverse by construction. The 12 Oct Meridian
> rows for BT.2408 and HDRTVDM were re-run on the true BT.709 codes (the external input was sRGB-coded):
> BT.2408 +5.96 -> +14.24 dB, HDRTVDM -0.41 -> -1.38 JOD. Not measured yet: the clip fill over BT.1886.
> Also: AppAnalytic.TheDefaultRunsNoModelAndSaysSo turns the clip fill off (since c4a6ecf the analytic
> fields fill clipped pixels, so they are not all zero). Tests: core 237/237, ORT 246/246, app 56/56.
>
> **12 Oct 2026 — toward 1.0 (line F; archive/docs/RELEASE_V1.md).** R3's open-source half
> (`training/compare_market.py`, the frozen set through RUDRA, BT.2408, HDRTVDM; scored as R1, the
> scorer reproducing R1's Meridian baseline to the digit): on real SDR the default ACES inverse is
> below the plain BT.2408 mapping by 5.96 dB / 2.04 JOD and below Source = Rec.709 by 1.70 / 1.33, so
> the default for SDR of unknown curve is a decision before 1.0 (the rendered v4b frames favour the
> inverse by construction). The clip fill, scored the same way: Meridian unchanged, v4b stills +0.53 dB and
> 0.14 stops better inside clipped pixels, v4b clip frames -3.09 dB / -0.22 JOD and 0.36 stops worse there. HDR10+ is in the shipped
> encoders (gyan.dev 7.1.1 full; Homebrew's 10-bit x265). `rudra batch` runs the app's `grade` jobs
> through rudra-native. Clip-mode CVVDP on the real clips (row 5). The release workflow publishes
> v1.0.0 as a release; `archive/scripts/release_v1_rc.ps1` makes each candidate.
>
> **12 Oct 2026 — the clip fill: clipped highlights in the analytic reconstruction (lines F and G).**
> `core/clip_fill.{hpp,cpp}`: where the SDR clipped, the inverse left one flat ceiling (every code at or
> above 0.995, ~1,276 nits at 0 EV). Now, from the SDR alone: (1) a channel that clipped while the others
> did not is estimated from them and the chroma of the clean pixels around it (a smooth push-pull fill),
> never below its ceiling; (2) a fully clipped region gets log2 luminance filled from its edge plus a
> dome whose slope at the edge is half the glow's outside it (`glow_scale` 0.5), capped at +1.5 EV for a
> region over 0.5 % of the frame and at 4,000 nits for a smaller one, hue from the edge; (3) a peak in
> nits per region from the artist (`ClipOverride`). It reaches the composite as Fields (a residual and a
> highlight mask of 1 where it changes anything), so the CPU composite, the GPU shader, masters and movie
> exports take it unchanged; no shader edit. `analytic_fields_for(sdr, MasterRequest)` is what every
> analytic path calls; `MasterRequest::clip_fill` (default on) and `clip_peaks` in the JSON, the EXR
> (`rudra:clipFill`) and the sidecar (`clip_fill`); `GradeSnapshot::clip_fill/clip_peaks` undone with the
> grade and kept in projects; Reconstruct > Fill clipped highlights / Set the peak of a clipped region… /
> Clear clipped peaks. `rudra-native bench-clip-fill <bench>` writes it as a bench tree.
> **Measured inside clipped pixels** (cp8_clip_ev0/1/2, 287 Meridian frames, `score_regions.py`'s
> measure; error in stops, lower is better; glow_scale picked on scenes 1–3, reported on 4–7):
> | | +0 EV | +1 EV | +2 EV |
> |---|---|---|---|
> | flat inverse, scenes 1–3 / 4–7 | 0.172 / 0.131 | 0.628 / 0.583 | 0.790 / 1.019 |
> | clip fill (default), scenes 1–3 / 4–7 | 0.598 / 0.217 | 0.274 / 0.321 | 0.435 / 0.698 |
> | v8 (all scenes, 9 Oct) | worse than the inverse by 0.36 | ties | ties |
> The fill halves the error at +1 and +2 EV and **loses at +0 EV** (truth there is only ~0.2 stop above
> the ceiling; any dome overshoots). No dome at all ties at +0 and gains little elsewhere (0.57/0.99 at
> +1/+2). Real Meridian SDR does not clip (3e-5 % of pixels), so the fill is for over-exposed and
> consumer/generated SDR. Cost: ~1.3 s for a 4K frame with 27 % clipped on 2 cores (fill only near the
> clip, multithreaded); frames that do not reach code 0.97 cost one pass. Tests: `ClipFill.*` (8),
> core suites otherwise unchanged. Not done: the Studio and the Python `rudra` CLI have no fill; movie
> frames are Rec.2020 codes when the fill runs, so a channel clipped in 709 reads as partly clipped.
> **v9 prepared, not run** (line G): `--exposure-push` re-renders half the samples at +0..+2 EV
> (the benches' own render, target x 2^E) so clipped pixels are common at 0 EV;
> `archive/scripts/run_v9_2026_10_12.ps1` (fine-tune from v8, 20k steps); its clip rows must beat the CLIP FILL,
> `cp8_verdicts.py --clip-against clipfill`. `tests/test_v9_clip_2026_10_12.py`.
>
> **11 Oct 2026, night — the static hold in playback (line F).** `shaders/hold.frag` runs
> `ShadowSmoother::hold_pixels` in the viewer after the composite: MRT into the model target and a state
> target (luma code, largest code, held gain, HDR Y), the state ping-ponging; a re-render of the same frame
> (a slider) reads the same state, so it does not step the hold. `PlaybackHold::pixel_step` gives
> retention^gap and the shot's starts (cut, step back, loop); stopped or with steady shots off, the frame's own.
> Three RGBA32F frame targets, made on first use. `GpuCompositor::hold_sequence` + `rudra-gpu-parity` hold it
> to the C++ reference on `probe/hold_sequence.hpp` (still, panning, clipped with small and large HDR change,
> crushed, clipped in alternate frames). The shader was checked here only by qsb and by a CPU transliteration
> (3.7e-7 relative to `hold_pixels`); Qt 6.8 builds and runs it in Gate B. Scopes while playing measure before
> the hold.
>
> **11 Oct 2026, evening — temporal follow-ups (line F).** (1) Clipped highlights: where the source is clipped
> (largest code >= 0.98) in both frames, `hold_pixels` now holds the gain by the HDR's own change (3x3 mean of
> |dlog2 Y|: held under 0.05 EV, its own over 0.25 EV); clipped in one frame only stays its own. Python and
> native in parity; video_convert/video_queue goldens re-emitted. (2) `PlaybackHold::shot()` counts every shot
> start (loops included) and a measure carries the shot it was shown in, so a late anchor measure from before a
> loop or a cut holds nothing. (3) `tools/measure_temporal.py`: clips x {each frame, shot hold, shot + static}
> -> temporal.json/md. On the test clips: still grainy pattern local flicker -65 %, h264_709 -70 %, heavy-grain
> moving pattern -4 % (moves exceed the still threshold). No real consecutive footage is on this machine, so
> real footage then measured (docs/TEMPORAL_RESULTS.md): five 2 s clips of HdM HFR 2017 and Netflix Chimera
> (`tools/make_temporal_clips.py`, SDR by Hable tone map), `rudra-native video` with shadow_v1 and analytic
> (`--grade`, new: an export settings file on the command line, "-" for no package). With the model the fire
> clips flicker 0.03 / 0.05 EV a frame beyond the source (worst 0.11 / 0.19 EV); both holds take that to
> 0.006 / 0.013 (worst 0.024 / 0.054), local -64 % / -47 %. Analytic flickers ~10x less to begin with. Still
> hillside -29 % (model) / -63 % (analytic) local; freeway -3 to -5 % (everything moves). STATUS row 5 is
> measured with RUDRA's flicker measures, not yet clip-mode CVVDP. (4) Static hold in playback: not done; it
> needs a GPU pass (render/, Qt 6.8) that cannot be built here.
>
> **11 Oct 2026, later — Dolby Vision and HDR10+ metadata in movie exports (line F, item 6).** PQ exports
> (HDR10, ProRes PQ) analyse every mastered frame (`analyze_frame`, MaxRGB) and write per shot of the
> export's own cuts (`shots_from_cuts`): `<output>_hdr10plus.json` (x265's LLC JSON: one SceneInfo per
> frame, 0.1 cd/m2, DistributionIndex 1..99), `<output>_dovi_generate.json` (dovi_tool generate: L1 now
> `{"Level1": ...}` with its CM v4.0 clamps, L6 from the mastering display and MaxCLL/FALL), the analysis and
> the HDR10+ scenes file. HDR10 embeds HDR10+ via `-x265-params dhdr10-info` when a one-frame probe shows the
> ffmpeg's x265 has ENABLE_HDR10_PLUS; QC then requires ST 2094-40 on frame 1. Ubuntu's x265 does not, so CI
> runs the sidecar path; the embedded path was run here against an x265 3.5 built with HDR10+. Validated with
> third-party tools: hdr10plus_tool extract gives back our values, hdr10plus_tool inject accepts the file,
> dovi_tool generate accepts the config (the old `{"Level": 1}` blocks were not accepted). Python and native
> in parity (goldens re-emitted: delivery, video_convert, video_queue). Reviewed: x265-params escaping (quote,
> blank, colon, backslash), names per output (clip.mp4 and clip.mov), publish order, probe caching.
>
> **11 Oct 2026 — beta 10 prepared (line F).** v0.9.0-beta.9 was tagged on bbf6726 (the shot hold) before
> the static hold (0dbad8f) and the notes (a8ac01a) landed, so they ship as beta 10 (`RUDRA_RELEASE` beta.10,
> archive/docs/BETA.md "Changes since beta 9"); the beta 9 tag stays where it was published.
>
> **10 Oct 2026, later — the static hold (beta 10, line F).** Pixel level, still without fetching anything
> across frames: `ShadowSmoother.hold_pixels` holds the HDR/source luminance gain per pixel with the shot's
> retention where the decoded source's luma code is still (3×3 mean |Δ| under 1.5/255 held, over 6/255 its
> own, smoothstep between), never where the source is clipped (largest code ≥ 0.98) or crushed (≤ 0.02) in
> this frame or the last, nor a negative HDR pixel; output = HDR × held/gain, so the source's own change passes
> through. Applied in `convert_video`'s loop (Python and native, `--static-hold on|off`, default on, a no-op
> at retention 0), before the measures; reports gain `static_hold`, per-frame `local_flicker_ev` (mean over the
> 36×64 cells of |ΔEV(HDR) − ΔEV(source)|) and its mean and max. Goldens re-emitted (hdr10 and hlg masters
> change, still byte-identical to the Python on ORT; prores runs it off). On a still grainy ramp, analytic:
> local flicker mean 1.9e-4 → 1.3e-4 EV, worst frame 1.9e-3 → 3.3e-4; with the model, PQ temporal std p99
> −37 %. 40 ms per 1080p frame on one core. Not in playback yet. Reviewed: negative pixels, 4K copies,
> trails inside clipped highlights (now excluded). Linux: core 220/220, ORT 229/229, app 56/56, Python 30/30.
>
> **10 Oct 2026, late — temporal consistency for video (beta 9, line F).** Scope chosen with the user:
> shot-stable scalars and a flicker measure, no pixel blending (line D's verdict stands: estimated flow
> does not carry the information, so nothing is fetched across frames). `ShadowSmoother` gained `hold()`:
> the residual scale and curve (models with those heads) and, in graded exports, the anchor's hold (log2)
> are held with the shadow weight's retention and reset at the same cuts; `--temporal-smoothing SECONDS`
> (default 0.25, retention exp(-1/(fps·s)); `--shadow-smoothing`, when given, still sets the retention) in
> `rudra video` and `rudra-native video`, queue option `temporal-smoothing`. Every movie report gains
> `temporal_smoothing`, per-frame `flicker_ev` and a `temporal` summary: |ΔEV(HDR) − ΔEV(source)| on a
> 36×64 area thumbnail of the luminance, cuts not scored. The app holds the shadow weight and the anchor's
> hold while playing (`engine/playback_hold`, skipped frames as elapsed); stopped shows the frame's own
> values; Clip > Hold steady within a shot (QSettings `video/steady`) sets playback and the export's option.
> Goldens re-emitted (video_convert, video_queue; prores case runs `--temporal-smoothing 0`), masters
> unchanged. On a grainy moving test pattern the analytic anchored export's flicker fell 0.0044 → 0.0014 EV
> mean. Linux: core 217/217, ORT build 226/226, app 56/56, Python video tests 28/28.
>
> **10 Oct 2026, night — beta 9 prepared (line F).** Movie exports now carry the app's settings:
> `deliver/master grade_master()` (split from `write_master`) runs per frame inside `video/convert` when the
> job names a `grade` settings file (`VideoConvertArgs::grade`, queue option `grade`); analytic jobs need no
> package (the settings file is the job's checkpoint). Playback with the model: `FrameEngine::set_playing`
> keeps inference ahead of the playhead, a proxy at 960 px by default (`FrameResult::proxy`,
> `resize_fields`) refined at full size where it stops; `app/playback` MovieFeeder decodes a movie in order
> with one ffmpeg; realtime keeps time by skipping. CPU ORT on shadow_v1: 8.85 s at 1080p, 2.11 s at 960x540
> (4.2x), 1.16 s at 640x360 (7.6x); from 154 ms per 1080p frame on the RTX 4080 that is ~37 ms / ~20 ms,
> estimated, to measure on the GPU. Reviewed (feeder stall on a skip and a loader held in take() on reset:
> fixed). Linux: core 214/214, app 55/55 (41/41 without OpenCV), master parity PASS, video real tests 5/5 on ORT.
>
> **10 Oct 2026, evening — beta 8 prepared (line F, R5).** An external review (ChatGPT Pro, of `main`
> 5e827a7 and `native` 161eb2d) found that "masters default to the analytic inverse" was not true of the
> app: `GradeSnapshot` defaulted to mode all / strength 1 and every frame and master ran `infer_frame`.
> R5 ("never the default path of a master") was therefore not met. Now the analytic reconstruction is the
> default: zero fields, default scalars and `kAnalyticConstants` (corpus EV 0), no inference call, no
> package needed to open, view or master; Reconstruct > Use the model turns the model on (QSettings
> `model/use`, `Project::use_model`); masters record `rudra:reconstruction` / sidecar `reconstruction`
> when analytic, and the CLI master honours `"analytic": true`. Known and said: movie exports still run
> `rudra video` (the model, recovery all, no grade). Reviewed twice (second pass: source panel at the
> wrong corpus EV, CLI label, pending shots, project changing the user default: all fixed). Linux: core
> 209/209, app 51/51 (41/41 without OpenCV), master parity PASS. CI actions moved to Node 24.
>
> **10 Oct 2026, later — beta 7 prepared (line F).** Beta 6 released (release #10 green, 8 assets), but
> the native workflow had been red since beta 5 and nobody had read why: the CI re-emits the Python
> goldens, and the 9 Oct ship-path fixes moved the Python (HLG log10 + ratio-preserving scale, Rec.2020
> before the shoulder in `deliver`, partial-name publish, Region EV after the anchor, linear masters in
> Rec.2020) without the C++ port following. Ported all five: `deliver/sequence_encode` + `cli/deliver`,
> `core/master` + `deliver/master` (grade last; linear converted and tagged `kRec2020Chromaticities`).
> The viewer had the same anchor bug (the display-pass anchor divided a Region EV push out below the
> knee): the composite now carries the grade gain in its alpha (composite.frag) / `grade_gain`
> (CPU), and the measured hold is the ungraded one. Emitters updated (composite stages: anchored,
> carried, settled, graded; sequence_encode maps the partial path to OUTPUT). The Qt shell job failed
> on beta 6's own test (`last_log` exists only with still decode): fixed. Linux: core 207/207 with
> OpenCV against freshly emitted goldens, master parity PASS on ONNX Runtime 1.22 (3 cases), app 50/50.
>
> **10 Oct 2026 — beta 6 prepared (line F, R4).** Product items 2 to 5 of the 9 Oct "professional"
> list. Projects (`engine/project`, `.rudra` JSON v1, atomic, masks as `<name>.rudra.masks.png`,
> relative paths, validated and clamped on load) with File > Open/Save/Save as, autosave a few seconds
> after a change, File > Reopen last session (the last run's file kept as previous-session.rudra; one
> instance owns it, QLockFile), a save prompt before a dirty project is replaced. The Windows package
> carries the gyan.dev full ffmpeg 7.1.1 (SHA-256 pinned; GPL v3, licence and source note in `ffmpeg\`),
> put first on PATH by `platform/tools`; the DMG only with `MAC_FFMPEG_DIR` (a static build), so macOS
> still needs Homebrew's. Every Windows executable now runs in the UTF-8 code page (`cmake/utf8.manifest`),
> which fixes non-ASCII user and folder names reaching ffmpeg and OpenCV. Daily update check against
> GitHub releases (betas follow betas), Help > Getting started, User guide (F1, `docs/USER_GUIDE.md`),
> Open log folder, tooltips. Signing hooks: signtool with `RUDRA_SIGN_PFX`, `WINDOWS_CERT_PFX` in the
> release workflow; certificates still to buy. Reviewed twice (independent pass: 9 findings, all fixed;
> re-review: 2 more, fixed). Linux: core 199/199 (206/206 with OpenCV), app 50/50 offscreen; Windows and
> macOS run in CI. Not done: Dolby Vision / HDR10+ metadata, OFX plug-in, real-time playback (item 6).
>
> **9 Oct 2026, 23:45 — beta 5 (line F).** Beta 4 was tagged and published at `9397ae0` (8 assets)
> before the startup and error-reporting commit (`5f2f6c2`) landed, so that ships as beta 5 rather than
> by moving a published tag: foreign `QT_*` variables ignored, a rotating log file, failed writes that
> name their reason. `RUDRA_RELEASE` beta.5; `archive/docs/BETA.md` leads with the changes since beta 4.
>
> **9 Oct 2026, 21:30 — beta 4 prepared (line F).** `RUDRA_RELEASE` beta.4; the release workflow
> exports `sdr2hdr_image_v8` (it still exported shadow_v1, so a tag would have shipped the retired
> model); `archive/docs/BETA.md` lists what changed since the beta 3 tag (source panel, calibration, reference
> match, painted masks, anchor live, ProRes 4444 and log, v8, GroupNorm parity, fp16/TensorRT). A bare
> start follows the default when it moves (`model/followsDefault`; an older beta's own package gives
> way), `AppModels.*` 10/10 on Linux. PR #29's macOS core job failed `SequenceEncode.LiveEncodesCarryTheirTags`
> and `DeliverReportIsThePythons`: the 7 Oct goldens were recorded with the 2025 gyan.dev ffmpeg, whose
> MOV/MP4 colr atom leaves BT.2020/PQ unspecified, and ffmpeg 6.1 (Homebrew, Ubuntu) fills them in. The
> tests now accept either form for the container atom and require the ProRes frame headers to match; 5/5
> on Ubuntu with ffmpeg 6.1. Startup and errors (item 1 of the product list): foreign `QT_*` variables
> ignored by a packaged app (`app/startup.cpp`), a rotating log file, and every failed write names its OS
> reason and free space (`platform/io_error.cpp`; writers check `close()`, truncated EXRs removed); native
> 190/190, app 34/34 on Linux (Qt 6.4, no OpenCV/ORT). Ship-path review and fixes:
> `reports/CODE_REVIEW_SHIP_PATH_2026-10-09.md`. Tag and push from PowerShell:
> `archive/scripts/release_beta4_2026-10-09.ps1`.
>
> **9 Oct 2026, 13:45 — the optional model is v8 (line G, release row R5); shadow_v1 retired.**
> `checkpoints/sdr2hdr_image_v8.pt` (best.pt, step 48,000) committed with its config and SHA-256;
> both `models.json` default to it, shadow_v1 kept in the registry as retired, its package moved out
> of `dist\models`. Gate A on v8 (RTX 4080 SUPER): ONNX vs eager 4.3e-6, the 287 Meridian frames
> 3.9e-6 (fp16 2.3e-3), every runtime PASS (worst DirectML fp16 8.4e-3), 1080p DirectML 158 ms, CUDA
> 154 ms. Beta 3 repackaged with v8 (zip sha256 87dfdd2f…). The phase 3 and 4 exit scripts and the
> package script default to the v8 package. Why: on real SDR v8 is level with the inverse (+0.02 dB,
> CVVDP CI above zero) and +4.14 dB over shadow_v1 on all 287 frames; it does not pass its own gate
> (clipped pixels no better, black lifted), so the master path stays the inverse.
>
> **9 Oct 2026, 03:30 — ProRes 4444 and log masters in the app's Export sheet (line F).** A 4444 tile
> beside 422 HQ; on both ProRes tiles an Encoding row: PQ (graded, as before), ACEScct (AP1) or ARRI
> LogC4 (AWG4). The log files carry the scene-linear master before peak and knee (the ACES EXR's
> pixels), Rec.2020 to the curve's gamut by Bradford, then the curve; tagged unknown primaries and
> transfer, the curve and gamut in the sidecar's `log_encoding`, `_acescct`/`_logc4` on the name.
> Four native-only delivery profiles (`log_delivery_profiles`); the Python's five and their parity
> tests unchanged. `tests/test_log_encode.cpp` (6): ACEScct 0.18 -> 0.41359, LogC4 0.18 -> 0.27840 and
> black at 95/1023, the AP1 and AWG4 matrices to 1e-9, the encoder's tags, QC on an untagged file.
> End to end with ffmpeg 6.1 (Linux): ProRes 4444 LogC4 `ap4h` yuv444p12le, no primaries or transfer
> tag, QC passed, grey decoded 0.27854 (10-bit step). ffmpeg's prores_ks takes 10-bit input, so 4444
> is 10-bit in a 12-bit container; the label says ProRes 4444, not 12-bit. Native tests 186/186, app
> 29/29 (the movie export test runs in the OpenCV build, NATIVE_PHASE3_EXIT).
>
> **9 Oct 2026, 01:45 — shadow_v1 on real SDR for the first time (line G, release row R5).** Netflix
> Meridian, 287 test frames, against the inverse: −4.11 dB [−4.18, −4.04] / −0.006 JOD
> [−0.008, −0.004], 0/287 wins on PU21; crushed-pixel error 5.58 stops vs the inverse's 1.56. v8 against
> shadow_v1 on the same frames: +4.14 dB [+4.10, +4.17], 287/287, +0.026 JOD [+0.008, +0.044]. The
> optional model the app ships loses to the inverse on every real frame. `models.json` notes updated;
> `scripts\bench_shadow_v1_real_2026_10_09.ps1`, `reports\logs\shadow_v1_real_vs_baseline.json`.
>
> **9 Oct 2026, 01:20 — phase 3 gate passed by hand on Windows (line F).** The beta 3 package
> (`PACKAGE_WINDOWS.ps1 -NoInstaller`, `dist\beta\RUDRA-0.9.0-beta.3-windows-x64`) on the RTX 4080 box
> and its HDR display, launched with no Python: source, three-click calibration, reference match,
> painted mask with Region EV, anchors with no control lagging the playhead, a master still and a
> 240-frame video job. Beta item "workflow by hand on an HDR display" ticked. The gate B build
> (`build\native_gate_b`) is a viewer test build with no still decode or backend and opens no frames;
> the by-hand pass runs on the package. Left for 1.0: the Mac items, Apple enrollment, the installer
> on a clean PC, the tag.
>
> **9 Oct 2026, 00:30 — v8 scored (line G): FAIL, the gate holds; v8 stays research, not shipped.** 50k
> steps, best.pt = step 48,000 (whole-val composite 0.786; clean real val gain −0.12 dB, peak +0.61 at
> 6k). Against the inverse: **real Meridian +0.023 dB [−0.025, +0.077] / +0.020 JOD [+0.003, +0.036],
> 38/287** (FAIL on the PU21 CI; the first model with a CVVDP CI above the inverse on real, v7 was
> −4.13 dB, 0/287); aces −11.20 dB / −0.873 JOD (v4b −8.09, v7 −19.21; on aces the inverse is exact,
> 49 dB); oog −0.29 / −0.086; mix −0.03 / −0.120. Inside clipped pixels: +0 EV −0.36 stops
> [−0.42, −0.30] (worse), +1 EV −0.02, +2 EV +0.00 (ties): the region-focused loss did not teach
> highlight reconstruction. Crushed pixels: 3.96 stops vs the inverse's 1.59 (+2 EV), 4.83 stops worse
> on real. Diagnosis by luminance band: v8 tracks the inverse to 0.01 stop from 2 to 200 nits; its
> loss is below 2 nits, where it lifts black (median +5.8 stops over the reference under 0.05 nits on
> Meridian, the inverse +3.1), and on aces from 200 to 1,000 nits (0.54 stop vs 0.05). Above 200 nits
> on Meridian it is a stop closer than the inverse (−0.54 vs −1.55). An inference-time shadow pin
> (the inverse where the inverse is under 1 nit, log ramp to v8 at 4 nits) measured on bench subsets:
> real +0.20 dB, mix +0.26, oog +0.21, aces −6.9 (from −11.1). Not adopted: its thresholds were found
> on the test benches. `reports\logs\cp8_results_v8.json`, `v8_verdicts.log`.
>
> **8 Oct 2026, 15:00 — v8 tooling in (line G), no GPU time spent.** The gate is written before the run:
> `training/cp8_verdicts.py` (real Meridian both CIs above the inverse; aces/oog/mix not worse; inside
> clipped pixels at +0/+1/+2 EV lower error than the inverse, CI above zero). The clip benches:
> `export_bench_pairs.py --condition exposure` and `training/score_regions.py` (roadmap 4.2 tooling).
> The narrowed target: `sdr2hdr_loss(region_focus=f)` / `train_sdr2hdr.py --region-focus` (f of the loss
> on the SDR's clipped/crushed pixels, the rest held to the inverse; 0 is the old loss to the bit).
> `archive/scripts/run_v8_2026_10_08.ps1` smoke/train/bench on `rudra_mix_v4c_netflix_20261008b`, region focus
> 0.5, whole-val eval every 2k steps, no curve head or label. `tests/test_v8_bench_2026_10_08.py`.
>
> **8 Oct 2026, 14:20 — full-set model check closed with a real fix (line F); v8 data in (line G).** The
> 287 Meridian frames through every runtime: ONNX fp32 had left eager PyTorch by 5.6e-3 at 1080p (3e-4
> allowed), unseen on the 300 px golden frames. `nn.GroupNorm` -> ONNX `InstanceNormalization`, whose
> group statistics ORT sums in one float32 pass; `StagedGroupNorm` in the ONNX graphs reduces them in
> three stages. Now 8.8e-6 on the 287 frames, golden 2.2e-6 (was 5.8e-5), fp16 2.5e-3; native DirectML
> 3.5e-6. DirectML pays for the extra ops (1080p 139 -> 207 ms, 4K tiled 1.5 -> 2.1 s; dispatch-bound,
> fp16 no faster), budgets re-measured. Line G: the Netflix corpus is 5,494 train / 163 val / 287 test
> real pairs (second pull, every odd frame; `check_realsdr_corpus.py` PASS), the v8 training manifest
> `rudra_mix_v4c_netflix_20261008b`. Beta items left: the by-hand workflow on an HDR display and the Mac.
>
> **7 Oct 2026, 20:05 — roadmap 3.6 closed, masks verified (line F).** Gate A on the RTX 4080 SUPER
> (fp32, median of 5): LibTorch CUDA 170 ms 1080p / 689 ms 4K (tiled 290 / 900), DirectML 139 ms /
> 3 535 ms untiled, 1 504 tiled, CPU LibTorch 2.45 s / 9.3 s, ORT 3.1 s / 13.6 s; every 4K row now
> budgeted (+25 %) and gated. Parity on all four backends 1e-7 to 6e-5. Phase 3 items are all ticked;
> the phase 3 gate (a colourist by hand on an HDR display) and the beta items that need a Mac remain.
> The masks commit passed rudra_tests 180/180 and rudra_app_tests 29/29 (19:16); gate B for it pending.
>
> **7 Oct 2026, 19:40 — roadmap 3.3 painted masks in (line F), awaiting the Windows run.** One 8-bit
> mask per Region EV band (first four), painted on the viewer at the preview's size, gating the band's
> qualifier (`core/masks.cpp`; the brush, bilinear sampling at any frame size, PNG codec in
> `platform/png8.cpp` with no library). GPU: one RGBA8 texture read by composite.frag and display.frag
> (the tint), uploaded per stroke. Session: a stroke an undo step; master writes `<name>.masks.png`,
> sidecar `masks`, provenance `rudra:masks`; CLI `masks_file`. Brush card under the Region EV rows.
> `tests/test_masks.cpp` (8, green with g++ on the VM); parity cases `masked region EV` and view
> `painted mask tint`. 3.3 closes with it.
>
> **7 Oct 2026, 18:55 — roadmap 3.4 reference match in and verified (line F).** Windows: rudra_tests
> 172/172 (ReferenceFit 10/10), rudra_app_tests 29/29, rudra-gpu-parity 20/20 cases on D3D12, D3D11,
> Vulkan and OpenGL, the new `reference hable` row fp32 <= 2.8e-6 abs (the +0.4 to +0.75 stop target
> raises the magnitudes), fp16 1 ulp, every view row passing. The
> Reference block in the Source card: load the graded HDR of the frame (EXR by its chromaticities, or
> 16-bit PQ PNG/TIFF; `engine/reference_image.cpp`) and the baseline is fitted to it as a calibration at
> every code (`core/reference_fit.cpp`: per-code median of log2 nits, holes interpolated, smoothed,
> isotonic, residual mean and p95 in stops). Stored as log2 nits per code, independent of the picker, so
> it rides the same 256-knot path through `baseline_curve_params` and replaces the anchors. In
> `params()`, the master request, the sidecar and the EXR provenance only when set. New:
> `tests/test_reference_fit.cpp` (10 tests), a parity case `reference hable`. Phase 3 critical path
> left: 3.3 painted masks, 3.6 numbers, wiping against the reference (optional).
>
> **7 Oct 2026, 17:00 — roadmap 3.3 latency and knee in and verified (line F).** Every live control is one
> composite + display pass: 4K 1.08 to 1.33 ms wall across D3D12, D3D11, Vulkan and OpenGL on the RTX 4080
> SUPER, now gated (`native/bench/latency_budgets.json` `control_latency`, `rudra-gpu-parity --budget
> --machine`). The master's anchor stage is live on the viewer with an Anchor knee slider in Deliver
> (`core/view.cpp anchor_gain_f`, the fp32 twin of `anchor_to_sdr`, pinned to 2e-4; the hold from the
> measure). Verified: rudra_tests 162/162, rudra_app_tests 29/29, parity 18/18 with four anchored view
> rows at <= 1 code. Open in 3.3: the painted masks. Carry source chroma stays master-only.
>
> **7 Oct 2026, 12:35 — roadmap 3.1 and 3.2 in and verified (line F).** The Source card: a six-way curve
> picker (3.1) and three-click calibration (3.2), both expressed as the CurveHead's own per-code log2
> correction over the ACES inverse (`core/source_curve.cpp`, `core/calibration.cpp`, one knot per 8-bit
> code; shader knot buffer 9 to 72 vec4), summed with the model's head in `baseline_curve_params`, so
> the composite, the shader, master, measure and QC carry both with no new path. Unknown and no anchors
> are bit-identical to every master before. Verified on this box: rudra_tests 159/159, rudra_app_tests
> 29/29, rudra-gpu-parity 18/18 on D3D12, D3D11, Vulkan and OpenGL (fp32 within 6e-7, fp16 1 ulp on the
> new rows). Open: the by-hand pass in RUDRA.exe; the source and anchors are per master, not yet per shot
> on video delivery (5.3).
>
> **7 Oct 2026, 11:50 — native tests on Windows, first full run (line F).** `scripts\NATIVE_TESTS.ps1`
> (new) builds and runs the suites in the gate B build: rudra_tests 154/154 (1 skipped: rudra-native not
> in that build), rudra_app_tests 29/29, rudra-gpu-parity 16/16 on D3D12, D3D11, Vulkan and OpenGL
> including roadmap 3.1's source-curve rows. Two ffmpeg-build findings, both fixed: the 2025 gyan build
> writes no `colr` atom for MP4 unless asked (`+write_colr` now goes on MP4 as well as MOV, in
> `rudra/delivery/video.py` and `sequence_encode.cpp`), and it cannot put BT.2020/PQ in a MOV's legacy
> `nclc` atom, the case the oracle already notes and delivers; the golden now records that note and the
> test compares it. Golden re-emitted on this box (index only; the Linux frame and code oracles kept).
>
> **7 Oct 2026, 11:00 — v7 post-mortem, line E closed.** `sweep_val_checkpoints.py` on the full
> 538-row val (163 real, 375 rendered), every other checkpoint, and `bench_by_curve.py` on `mix`:
> 1. *Not overfitting.* Full-val composite is flat, +1.44 (2k) to +1.77 (34k) to +1.72 (50k); real-row
>    hard gain −0.40 at 2k, +0.74 at 34k, +0.51 at 50k. The step-1,500 peak and 48k-step decay were the
>    32-record slice. `best.pt` (step 3,000) was picked where the real rows were still negative.
> 2. *The training eval does not predict the bench.* Full val says +1.5 dB over the inverse on every
>    row kind; the bench says −2 to −24 dB and 0 of 287 on real. 256-px centre crops and log-PSNR on the
>    mixed manifest's val versus full frames and PU21/CVVDP: selection on the former cannot find a
>    checkpoint that passes the latter, whichever step. Every run since v4 selected this way.
> 3. *The real val split is animation.* Cosmos Laundromat is a Blender short; the real test (Meridian)
>    is live action. Real-row training gains were measured on a cartoon.
> 4. *Curve input: not miswired, harmful.* `aces` label helps (mix −0.98 dB vs −2.29 blind; aces bench
>    +2.4 over blind). `hable` −4.58 vs −3.32 blind, `agx` −4.42 vs −3.03: the label makes the filmic
>    curves 1.3 dB worse on both metrics. Only `clip` (+1.49 blind, v4c +2.94) and `reinhard` (+1.19,
>    v4c +2.35) are positive for any model: the recipe helps when the SDR is nearly a plain clip and
>    hurts on the curves it was built for.
> Evidence: `checkpoints\sdr2hdr_image_v7\val_sweep.jsonl`, `bench_by_curve.py` output in the 7 Oct
> project note. Optional, research track only: bench step 34,000 once to see how much of the gap is
> the step-3,000 pick (expected: little; the −4 dB on real has 0 wins).
>
> **24 Sep 2026, 22:30 — critical path scored; all four gates that ran fail (line E).**
> `RUN_CRITICAL_PATH.bat` finished at 14:32: Step 4 re-run on the hold-out
> manifest (`87a32f…`, 50k steps, best = step 45,500), Step 5 (8k), v4c with
> `--curve-head` (50k, best = step 25,500), then the three CP7 benches. CP7 had
> called `paired_gate.py` with **no gate flag**, so every row printed `GATE PASS`
> (shadow_v1's 0 of 537 on ACES included). Gates now live in
> `training/cp7_verdicts.py`, re-scored from the same CSVs (no GPU); the old
> file is kept as `reports/logs/cp_results_2026-09-24_nogates.json`.
>
> | gate | question | PU21 Δ [95% CI] | CVVDP Δ [95% CI] | |
> |---|---|---|---|---|
> | N1/step4 | v4b beats the analytic inverse on its own ACES render | −8.09 [−8.80, −7.36] | −0.508 [−0.564, −0.456] | **FAIL** |
> | N1/step5 | the gate head adds anything over v4b | 0.00 | 0.000 | **FAIL** |
> | N3 | v4c beats the inverse out of generator | +1.33 [+0.80, +1.86] | −0.126 [−0.182, −0.073] | **FAIL** |
> | N3/clean | v4c within 0.1 dB / 0.02 JOD of v4b on ACES | −13.86 | −1.082 | **FAIL** |
> | N7 | studio weights within 0.3 dB / 0.03 JOD of v4c | | | not run |
>
> - **Step 5 did nothing.** From step 0 no eval beat the init (hard gain fell
>   from 0.80 to 0.67 dB), so `best.pt` is the step-0 save and its bench rows
>   are v4b's to the digit.
> - **v4c cannot see ACES.** It loses on all 537 ACES frames on CVVDP, which is
>   what the CPU proxy predicted. The fix already named for it is a confidence
>   output that falls back to the analytic inverse, not dropping the head.
> - **What training measures and what the bench measures disagree.** v4b's evals
>   read +1.41 dB clean over the inverse, but on the bench of the same render
>   it loses 461 of 537 frames. Median frame: baseline 47.3 dB PU21, v4b 38.1.
>   The two differ in data (32 val crops of 256 px against full test frames),
>   metric (log1p(16x) PSNR against PU21) and precision: `predict_image` ran
>   under bf16 autocast while the baseline tree is fp32.
> - **25 Sep: precision is not the gap.** `scripts\RUN_BENCH_FP32_CHECK.bat`
>   re-exported the four rows in fp32: aces/v4b -8.121 dB (bf16 -8.088),
>   aces/v4c -21.950 (-21.948), mix/v4c -0.890 (-0.899), oog/v4c +1.342
>   (+1.330); JOD moves by 0.003 at most. bf16 stays the export default. That
>   leaves data and metric. **Open: `scripts\RUN_BENCH_GAP_CHECK.bat`** (no GPU,
>   minutes) scores the same bench trees with the training metric beside PU21,
>   and splits the PU21 error and the level bias by reference luminance
>   (`tools/diagnose_bench_gap.py`). The training metric, PSNR of
>   log1p(16 x) in 10,000-nit units, barely sees anything under a few hundred
>   nits: a 10% error at 20 nits moves it 0.003, at 2,000 nits 0.07. If it
>   says v4b wins on the bench frames while PU21 says it loses, the loss and
>   `best.pt` selection are rewarding the wrong thing, and they are fixed before
>   any retrain; if both say it loses, the difference is full frames against
>   crops.
>
> Next, in order, each behind the one before: (1) the fp32 check (done:
> not precision); (2) the gap check, then the metric or selection fix it
> points to; (3) the N3 fallback, then retrain v4c (about
> 6.5 h); (4) Step 7 as written: the 429 paper frames at clean and hard, and
> `measure_clipping.py --score`; (5) only then Step 6 temporal, promotion, and
> N7 `rudra-studio`.

> **25 Sep 2026, the master: highlight grain (line F).** A tester found a
> colour-neutral grain in recovered highlights, peaking where the source sits
> at 0.95-0.98. It is the analytic baseline, not the model: one 8-bit code is
> 0.8 nits at mid-grey through `inverse_aces_approx` and 41 to 161 nits between
> 0.95 and 0.98, so the source's own grain comes out as tens of nits once the
> reconstruction takes over from the anchor. New stage after the chroma carry,
> `rudra/grain.py` `settle_highlight_grain`: luminance smoothed where the
> reconstruction took over and the source is flat (spread under one code;
> none from three), in linear light, one gain per pixel. Measured on a sunset
> plate, flat areas, by source luma (`tools/measure_highlight_grain.py`): 0.9-0.95
> 9.4 -> 0.7 nits, 0.95-0.98 17.0 -> 1.8, 0.98-1.0 27.7 -> 7.2, against the
> source's own 0.9 / 0.7 / 0.3; frame mean and peak unchanged; textured areas
> unchanged. Default on in the Studio's master and `rudra-native master`
> (`settle_grain`), ported with its goldens. CI the same day: every build passes
> on the three OSes; the core tests' Windows (a file still open when removed,
> backslash paths in a refusal message, tile weights one ulp from the MSVC
> wheel's linspace) and macOS (Apple clang fusing multiply-adds, now off
> project-wide; Homebrew ffmpeg without zscale, now ffmpeg-full) failures are
> fixed, and each failing test now publishes its own annotation.

> **25 Sep 2026, native app: macOS and the beta (line F).** On a MacBook Pro
> (Apple silicon, macOS 27) the app builds with `scripts/native_app.sh` and
> its 36 Qt tests pass, the scripted workflow and a movie's HDR10 export
> included; the model exports there with TorchScript exact and ONNX at
> 5.4e-5. What the Mac showed and was fixed: Qt 6.8 linking AGL (gone from
> the macOS 15+ SDK), OpenGL needing a 4.1 core profile, ONNX Runtime's
> environment made before a Core ML session and destroyed in order at exit,
> a detached measurement thread, `/var` being `/private/var`. CI's goldens
> check failed on every OS on one line (the fit golden recorded OpenCV's
> version; pip now installs 5.0); fixed, and failing steps now publish
> their output as annotations. The beta is packaged: 0.9.0-beta.1,
> `scripts/package_mac.sh` (DMG), `scripts/PACKAGE_WINDOWS.ps1` (ZIP),
> `release.yml` on a `v*` tag, notes in `archive/docs/BETA.md`. Open before the tag:
> the probe builds in CI, Gate A on MPS and Core ML, Gate B on Metal EDR,
> and each package built and opened on its OS.
>
> **24 Sep 2026, native app: Phase 4, video delivery (line F).** `rudra video`,
> `rudra deliver` and `rudra batch run` now exist without Python:
> `rudra-native video` is convert_video (the same checks and words, decode,
> predictor with its shadow smoother, mastering, spool, encoder command, QC
> and report key for key), `rudra-native deliver` is encode_sequence with its
> tag checks, `rudra-native batch run` runs the same queues, and a queue
> stopped by either side finishes on the other. The HDR10 and HLG masters are
> byte-identical to the Python's on LibTorch and ONNX Runtime; ProRes 4444 is
> within codec noise, because the Python's PQ codes come from numpy's float32
> power, which is not correctly rounded (one code in 65535, and CPU-dependent).
> In RUDRA.exe a movie opens and scrubs as a shot and its HDR10, HLG and
> ProRes exports go through a queue window with Stop and Resume; the app's
> HDR10 master of a clip is byte-identical to `rudra video`'s. `rudra-native
> ffmpeg-check` says what the machine's ffmpeg lacks and runs a 16-frame
> HDR10 export through it, once per build. ffmpeg and ffprobe run as programs,
> as the Python runs them (x265 stays out of the app). 177 native tests on
> Linux. Found on the way: x265 3.5 crashes at 48 x 32 with preset slow, in
> the Python too; two native tests had silently run no cases (a dangling
> range-for over a temporary), now fixed. Open:
>
> - [ ] Windows, scripted, no Python on the PATH:
>   `.\scripts\NATIVE_PHASE4_EXIT.ps1 -Clip <a movie with audio>` (ffmpeg with
>   libx265 and zscale on PATH or `-Ffmpeg`)
> - [ ] Windows, by hand (the checklist the script prints): drop a movie,
>   scrub, export HDR10 from the sheet and watch the Queue window to Complete,
>   stop and resume an HLG export, play the master on the HDR display with its
>   audio, reopen and find the queue as it was
>
> **24 Sep 2026, native app: Phase 3, the Qt UI (line F).** RUDRA.exe is the
> Studio page as a native window: its look generated from `ui/theme.css`, its
> 33 actions, menus and keys, `params()` and undo byte for byte with the page,
> its layout, scopes, panels, probe and measurements checked against the page
> run headless, the Deliver tab's master as a background job (the server's
> render plan and refusals exactly), a checkpoint manager that finds packages
> as the server finds checkpoints and switches them mid-session with the
> grade kept and each package checked against its goldens on first use, a
> first-run check that shows the HDR card on the display and names its peak,
> the page's clipboard texts byte for byte, drop to open, Open recent, and
> settings kept between runs. 138 app and engine tests on Linux.
>
> **Revision after the first Windows run (24 Sep).** The window now has the
> Pro-direction look (the boards on the RUDRA Studio Desktop canvas) instead
> of a copy of the browser page, with every control, handler and number as
> before, and it previews at the Studio's 1600 on the long side (it was
> previewing 2560 x 1440 at full size). The Windows scripted exit had passed
> every workflow step (240 frames on DirectML, masters byte-identical to the
> CLI's); its FAIL was the app tests, whose output the script now keeps.
>
> **Phase 3 exit.** Scripted: `RUDRA --workflow-check` opens a package and a
> folder, scrubs every frame, grades and undoes, compares, probes, measures
> and masters three frames in the real window; `rudra-native master-compare`
> holds those masters to the CLI master (the path held to the Studio). On
> Linux, 240 frames on ONNX Runtime CPU: every step passes, every frame
> delivered as itself, the graded masters byte-identical to the CLI's. Open:
>
> - [ ] Windows, scripted, no Python on the PATH:
>   `.\scripts\NATIVE_PHASE3_EXIT.ps1 -Frames <a 240-frame folder>`
> - [ ] Windows, by hand on the PA279CRV (the checklist the script prints):
>   first-run card and peak; switch packages mid-grade; drop, scrub, play;
>   grade, undo, redo; wipe, flip, layers; probe against the Frame panel;
>   master the frame and the sequence, copy the delivery metadata; quit and
>   reopen (window, rails, tab, Render fields, Open recent)
> - [ ] Mac: the Phase 0 runs still stand in front of it
>
> **24 Sep 2026, native app: Phase 1 (line F).** librudra now does, in C++
> and against the Python it ports: still decode (bit-exact), grade, HDR10/HLG,
> metadata sidecars, EXR/ACES/OCIO (byte-identical), `rudra-native master`
> (the Studio master within 1 half-float ulp, no Python), QC (same report
> text), the batch queue (state byte-identical and resumable from either
> side) and sequence open. Found on the way: the Python wrote its sidecars,
> OCIO config and queue state with the platform's line ending, so the same
> master had different bytes on Windows; they now write LF everywhere. The
> Phase 1 exit waits on CI green on three OSes and the Mac runs from Phase 0.
>
> **23 Sep 2026, native app: Phase 0 go/no-go (line F).** The two questions
> Phase 0 had to answer (docs/NATIVE_ARCHITECTURE.md section 12), measured on
> an RTX 4080 SUPER under Windows 11 with an ASUS PA279CRV in HDR:
>
> - **Gate A, does C++ compute what Python computes?** Yes, on every Windows
>   backend: LibTorch CPU 1.2e-7 (bound 1e-5), LibTorch CUDA 1.4e-5 in true
>   fp32 (TF32 was costing 4e-4 and is now off; `gpu_fp32` bound 5e-5 +
>   1e-5|ref|), ONNX Runtime CPU 5.8e-5 and DirectML 3.3e-6 (bound 3e-4 +
>   1e-4|ref|). The composite, master chain to AP0 and every measurement match
>   the Python stage by stage (35 native tests).
> - **Gate B, does HDR reach the glass?** Yes: D3D12 scRGB and D3D11 scRGB
>   carry 203, 1 000 and 2 000 nits exactly, D3D12 HDR10 to within 10-bit PQ
>   quantisation; Windows reports the output as G2084/P2020. The composite
>   shader matches `composite.cpp` on D3D12, D3D11, Vulkan and OpenGL (fp16
>   within 1 half-float ulp).
> - **Budgets:** composite 0.11 ms at 1080p and 0.51 ms at 4K (budgets 4 and
>   12 ms); inference 150 to 172 ms at 1080p fp32 untiled.
>
> **Decision: GO for Phase 1 on Windows.** macOS is GO on condition of three
> runs on an Apple Silicon Mac with an XDR panel, none of which needs new code:
> Gate A on MPS and Core ML, Gate B on Metal EDR, the composite parity on
> Metal (`scripts/native_gate_a.sh`, `scripts/native_gate_b.sh`). Linux ships SDR-out
> first; its composite already passes on OpenGL. Still open and not blocking:
> the 429-frame bench through Gate A (`NATIVE_GATE_A.ps1 -BenchDir`), Tracy,
> and a reduced-precision inference path. Phase 1 (decode, engine, the viewer
> in the Qt shell) starts from `native/` on the `native` branch.
>
> **22 Sep 2026 — dataset audit (line E).** What was done since 16 Sep, checked:
>
> - Sources moved to `G:\datasets\sources` (`pipeline/migrate_datasets_to_g.ps1`);
>   `E:\source_hdr` is a junction. `scripts/BUILD_CORPUS_V4.ps1` re-ingests at 0 EV
>   through the pipeline path into **`G:\datasets\corpora\corpus_v4b`**: 20,628
>   records, 783 train scenes, **check 3b passes at 29.3%** (the shipped corpus
>   was 0.57%), check 8 passes with 12 train + 2 held-out video scenes, check 9
>   WARNs (2% of targets above 40,000 nits; left at `max_hdr=4.0` on purpose).
>   The smoke run on it reads `corpus_ev 0.0` and a step-0 baseline of 48.99 dB
>   clean `psnr_log`. The corpus is sound. `docs/TRAINING_STEPS.md` has the run.
> - **Three checkpoint runs are invalid and quarantined** in
>   `checkpoints/_invalid_corpus_v4/` (README inside): `sdr2hdr_image_v4` (70k
>   steps), `sdr2hdr_image_v4_gate` (8k) and `sdr2hdr_temporal_v4` (111 steps,
>   stopped). The first two trained on the *first* `G:\corpus_v4` — old ingest,
>   no sidecars, so `corpus_ev -1.0` over a 0 EV render — and their "+13.9 dB
>   clean gain" is the baseline's one-stop error, learned (that baseline reads
>   25 dB; on v4b it reads 49). The temporal run took the invalid image model
>   over the 0 EV clips, and nothing stopped it because the video manifest never
>   carried `tonemap_ev`: `corpus_ev_of` fell back to -1 EV and agreed with the
>   wrong checkpoint by accident.
> - **Fixed, each with a test in `tests/test_temporal_corpus_ev_2026_09_22.py`:**
>   clips carry `tonemap_ev` and a sidecar path; `corpus_ev_of` reads a clip
>   row's sidecars (v4b's existing video manifest needs no rebuild); temporal
>   training exits when the image checkpoint's `corpus_ev` is not the manifest's;
>   `build_manifests.py --hold-out-scenes` pins a previous manifest's test scenes
>   to test, matched on the drive-independent tail of the id, so the paper's 429
>   frames stay held out of anything trained on v4b (`scripts/BUILD_CORPUS_V4.ps1
>   -Manifest` passes it by default); `.gitignore` stops `checkpoints/*/` and
>   `/bench/` — 816 MB of step checkpoints and exported bench PNGs were staged.
> - **Not done, now measurable:** the out-of-generator condition is exported
>   (`bench/oog`, 429 frames from `sdr2hdr_shadow_v1.pt` on the v3 test split;
>   Hable + H.264 CRF 28) but not scored. The synthetic-clip protocol
>   (`measure_clipping.py --score` on 0/+1/+2 EV re-renders) is still the only
>   measurement of the highlight claim and has not been run.
> - **`rudra deliver` failed every encode on FFmpeg 7.x** (found 23 Sep on the
>   Windows box): swscale's `out_color_matrix` takes `bt2020`; `bt2020nc` is the
>   tag's name and 7.x rejects it as an undefined constant. 4.4 (CI) accepted
>   it, so CI was green. Filter now gets `bt2020`, tags stay `bt2020nc`;
>   verified on 4.4.2 and 7.0.2, pinned by a test.
> - Repo root organised: one-shot commit/push scripts → `scripts/archive/`
>   (git-ignored), dated reports → `reports/`, `scripts/AUDIT_REPO.ps1` kept.
>   `codex/rudra-final-release` (20 Sep, +2,309 lines: batch/video delivery,
>   quality benchmark, recovery ablation, finetune scripts, 14 test files) is a
>   worktree branch off 6 Sep and has not been reviewed or merged; nothing here
>   depends on it.
>
> **23 Sep 2026, 02:00 — Step 4 ran.** Launched on v4b at 21:51 (manifest
> `ffcd8bbb…`, before the hold-out rebuild), `corpus_ev 0.0`, 50k steps in
> 4 h 08 min. `best.pt` = step 36,000: **+1.80 dB clean, +0.82 dB hard**
> `psnr_log` over its own analytic baseline (25.29 / 19.96 dB). Both signs
> positive, which v5 never managed. Acceptance waits on
> `pipeline/check_holdout_overlap.py`: if any of the paper's bench scenes are in
> this run's train split it is retrained on the rebuilt manifest (4 h), and
> `scripts/next_steps_2026-09-22.ps1` does that decision by data.
>
> **23 Sep 2026, 17:26 — v4c is the research (non-commercial) corpus**, HdM
> included, at `G:\datasets\corpora\corpus_v4c`; one model, `sdr2hdr_image_v4c`.
> The commercial build waits for more clean real footage (FXTD, LIVE-TMHDR).
> Checked on G: first: all 52,772 inventory sources resolve after the move;
> Sparks' duplicate P3-PQ rendition (13,777 files) is dropped; ACES scaled
> 1.0 = 100 nits (measured 55-91 against the PQ grade); Poly Haven venice_* /
> stuttgart_* no longer read as S-Log3 / PQ / HdM. liu_hdrv and pandora are
> still zip archives (pandora partly .part) and are not in any inventory.
>
> **23 Sep 2026, 17:00 — critical path built, running on the box.**
> `scripts/RUN_CRITICAL_PATH.bat` runs N1 → N2 + N3 → N7 unattended with
> gates and resume markers (`reports/logs/cp_*`). What is in the code now:
>
> - [x] **N2** `pipeline/sdr_render.py` + `prepare_pairs.py --sdr-render mix`:
>   six curves (ACES, Hable, Reinhard, AgX-like, camera log→709, clip), ±1.5 EV,
>   contrast/saturation/OETF jitter, JPEG/H.264/HEVC/AV1 round trips, one
>   recipe per shot, recorded per pair. ACES path bit-exact with the old render.
> - [x] **N3** `rudra.sdr2hdr.CurveHead` (`--curve-head`): per-frame exposure +
>   8-knot log2 correction of the analytic inverse, zero-init (identity), one
>   curve per frame under tiling, the same maths in the Studio shader
>   (`uCurve[9]`), gain still scored against the *analytic* baseline.
> - [x] **N7** `pipeline/licences.py`: every manifest row carries
>   `licence_source` / `commercial_ok`; `build_manifests.py --commercial-only`
>   is the rudra-studio corpus (HdM and unclassified sources out).
> - [x] Sparks: ACES 2065-1 EXRs now decode AP0 → Rec.2020 (`aces` encoding);
>   `pipeline/reclassify_inventory.py` applies it without a rescan.
> - [x] `training/paired_gate.py`: paired Δ, bootstrap CI, pass/fail.
> - [ ] Runs: v4c ingest, v4c research + studio training, benches (hours).
> - [ ] N8 desktop app: its plan moved to native Qt/C++ in `d427bec` (another
>   session); not touched here.
>
> **CPU proxy for N3 (mechanism check, not a result).** 97 bench scenes at
> 192×108, 70 train / 27 test, 12-channel model, ~900 steps. psnr_log, model
> vs analytic inverse, per test curve: with the curve head Hable **31.4 vs
> 29.8**, AgX **35.3 vs 33.4**, camera-log **33.4 vs 30.7**, clip **30.1 vs
> 27.3**; without it +0.4/+0.9/+0.6/−0.4. **But on the corpus's own ACES render
> it falls to ~31 vs 49**: from one frame it cannot tell ACES from the mix
> and applies an average correction. The real run decides whether 25% ACES in
> the mix teaches it to recognise the curve; the `aces` bench in CP7 measures
> exactly this. If it doesn't, the fix is a confidence output that falls back
> to the analytic inverse, not dropping the head.
>
> **23 Sep 2026 — scope.** RUDRA is SDR→HDR for any image or video from any
> source, pixel-domain. Lines A and B are paused (they only work inside
> specific latent models). Plan, competitive read and what is against us:
> `reports/SDR2HDR_PLAN_2026-09-23.md`.
>
> **Out-of-generator bench scored (23 Sep).** 429 frames, Hable curve + real
> H.264 CRF 28, shipped `sdr2hdr_shadow_v1.pt`: RUDRA **26.77 dB PU21 / 8.114
> JOD vs baseline 27.18 / 8.139**, paired Δ −0.41 dB (95% CI −0.49…−0.34),
> −0.024 JOD (−0.048…−0.003); worse on 270 of 429 frames. On SDR made by a
> curve and codec it never trained on, the shipped model is worse than
> doing nothing learned. This is now the top item.
>
> **23 Sep, 16:00 — hold-out check answered.** 97 of 97 paper-bench scenes are in
> v4b; 96 were already in test, **one (`fireplace`, 348 records) was in train**.
> The overnight Step 4 run trained on it, so it is not held out on the old
> bench and is retrained on the rebuilt manifest (4 h). Evidence:
> `reports/logs/ns_2_overlap_original_manifest_ffcd8bbb.json`.
>
> The rebuild then failed check 7 on test (largest scene 30.4% vs 25%):
> `cap_scene_share` sized each dominant scene against the total as it stood,
> so thinning `fireplace` after `carousel_fireworks` pushed carousel back
> over. It now caps all dominant scenes jointly and re-checks the result.
>
> **Next steps, in order. Each has the gate it must pass before the next.**
> *(`scripts/RUN_NEXT_STEPS.bat` runs 1, 2, 6, 3 and 5 unattended with markers in
> `reports/logs/`; re-run it after each training window.)*
>
> 1. **Push the 22 Sep batch** — `scripts/finalize_2026-09-22.ps1` (pytest, then
>    one commit, then push). Gate: CI green; `git ls-files checkpoints/` shows
>    only root-level weights.
> 2. **Rebuild v4b manifests with the hold-out** — `scripts/BUILD_CORPUS_V4.ps1 -Manifest
>    -Verify` (no re-ingest; minutes). Gate: the hold-out line reports > 0 scenes
>    pinned, `verify_dataset.py` exits 0 with 3b still passing, and test's
>    largest-scene share stays ≤ 25%. If the hold-out pushes test over the cap,
>    raise `--test-frac`, not the cap.
> 3. **Step 4 — image model on v4b** — ran 22–23 Sep (above). Gate: the run's
>    manifest is the rebuilt one, or the overlap check finds no old bench scene
>    in its train split; otherwise retrain (4 h). `config.json` must read
>    `corpus_ev 0.0` (it does). Note the 49 dB smoke baseline was a 40-item
>    subset; the full val baseline is 25.3 dB clean, and that is not a defect.
> 4. **Step 5 — the conditioning head**, from item 3's `best.pt`, 8k steps.
> 5. **Step 7 — acceptance on the paper's bench**, re-exported from the *same*
>    429 reference frames at 0 EV (`export_bench_pairs.py` from the v4b manifest's
>    test rows once step 2 has pinned them; `clean`, `hard`, and
>    `out-of-generator`). Score v5, shadow_v1 and the v4b model each against the
>    render it was trained to invert. Then `measure_clipping.py --score`. Gate:
>    RUDRA beats the analytic inverse on clipped pixels in stops; if it ties to
>    the digit again, corpus content was not the constraint — write that down and
>    stop the corpus programme.
> 6. **Score `bench/oog`** with the shipped `sdr2hdr_shadow_v1.pt` now (no GPU
>    time to speak of) and put the row in `docs/RESULTS.md`; it answers the
>    review's "one out-of-generator degradation" today, before any retrain.
> 7. **Step 6 — temporal on v4b**, only after 3 and 5, and only because check 8
>    passed. Line D closed on a rendered corpus; 12 real video scenes with real
>    parallax is the one thing STATUS said would reopen it. Kill it if the first
>    three evals do not beat the step-0 baseline.
> 8. **Promote or drop.** A v4b `best.pt` that passes step 5 is copied to
>    `checkpoints/` under a release name with `SHA256SUMS` and `models.json`
>    updated; `sdr2hdr_temporal_v1.pt` ("Unevaluated") and v6 (4× capacity, no
>    gain) get measured or pulled from `models.json` in the same commit.
> 9. **Sparks scale — cause found, fix in, corpus not yet rebuilt (23 Sep).** The
>    Sparks download is ACES EXRs under `netflix_sparks/`; `scan_sources.py`
>    matched the PQ keyword "netflix" before looking at the container, so
>    scene-linear values were decoded as PQ codes and 1,799 pairs "peaked below
>    1 nit". A float container is now linear regardless of dataset name (camera
>    log names still win); `tests/…_2026_09_22.py` pins it. Verify on the box:
>    `python pipeline\scan_sources.py G:\datasets\sources\netflix_sparks --out
>    reports\logs\sparks_inventory.jsonl` and read `encoding_guess` and
>    `peak_nits_estimate` (expect thousands of nits). Then a **corpus_v4c**
>    re-ingest with Sparks in, before the `rudra-studio` (no-HdM) retrain. Not
>    before this run's acceptance: one variable at a time.
> 10. **`codex/rudra-final-release` merged to main on GitHub (PR #1, `205b19b`).**
>     The review (`reports/CODEX_BRANCH_REVIEW_2026-09-23.md`, local) still
>     stands as a to-do list against what is now in main: `rudra/video.py`
>     duplicates `rudra deliver` and converts input to Rec.2020 before the
>     network; `quality_benchmark.py` / `recovery_ablation.py` /
>     `assess_finetune.py` score the analytic baseline at the legacy −1 EV;
>     `master_targets` writes EXRs to any absolute folder a request names.
>     **Fixed on integration (23 Sep):** the merge (`869ecfa`) left
>     `_render_master` resizing an undefined PIL `image` around main's
>     full-depth `decode_sdr`, so every Studio master raised
>     `UnboundLocalError`; it now uses `_fit(decoded.rgb, master_max_side)`
>     (0 = full resolution). Suite on the merged tree: 498 passed on
>     FFmpeg 8.0.1. `rudra/video.py`'s QC needs ffprobe ≥ 5
>     (`frame_side_data`).
>
> **The paper (kept out of this repository) is about line C.** It is not
> the earlier manuscript, which was about line B; what was withdrawn from that
> one and why is Appendix D of the paper. Line B's
> completion path is unchanged and is listed below; nothing since 22 Aug has
> advanced it.
>
> **Line C, as of 1 Sep 2026:** v5 (1,196,197 parameters) benchmarked on 429
> held-out frames — **+1.43 dB PU21-PSNR and +0.44 JOD on degraded input, 348 of
> 429 frames**; **-3.0 dB / -0.046 JOD on clean input**. Failure mode located
> (error correlates +0.46 with scene headroom), oracle bound measured (+5.84 dB
> clean), and that bound shown to be mostly unreachable from an 8-bit input
> (features explain 3% of the oracle scale's variance; 79% of its variance is
> within-condition). Capacity (4x), corpus (6x) and objective were each varied;
> none moved the bound. Three evaluation-harness defects found and fixed:
> selection on a noisy maximum, an eval reading the alphabetical front of the
> split, and a viewer presenting every frame upside down.
>
> **Line C, done since:** ExpandNet run from the authors' released weights on
> the same 429 frames (−18.56 dB, −2.03 JOD, 1 frame won on PU21 and 16 on
> CVVDP); the shadow gate scored on three seeds (+0.41 ± 0.33 dB clean,
> +1.12 ± 0.15 dB hard); `step_0072000.pt` scored, confirming the selection fix
> picks it and that it is better on the criterion the selector optimises and
> worse on CVVDP in both conditions; the LaTeX build, the arXiv package and the
> committed PDF. Related work cited (9 references + 4 standards); no `[CITE]`
> markers remain.
>
> **Line C, 16 Sep 2026 review (engineer / colourist / researcher; the full
> text is local, `reports/FINAL_REVIEW_2026-09-16.md`).** Fixed the same day, each
> with a test in `tests/test_review_fixes_2026_09_16.py`:
>
> - `rudra deliver` encoded **BT.601 chroma under a bt2020nc tag** — swscale's
>   default matrix; `-colorspace` only labels. Reproduced on ffmpeg 6.1 (red at
>   PQ' 0.75 → Y' 1044 where BT.2020 is 946). Fixed with
>   `-vf scale=out_color_matrix=bt2020nc`. **Anything delivered before this
>   date should be re-encoded.**
> - HLG export skipped the inverse OOTF (diffuse white −0.46 st, 18% grey −0.96 st).
> - `deliver` clipped at 10,000 nits and wrote MaxCLL from those pixels, so SDR
>   white (2,552 nits from the baseline) exceeded a 1,000-nit MaxMDL. It now
>   shoulders into the declared peak (hue-preserving) and measures after.
> - Rec.709 masters were labelled Rec.2020 everywhere: the Studio's ACES path fed
>   709 primaries to the 2020→AP0 matrix, the linear EXR carried no
>   chromaticities, and both CLI defaults were `rec2020`. Default is `rec709`
>   now; the linear container converts and says so in its header.
> - The Studio bound 0.0.0.0 and would `torch.load(weights_only=False)` any path
>   a request named. Loopback by default (`--host` to widen), checkpoint
>   overrides limited to the registry and `RUDRA_CHECKPOINT_ROOTS`, 256 MB body
>   cap.
> - `infer_sdr2hdr.py` ran the shadow gate per tile (seams in tiled masters) and,
>   untiled, from full-resolution features it was never trained on; the paper's
>   bench went through this path. One whole-frame weight now, as the Studio
>   does. **The bench should be re-run**; `--recovery-mode` defaults to `all`,
>   which is what was scored.
> - `tonemap_ev` was written by the corpus builder and read by nothing, so the
>   next training run would have built the model against the legacy −1 EV
>   baseline over a 0 EV corpus. It now travels manifest → `corpus_ev` in the
>   checkpoint config → frame header → compositor uniform. Phase 0 of the
>   runbook is closed.
> - Playback ran at 24 fps for every shot (`fps` was never sent); `theme.css`
>   and `shell.js` were not cache-stamped; `paper/mdtotex.py` failed the
>   fresh-clone test and is gone.
>
> **Line C, 18 Sep 2026 — the Studio is an instrument, not a dark web app.**
> Neutral surround (every grey R = G = B; a tinted one biases colour
> judgement), the titlebar folded into the menubar, the scopes moved out from
> under the viewer into a full-height right-rail column and joined by a
> vectorscope, a permanent probe readout in the left rail with the largest
> figures on the page, a measured `Frame` block that reports the share of
> pixels the SDR actually clipped beside what the network chose to act on,
> timecode on the transport, and a colour pipeline bar across the bottom that
> names all four transforms and warns when MaxCLL is over the view peak.
> Every existing element id was kept, so `compositor.js` is untouched.
> `tests/ui_smoke/press_everything.py` now runs 72 checks, 0 failed, console
> clean — eight of them new, and two assertions fixed that had been stale
> since the pannable viewer landed (zoom stopped being a class on the viewer)
> and were failing before this change too.
>
> **Still open from the review, in order:** the synthetic-clip protocol
> (`measure_clipping.py --score` on 0/+1/+2 EV re-renders — the only measurement
> of the highlight claim); one out-of-generator degradation beside "hard"
> (**code now in `export_bench_pairs.py --condition out-of-generator`** — a Hable
> curve + real H.264; the measurement is still to run);
> per-shot smoothing of the gate, anchor and chroma scalars; a BT.1886 input
> option and a conforming baseline (a retrain — belongs with the corpus
> programme); an ExpandNet row on the hard condition; §4 provenance and the
> weights licence in the paper.
>
> **Line C remaining:** nothing measurable. The blockers are the arXiv
> endorsement (a person has to say yes), the HuggingFace upload, and the
> weights licence below. Section 10 still declares two gaps honestly: three
> published methods have runnable code and have not been run, and §6's
> trimmed-PSNR table and §7's oracle sweep have no script because they need
> per-pixel statistics the benchmark does not write.
>
> ---
>
> **Line D — v02, the temporal track (opened 4 Sep 2026).** The v01 video corpus
> is 935 clips across **13 scenes**, which is why the temporal refiner is
> reported as unevaluated. `pipeline/render_hdri_moves.py` flies a virtual
> camera through the CC0 Poly Haven panoramas, one panorama being one scene:
> the corpus is now **993 scenes, 17,874 frames, 128 GB**.
>
> Three things were measured before any model was trained, in the shape of §7:
>
> - `TemporalHDRRefiner`'s receptive field is **±4 frames, ±4 pixels**, measured
>   by gradient, against **4.3–27.3 px/frame** of camera motion. It cannot fetch
>   a value from where the content was; it can only smooth. Retraining it is the
>   control, not a candidate.
> - Scoring per frame is **blind to flicker by construction**. Two clips with an
>   identical 0.0600 relative error on every frame score 10.000 and 10.000
>   per-frame, and 10.000 and 5.111 as clips. `hdr_vdp3_clip_jod` runs
>   ColorVideoVDP in video mode; `rudra/pose_warp.py` adds a temporal
>   consistency measure with no flow estimator in it, ground truth against
>   itself sitting at 0.0145 stops.
> - **The gate.** `training/gate_temporal_oracle.py`. On clean frames the
>   per-frame model already scores 9.972 JOD of 10, so nothing can be won and
>   the run says nothing; the gate has to be read on `--condition hard`.
>
> **The gate failed, and then said why (5 Sep 2026).** The 4 Sep reading of
> **+9.31 JOD achievable** does not survive. Two faults produced it, and both
> are fixed:
>
> - It scored a **bare `model(x)` forward pass**, not RUDRA as deployed. The
>   benchmark runs `predict_image(preserve_outside=True)`, where outside the
>   learned masks the output *is* the analytic baseline. That is why the floor
>   sat at −1.96 JOD against the benchmark's 7.805 on the same checkpoint and
>   the same 1280×720 frames — it was never a crop-size or resolution
>   mismatch.
> - `degrade_like_eval` **reseeds from the frame index**, so every frame of a
>   nine-frame clip got its own exposure, tone curve, white balance,
>   saturation, chroma subsampling, bit depth and JPEG quality. Averaging nine
>   independent draws of a corruption is worth √9 whether or not the frames
>   carry information. `--degradation {per-frame,per-clip,realistic,codec}`
>   makes that assumption a flag; `codec` puts the clip through a real H.264
>   round trip and is the one with a GOP in it.
>
> | degradation | clips | per-frame | achievable | ceiling |
> |---|---|---|---|---|
> | `per-frame` (4 Sep) | 2 | −2.396 JOD | **+9.397** | +9.408 |
> | `realistic` | 40 | 6.961 | **+0.033** | +0.191 |
> | `codec` | 40 | 6.864 | **+0.034** | +0.165 |
>
> Against a +0.5 JOD threshold, **the gate fails** — and even the unreachable
> bound (omniscient per-pixel selection over exactly aligned neighbours)
> reaches only +0.19.
>
> **That is a fact about the corpus, not about video.** `make_sdr` tone-maps
> every frame with one fixed curve and one fixed EV offset, and the renderer's
> camera only rotates through a static panorama — so a scene point carries the
> **same SDR code in every frame it appears in**, and what is blown in frame 3
> is blown in frame 7. The corpus contains none of the information v02's claim
> is about. `--exposure-drift` and `--exposure-jitter` put that axis back
> (defaults 0.0; the `_ingest_config` sentinel refuses to mix a drifted render
> into the existing 993 scenes).
>
> **The gate passes once exposure moves (6 Sep 2026).** 50 panoramas rendered
> twice with `PYTHONHASHSEED=0` — identical camera paths (checked to 1e-9),
> identical H.264 degradation, the SDR exposure the only difference. Scene
> list in `_gate50_scenes.txt`.
>
> | exposure | per-frame | achievable | ceiling |
> |---|---|---|---|
> | constant | 6.209 JOD | +0.110 | +0.264 JOD / +0.632 dB |
> | ±0.48 stops | 5.786 | **+0.511** | +0.851 JOD / **+4.554 dB** |
>
> **+0.511 against a +0.5 threshold, with the fixed-exposure control at +0.110
> on the very same scenes and camera paths.** The PU21 ceiling is the clearer
> signal: +0.63 dB without exposure movement, +4.55 dB with it.
>
> **Repeated on three seeds (6 Sep 2026, `training/run_drift_gate.ps1`, on the
> 4080):**
>
> | seed | flat | drift | drift ceiling | clips |
> |---|---|---|---|---|
> | 20260903 | +0.110 | +0.511 | +0.851 | 50 |
> | 20260906 | +0.035 | **+0.603** | +1.090 | 40 |
> | 20260907 | +0.046 | **+0.661** | +1.142 | 40 |
> | **mean** | **+0.064** | **+0.592** | +1.028 | |
>
> **The result holds.** Every drift arm clears the threshold; every flat arm
> is an order of magnitude below it. The ~+0.53 JOD separation between arms is
> far larger than the spread across seeds, which is what makes this a result
> rather than a run. The hypothesis behaves exactly as stated — a neighbour is
> worth something when it saw the scene at a different exposure and close to
> nothing when it did not.
>
> Two things travel with it. The 40 in the later rows is a defect:
> `stage_oracle_clips` defaulted `--count` to 40 and the sweep passed none, so
> those seeds used the first 40 of the 50 scenes — the *same* 40 in both arms,
> so each pairing is intact, and the default is now 0. And drift makes the
> per-frame job harder (6.209 → 5.786 on seed 20260903), so part of the gain
> is repairing damage the drift itself did; the oracle ceiling separates the
> two, and +0.26 JOD flat against +0.85 drift is information that exists to be
> fetched, not merely damage to undo.
>
> What it licenses is narrow: a proposition about footage whose exposure
> breathes — handheld, documentary, anything riding auto-exposure — not about
> video in general.
>
> **And then estimated alignment took it away (6 Sep 2026).** Every number
> above used the camera angles the renderer wrote down. A plate has none, so
> the same 50 drifted clips were re-scored with the correspondence estimated
> by DIS optical flow from the degraded SDR — what a deployed model holds:
>
> | arm | per-frame | control | aligned | oracle | **achievable** | ceiling |
> |---|---|---|---|---|---|---|
> | pose (exact) | 5.786 | 5.835 | 6.296 | 6.687 | **+0.511** | +0.851 |
> | flow (DIS) | 5.786 | 5.844 | 5.802 | 5.839 | **+0.016** | −0.005 |
> | flow + texture gate | 5.786 | 5.828 | 5.658 | 5.514 | **−0.128** | −0.314 |
>
> **Read the ceiling column.** Under estimated alignment the *oracle* — ground
> truth consulted per pixel, better than any architecture or weighting could
> ever do — beats the per-frame model by +0.053 JOD, while the control, which
> carries no information at all, beats it by +0.058. The oracle's whole margin
> is selection on resampling noise. **There is no headroom left to build for.**
>
> The alignment is not visibly bad, which is what makes this worth stating
> carefully: DIS matched the analytic poses to a median 0.04 px at one frame
> of separation and 0.09 px at eight, coverage within 1%, warped frames
> agreeing to under half an 8-bit code value. PU21-PSNR keeps 75% of the gain
> (+0.326 of +0.435 dB). The JOD keeps 3%. What survives a per-frame PSNR and
> not a video metric is a small, spatially coherent error that changes every
> frame — the exact artefact a temporal model exists to remove.
>
> Where it fails is legible: the six worst clips are open sky, the four best
> interiors. On the sky scene flow error in low-texture regions is **1.35 px
> against 0.15 px** in textured regions of the same frame, and
> forward-backward consistency passed **57%** of those bad pixels, because in
> a flat region any displacement round-trips perfectly. Flow fails exactly
> where the highlights are. Gating on texture energy made it worse (−0.128):
> a hard mask leaves nine-frame averaging beside one-frame averaging with a
> seam between them. A softer weighting is not worth trying — the oracle row
> bounds every weighting there is.
>
> **The learned estimator, and the close (10 Sep 2026).** DIS is a fast
> classical estimator, so the flow arm was re-run with RAFT-large — markedly
> better in exactly the low-texture regions where DIS failed, 0.35 px against
> 2.61 px on an open-sky clip. Seed 20260906, 40 drifted clips, same clips
> every row:
>
> | arm | per-frame | aligned | oracle | **achievable** | ceiling |
> |---|---|---|---|---|---|
> | pose (exact) | 5.925 | 6.528 | 7.063 | **+0.603** | +1.090 |
> | flow (DIS) | 5.925 | 5.856 | 6.115 | **−0.069** | +0.122 |
> | flow (RAFT) | 5.925 | 6.266 | 6.659 | **+0.341** | +0.671 |
>
> RAFT recovers 57% of what exact poses give and **misses the threshold** —
> +0.341 against the +0.5 set before any of this was measured. Not the flat
> zero DIS gave: the ceiling moved from +0.122 to +0.671, so there was room a
> better combiner might have reached.
>
> One combiner was declared and tried, *before* it was run — weight each
> neighbour by its forward-backward residual instead of averaging equally.
> On the same clips: **mean +0.351, confidence +0.350.** Nothing.
>
> The reason is the same wall from a third angle. RAFT's forward-backward
> drift is 0.04–0.09 px on nearly every pixel that passes, so the weight is ~1
> everywhere and the signal has no dynamic range. **The failures are not
> low-confidence matches — they are confident wrong ones**, in flat regions
> where any displacement round-trips perfectly. That is precisely what
> forward-backward consistency cannot see, and therefore what weighting by it
> cannot fix.
>
> **Line D is closed.** Three alignment arms and two combiners against a
> threshold fixed in advance: exact camera poses clear it, nothing a plate can
> supply does. The +0.603 belongs to the renderer's angles. No temporal model
> was trained because there is nothing measurable for one to learn — **that is
> the result, not the absence of one**, and it is worth more than the month it
> would have taken to find out the other way.
>
> The corpus re-render, the architecture ladder and the video split are off
> the board. What would reopen it is a corpus whose neighbouring frames carry
> information these do not — real parallax, moving subjects, genuine
> multi-exposure capture — not a better estimator and not a better
> architecture. The gate would have to be re-run from scratch on it.
>
> **The shadow gate is settled, and it stays (10 Sep 2026).** It was proposed
> for retirement on the strength of three checkpoints agreeing to 0.07 nits on
> ONE frame. `training/compare_bench_methods.py` answers it properly from the
> 429 held-out pairs already scored under `bench/results/` -- paired per frame,
> bootstrap CI, and measured against the spread between the three gate SEEDS,
> because an effect smaller than retraining noise is not an effect:
>
> | condition | metric | gate effect | worst seed-to-seed | verdict |
> |---|---|---:|---:|---|
> | hard | CVVDP | **+0.218 JOD** | 0.081 | 2.7x seed noise |
> | hard | PU21 | **+0.796 dB** | 0.278 | 2.9x |
> | clean | CVVDP | **+0.107 JOD** | 0.045 | 2.4x |
> | clean | PU21 | −0.103 dB | 0.645 | within noise |
>
> All three seeds clear zero with 95% CIs excluding it on three of four
> measures. The gate stays; the one measure it does not help, it does not hurt
> beyond noise. No GPU time was spent -- the files were already on disk.
>
> **Still open, neither a training run:** `sdr2hdr_temporal_v1.pt` ships in
> `models.json` marked *"Unevaluated"* and belongs to the closed line — pull
> it or measure it. And v6 (4× capacity, moved neither condition) is a keep
> or drop.
>
> ---
>
> **Licensing (24 Sep 2026).** The code is now **non-commercial** too, under the
> PolyForm Noncommercial License 1.0.0 (`LICENSE`, with the Required Notice in
> `NOTICE`); commercial use of code or weights needs a licence from FXTD
> Studios. Copies obtained before 24 Sep keep Apache 2.0.
>
> **Licensing (5 Sep 2026).** The code was Apache 2.0. The **weights are not**:
> HdM-HDR-2014 and HdM-HFR-2017 are **75.6% of the training corpus** and are
> free for academic use only, with commercial use requiring a separate
> agreement with HdM Stuttgart. `checkpoints/LICENSE` now licenses the weights
> non-commercially and `NOTICE` carries the Netflix Chimera CC BY 4.0
> attribution. Academic use is permitted, so **the paper is unaffected**.
>
> The intended resolution is two model families: `rudra-research` as it stands,
> and a `rudra-studio` retrained without HdM — Netflix Chimera (14.3%, CC BY,
> median peak 7,094 nits) plus Poly Haven (10.1%, CC0) plus the 17,874 rendered
> frames plus FXTD's own footage, which is comparable corpus volume with the
> high-nit end covered. That retrain depends on nobody's permission.

---

Snapshot of what is trained, with measured values, and what remains for the paper.

## Production decoders (ComfyUI node) — ✅ complete

Distilled `RadianceTurbo/FullDecoder` (`fast_vae.py`), trained by
`training/train_turbo_decoder.py`. Metric: log-space PSNR on held-out pairs.

| Backbone | Decoder used | PSNR_log | peak step | pairs |
|---|---|---|---|---|
| Flux.1 | **full** | 29.77 | 26k | 12,281 |
| Wan | **full** | 32.45 | 16k | 13,227 |
| SDXL | **turbo** | 33.86 | 18k | 963 |
| Qwen-Image | **turbo** | 26.67 | 20k | 963 |
| Flux.2 Klein (128ch/16×) | **turbo** | 28.57 | 18k | 963 |
| Z-Image | use Flux decoder | — | — | (Flux VAE) |

Turbo also exists for flux/wan/sdxl; the table lists the *best* per backbone.
Notes: SDXL/Qwen/Klein are on 963 pairs (data-starved) — regenerate multi-crop pairs to
lift them. Full is slow on 64×64-latent backbones (decodes at 512×512). Always deploy the
`*_decoder_ema_best.safetensors`.

## RUDRA research pipeline (the paper) — partial

`rudra/` package + `training/train_rudra.py`, Stages 1–3.

| Paper stage | Status | Measured value | Blocker / next |
|---|---|---|---|
| **Stage 1** — RUDRA-Lite descriptor + FiLM decoder (§3.6) | ✅ flux/wan @ 50k | ColorVideoVDP **JOD 9.0–9.2**, PSNR_tm ~25–26, EV-error ~0.05 stops, HRA ~0.18 | done |
| **Stage 2** — DR-gated LoRA (RUDRA-Lite conditioning) | ⚠️ partial (400 steps) | — | Flux-16GB OOM; runs on SDXL or 256px pairs |
| **Stage 3** — DRE transformer + cross-attention injection (§3.4–3.5, *core thesis*) | ❌ not trained (dryrun only) | — | run on **SDXL** (`research_sdxl.py --phase stage3`) |
| §7.1 component ablation | ❌ TBD | — | derived from Stage 1→3 runs |
| §7.2 descriptor channel ablation (L / L+E / L+H / L+xy / full R⁵) | ❌ TBD | — | `research_sdxl.py --phase ablate` |
| §7.3 λ conditioning-strength sweep (0.0 … 1.25) | ❌ TBD | — | `research_sdxl.py --phase sweep` |
| §6 results vs external baselines | ❌ TBD | — | `benchmark_hdr.py` + ColorVideoVDP |
| §8 qualitative grids / EV-over-time | ❌ TBD | — | after the above |

## Completion path

1. **Stage 3 on SDXL** — the paper's intended backbone (U-Net cross-attention; ~5× lighter
   than Flux, fits 16 GB). This is the core contribution. `research_sdxl.py --phase stage3`.
2. **λ sweep + descriptor ablation** — `--phase sweep` and `--phase ablate` (short runs).
3. **Benchmark** RUDRA vs external baselines with ColorVideoVDP (JOD), ΔE2000, EV-error, HRA.
4. **Fill the paper tables** (§6/§7) with the measured values; drop the placeholder numbers.
5. *(Optional)* Flux port of the conditioning — the paper's §10 generalization experiment.

## Code health

All P0/P1/P2 review items closed. Real HDR metric is
ColorVideoVDP (`rudra/hdrvdp.py`); the old hand-rolled "HDR-VDP-3 ≈ 80" numbers were a
placeholder and must not be reported. `pytest tests/` covers curve round-trips, the freeze
guarantee, conditioning, and the metric backend.
