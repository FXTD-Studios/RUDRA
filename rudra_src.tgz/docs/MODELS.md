# RUDRA models: licence and status

One table for every model RUDRA has published. The README, the Hugging Face
model card, the user guide and `models.json` must say the same thing; if they
disagree, this file is the one to correct them from.

Updated 12 November 2026 (RUDRA 1.2.4).

## In the app (downloaded, not bundled)

From 1.0.3 the Windows and macOS packages carry **no model weights**. Each
model below is downloaded in **File › Model packages**, shows its licence
first, and is checked file by file (SHA-256) before use. The analytic
reconstruction, which needs no model, is the default.

| Model | Files (SHA-256) | Licence | Commercial use | Status |
|---|---|---|---|---|
| **RUDRA ACES 2** (2.0, learned ACES 2.0 reconstruction with the lock; needs RUDRA 1.2.0) | `rudra_g1.ts` `7082eb869d265d6e…`<br>`rudra_g1.onnx` `880e7b698a099b8d…` | Apache 2.0 | Yes | **Release** (8 Nov 2026). See "Evidence" below |
| **AI fill v3** (Wan2.1-VACE-1.3B LoRA + brightness estimator) | `rudra_genfill.safetensors` `9fff7eb8492ae626…`<br>`brightness.json` `34892fb840de138f…` | Apache 2.0; base model Wan2.1-VACE-1.3B is Apache 2.0 (Wan-AI) | Yes | **Experimental**, off by default. Passed its pre-registered gates on 25 held-out Poly Haven scenes (30 Oct 2026; `registration_v3.json`, `report_v3.json`) |


Training data for RUDRA ACES 2 and AI fill v3: Poly Haven HDRIs (CC0), FXTD Studios' own footage and
renders, procedurally generated scenes, CC0 plates. No non-commercial data,
and no third-party model code, weights or outputs.

### Which route for which footage (9 Nov 2026)

RUDRA ACES 2 is the exact inverse of the ACES 2.0 SDR output transform: its
master renders back to the SDR you delivered to the code (the lock). That is
the right tool for an SDR that was made through ACES 2.0. On a grade made
another way, with bright areas parked just under white (an open door, a
window, a sky at codes 245-254, no hard clip), the same inverse puts those
areas at 10-20 x diffuse white with the chroma ACES compressed on the way out
re-expanded, and no trim reaches them: Peak limit and Highlight saturation
act inside the reconstructed mask only. Measured on a shot like that: the
analytic route placed the door at 714 nits with its hue (G/R 1.27 against the
source's 1.10), the learned route at 2,691 nits (2.41). From 1.2.1 the app says so in the Learned ACES 2.0 card and on the
Deliver page whenever the Source panel's curve is not ACES, and points at the
analytic route; set the curve to ACES when the SDR was an ACES 2.0 render.

## Not distributed in packages (research and Beta 2)

| Model | SHA-256 | Licence | Commercial use | Status |
|---|---|---|---|---|
| `sdr2hdr_image_v8` | `20130171…` | Non-commercial (`checkpoints/LICENSE`) | No | Retired. **Bundled by mistake in packages built by `release.yml` up to 1.0.2** (confirmed in the published 1.0.1 Windows ZIP; the 1.0.2 tag was never published as a release); not from 1.0.3 |
| `sdr2hdr_shadow_v1` | `6b7f73f0…` | Non-commercial | No | Retired (Beta 2 web app's model) |
| `sdr2hdr_shadow_s2`, `_s3`, `sdr2hdr_image_v5`, `_v6`, `sdr2hdr_temporal_v1` | `checkpoints/SHA256SUMS` | Non-commercial | No | Research only, kept for reproducing the paper's tables |

If you installed 1.0.0 or 1.0.1: the bundled `sdr2hdr_image_v8` is under the
non-commercial licence wherever it is. Update to 1.0.3, or delete the
`models/sdr2hdr_image_v8` folder from the install, before commercial work.

## Evidence: RUDRA ACES 2

**Published before 1.2.0 (1.0, preview):** the checkpoint behind `rudra_g1.ts`
`fb30e3df…` fails the 0 EV grading gate (0.121 against 0.0604, 29 Oct 2026).
Its manifest says `release_authorized: true`, set by hand; no committed report
names its checkpoint. It was replaced on Hugging Face by 2.0 with RUDRA 1.2.0
(8 Nov 2026).

**Published with 1.2.0 (2.0, release): w4 + lock_dqs050g.** The checkpoint
`research_bin_hinge_w4_20261102` step 1600, with the lock (stage 6b,
`training/aces_partial_tighten.py`, native `core/aces_lock.hpp`) at strength
0.5 toward the dequantized source, and the appearance guard.

- **Held-out footage test, run once as registered** (7 Nov 2026, on
  production footage the model never saw in training): passes every gate.
  0 EV RMS 0.311 code against a limit of 0.342 (analytic inverse 0.242 + 0.1);
  −3 EV, +3 EV and highlight colour better than the analytic inverse; no new
  negative luminance; no pixel more than 1 code off.
- **What it does not show:** at the delivered exposure it is *worse* than the
  plain inverse in every case (56 of 56), by less than a tenth of a code. The
  claim is "within 0.1 code RMS of the plain ACES 2.0 inverse at the delivered
  exposure", never "better". One production, one camera (ARRI ALEXA
  LogC3), single frames.
- **Native lock:** bit-exact with the Python oracle on its golden
  (`native/tests/test_aces_lock.cpp`); on real frames through the real view,
  `native/tools/aces_v2_parity` with `--lock`.
- **The package:** contract major 3 (stages plus the lock). Apps before the
  lock (1.1.0 and older) refuse it rather than run the model without its
  lock. It needs RUDRA 1.2.0.

It left preview on 8 Nov 2026 through `tools/promote_aces2_release.py`, which
refuses unless every one of these is on file: the holdout verdict, native
parity with the lock, LibTorch against ONNX Runtime DirectML and CPU, Core ML
(or a stated reason it was not measured), the provenance record
(`docs/models/RUDRA_ACES_2.provenance.json`), and a signed visual review.
`scripts/RELEASE_ACES2_W4.ps1` runs every step that needs no person.

- **Visual review (8 Nov 2026, `reports/aces2_review_2026-11-08_1148`):** 24
  frames, source against the analytic inverse, the no-lock render and the
  candidate at −3, 0 and +3 EV, with 1:1 crops of the most-changed regions.
  No artifact on any frame; the candidate equals or betters the analytic
  inverse in every clipped region (banded and posterised skies become smooth),
  and the lock makes no visible difference. At 0 EV it is within 1 code of the
  analytic inverse on every frame. Reviewed on SDR sheets and the EXR masters,
  not on an HDR monitor; the sign-off says so. Isolated black pixels on the
  +3 EV sheets are the ACES 2.0 SDR view (OpenColorIO 2.5.2) on off-neutral
  values near 130 linear; the masters are finite and ordinary there.
- **Core ML:** not timed on a Mac for this release; CI's ONNX Runtime CPU
  against Core ML parity job passed for this package.
