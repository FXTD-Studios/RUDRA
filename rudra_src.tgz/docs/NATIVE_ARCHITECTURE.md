# RUDRA Native: architecture and design patterns

> 23 Sep 2026. Companion to `docs/DESKTOP_APP_PLAN.md` (stack, phases, cost).
> This document fixes **how** the native app is built: the layers, the types,
> the threading model, the patterns, the numerics, and the first ten days.
> Stack (revision 2 of this document): Qt 6 (Widgets), **QRhi** over Metal /
> Direct3D 12 / Vulkan with an OpenGL fallback, C++20, **LibTorch + ONNX
> Runtime**, OpenEXR, OpenColorIO, FFmpeg with hardware decode. Target UI: the
> "Pro direction" boards on the design canvas. No platform is second-class: every
> OS gets native GPU rendering, compute, HDR output and accelerated inference.

---

## 0. The one idea the whole design rests on

The browser Studio already made the decision that matters, in `ui/server.py`
`run_frame()`:

> The fields the head produces (log residual and the two masks) do not depend
> on recovery_mode, residual_strength or the grade.

So the product is two pure functions and a cache between them:

```
fields    = infer(model, sdr_frame)                 # expensive, once per frame, GPU
picture   = composite(sdr_frame, fields, params)    # cheap, every slider move
```

`infer` runs once per (frame, model). `composite` is a pure function of its
inputs and runs every time a control moves, at display rate. Every design
decision below serves one of three goals:

1. keep `infer` off the UI's critical path,
2. make `composite` exist **once as a specification** and **twice as code**
   (GLSL for the viewer, compiled to every GPU API; C++ for masters and
   measurement) with a parity test
   that fails CI when they drift,
3. make the native result provably equal to the Python result.

---

## 1. Principles

| # | Principle | Consequence in code |
|---|---|---|
| P1 | **Units and colour encodings are types, not comments.** | `Image<Space>` tags; `Nits`, `Stops`, `SceneLinear` strong types; the 203-nit diffuse white defined once. A PQ buffer cannot be passed where scene-linear is expected; it does not compile. |
| P2 | **Pure stages, immutable data.** | Frames, fields and params are immutable values shared by `shared_ptr<const T>`. Threads exchange values, never mutate shared state. |
| P3 | **One composite, two backends, one parity test.** | `composite.spec.md` + `composite.cpp` + `composite.glsl`, tested pixel for pixel against each other and against Python goldens. |
| P4 | **Python is the oracle until retired.** | Every core module ships with golden files emitted by the Python code. No module merges without passing its golden test on all three OSes. |
| P5 | **Refuse, and say why.** | No silent fallbacks. Unknown colour tags, VFR, interlace, a model whose manifest does not match: typed error, shown to the user, same rules as `rudra.video`. |
| P6 | **The core knows nothing about Qt, the GPU API or the GPU vendor.** | `librudra` builds and tests headless on a CI box with no display. |
| P7 | **Every output is reproducible.** | Sidecar records model sha, params hash, app version, backend, precision. Same inputs, same bytes on CPU. |
| P8 | **Measure before optimising.** | Performance budgets are set from the Phase 0 spike on the RTX 4080, not guessed; Tracy zones on every stage from day one. |
| P9 | **Native on every OS, one source.** | One renderer on QRhi (Metal, D3D12, Vulkan, GL), one shader source compiled per API, one inference interface over several runtimes. Platform code lives only inside `render/` and `infer/` backends. |

---

## 2. Layers and the dependency rule

```
 ┌──────────────────────────────────────────────────────────────────┐
 │ app/         Qt Widgets: windows, view models, design tokens     │  depends on ↓
 ├──────────────────────────────────────────────────────────────────┤
 │ engine/      Session, Scheduler, caches, jobs, undo              │
 ├──────────────────────────────────────────────────────────────────┤
 │ video/       convert_video: predictor, pipeline, QC (no Qt)      │
 ├───────────────┬───────────────┬───────────────┬──────────────────┤
 │ render/       │ infer/        │ media/        │ deliver/         │
 │ QRhi viewer:  │ LibTorch +    │ readers (hw   │ encoders, QC,    │
 │ Metal, D3D12, │ ONNX Runtime  │ decode),      │ queue            │
 │ Vulkan, GL    │ backends      │ writers (EXR) │                  │
 ├───────────────┴───────────────┴───────────────┴──────────────────┤
 │ core/  (librudra) types, colour, baseline, composite (CPU),      │
 │        measure, metadata, grade, sidecar, errors                 │
 ├──────────────────────────────────────────────────────────────────┤
 │ platform/    files, paths, hashing, threads, logging, clocks     │
 └──────────────────────────────────────────────────────────────────┘
 cli/  headless `rudra-native`: core + infer + media + deliver + video, no Qt
```

**Rule:** a layer may depend only on layers below it. Enforced three ways:
CMake `target_link_libraries(... PRIVATE ...)` so headers do not leak upward;
a CI script that fails if any file under `core/` includes `<Q`, `<rhi/` or a GPU API header,
and if any file outside `render/` includes `<rhi/`;
`cli/` must link without Qt. (`video/` joined in Phase 4, step 7: the video
pipeline needs infer, media and deliver together, and the CLI runs it, so it
sits above the three and below `engine/`, with no Qt and no GPU.)

**Why this shape (the Apple habit):** AppKit apps that age well keep the model
layer free of the UI framework. It is what lets the CLI, the tests, every GPU
backend and a future ComfyUI/OFX plugin reuse the same core unchanged.

---

## 3. Domain model

All value types. Cheap to copy or shared immutably. Hashable where they feed
a cache key.

### 3.1 Colour and units (`core/color`)

```cpp
enum class Transfer  { Srgb, Bt1886, Gamma24, Linear, Pq, Hlg };
enum class Primaries { Rec709, Rec2020, P3D65, Ap0, Ap1 };
enum class Range     { Full, Limited };

struct ColorEncoding {            // what the numbers in a buffer mean
    Transfer  transfer;
    Primaries primaries;
    Range     range;
    float     nits_per_unit;      // 203 for scene-linear, 10000 for PQ-normalised
    bool operator==(const ColorEncoding&) const = default;
};

namespace space {                  // compile-time tags for the common ones
    struct SdrDisplay;             // sRGB/Rec.709 display-referred, [0,1]
    struct SceneLinear709;         // linear, Rec.709 primaries, 1.0 = 203 nits
    struct SceneLinear2020;
    struct DisplayPq2020;
}

template <class Space> class Image;   // RGB float32 planar or interleaved, owns pixels
struct Nits  { float v; };  struct Stops { float v; };
inline constexpr Nits kDiffuseWhite{203.f};
```

`Image<Space>` conversions exist only as named functions
(`to_scene_linear(const Image<SdrDisplay>&, Baseline)`), so every colour
transform in the program is greppable and tested.

### 3.2 Pipeline values

| Type | Holds | Produced by | Notes |
|---|---|---|---|
| `SourceFrame` | SDR pixels as `Image<SdrDisplay>`, `ColorEncoding` of origin, timecode, frame index, content hash | `media::Reader` | hash = xxh3 of decoded pixels, the cache key root |
| `FrameScalars` | `residual_scale`, `shadow_weight` (and future heads) | `infer` frame pass | computed **once per frame** from the whole frame, never per tile |
| `Fields` | log residual RGB + highlight mask (fp16 RGBA), shadow mask (fp16 R), `FrameScalars`, model id | `infer` tile pass | invariant to every user control, exactly as today |
| `GradeParams` | mode, residual strength, preserve outside masks, region EV qualifiers, display peak, container | UI edits | immutable, versioned, `hash()`; serialised identically into project, sidecar and queue |
| `Composite` | `Image<SceneLinear2020>` fp32 | `composite()` | what masters and measurements read |
| `Measurements` | MaxCLL, MaxFALL, peak, P99, share above 1 000 nits, share clipped, headroom stops | `core::measure` | CTA-861.3 maths ported from `rudra/delivery/metadata.py` |

### 3.3 Documents and jobs

| Type | Role |
|---|---|
| `Shot` | a clip or an image sequence opened by path; frame count, rate (rational), encoding, per-frame clip statistics for the timeline lane |
| `Project` (`.rudraproj`, JSON, schema-versioned, relative paths) | shots, per-shot `GradeParams`, collections, render destinations |
| `MasterJob` / `DeliveryJob` | frozen copy of `GradeParams` + model sha + preset + output path |
| `Queue` | `queue.json` **byte-compatible with `rudra batch`**, same state file, same lock semantics |

---

## 4. Data flow

```
             media thread            infer thread (owns device session)   render thread (QRhi)
 path ──► Reader.decode(i) ──► SourceFrame ──► FramePass ──► TilePass ──► Fields ─┐
                 │                 │  (whole frame,      (512 px tiles,         │
                 │                 │   ≤512 px view +     overlap, blend)        │
                 │                 │   native stats)                             ▼
                 │                 └──────────────► upload SDR texture   upload fields
                 │                                                             │
                 │                           GradeParams (UI, every edit) ────►│
                 │                                                             ▼
                 │                         composite shader → view transform → HDR/SDR swapchain
                 │                                                             │
                 │                                           scopes (compute) ◄┘
                 ▼
          deliver thread:  SourceFrame + Fields + frozen GradeParams
                           → composite.cpp (fp32) → measure → EXR / ffmpeg pipe → QC → sidecar
```

- The viewer never waits for inference to redraw: a slider move re-runs only
  the composite shader over resident textures.
- The master never uses the GPU render path. It runs `composite.cpp` in fp32 so the
  file on disk is independent of driver, GPU and display.
- Measurements shown in the inspector come from `composite.cpp` on a
  downsampled copy for interactivity and from the full frame on demand
  ("Re-measure"), matching what the browser Studio does with `measure()`.

---

## 5. Design patterns, and why each one

### 5.1 Pure pipeline + content-addressed cache (render graph, lite)

Each stage is a pure function with a version number. Its result is cached
under `hash(inputs..., stage_version, model_sha)`.

```cpp
struct FieldsKey { Hash frame; Hash model; uint32_t infer_version; Precision p; };
LruCache<FieldsKey, shared_ptr<const Fields>> fields_cache{bytes_budget};
```

Why: seeking back is free, switching model is correct by construction (the key
changes), and a stale result can never be displayed for the wrong frame. This
is the Nuke/Resolve pattern scaled down to three stages; a general node graph
is **not** built, because RUDRA's pipeline is fixed.

Budget example, 4K frame: fields fp16 × 5 channels = 3840·2160·5·2 B ≈ 83 MB.
A 16-frame read-ahead is ~1.3 GB of host RAM; VRAM holds the current frame and
the next 2. Budgets are settings, sized at start-up from available memory.

### 5.2 Actors with bounded queues (threads own resources)

| Actor | Owns | Why it must be single-threaded |
|---|---|---|
| `MediaActor` | libav contexts, EXR readers | codec contexts are not thread-safe |
| `InferActor` | the backend session (LibTorch module or ONNX Runtime session) and its device stream | one session per device, deterministic ordering |
| `RenderThread` | the `QRhi` instance, swapchain, textures, pipelines | QRhi and every native API behind it are used from one thread |
| `DeliverActor` | ffmpeg child process, EXR writers | one output at a time per job, like `rudra batch` |
| UI thread | widgets, view models | Qt rule |

Messages are immutable values (`shared_ptr<const SourceFrame>` etc.) over
bounded single-producer/single-consumer queues. The bound **is** the read-ahead
window, so backpressure is free. No mutex guards pixel data anywhere.

This is Swift's actor model expressed in C++20: isolation by ownership, not by
locks.

### 5.3 Priority scheduler with generations and cancellation

Three priorities: **interactive** (the frame under the playhead) >
**read-ahead** > **background** (masters, deliveries, thumbnails, the timeline
clip lane). Every request carries a `generation` number; a seek increments it,
and results from an older generation are dropped on arrival instead of
displayed. Long jobs take a `std::stop_token`.

Why: the classic failure of scrubbing tools is showing frame 120's result on
frame 180 after a fast seek. Generations make that impossible without locking.

### 5.4 Strategy interfaces at every external boundary

```cpp
struct InferenceBackend {           // LibTorch{Cuda,Mps,Cpu}, Ort{DirectML,CoreML,Rocm,OpenVino,Cpu}
    virtual Result<FrameScalars> frame_pass(const Image<SdrDisplay>&) = 0;
    virtual Result<Fields>       tile_pass (const Image<SdrDisplay>&, const FrameScalars&, TilePlan) = 0;
    virtual BackendInfo          info() const = 0;    // device, precision, versions
};
struct Reader  { virtual Result<SourceFrame> decode(FrameIndex) = 0; /* ... */ };
struct Writer  { virtual Result<void> write(const Composite&, const FrameMeta&) = 0; };
struct ViewerBackend { /* upload, composite, display, scopes, readback */ };  // QRhi (all APIs)
```

Why: each has several implementations **in v1**, not someday. Inference runs
on LibTorch where it is fastest (CUDA, MPS) and on ONNX Runtime everywhere else
(DirectML covers any DX12 GPU on Windows, Core ML the Apple GPU and Neural
Engine, ROCm and OpenVINO AMD and Intel on Linux). `BackendSelector` ranks what
the machine offers, runs the golden self-test on the winner, and falls back
down the list on failure. Swapping or adding one (AOTInductor, TensorRT) must
not touch the engine.

| Machine | Chosen by default | Fallbacks |
|---|---|---|
| Windows + NVIDIA | LibTorch CUDA | ORT DirectML, CPU |
| Windows + AMD / Intel | ORT DirectML | CPU |
| Mac, Apple Silicon | LibTorch MPS | ORT Core ML, CPU |
| Linux + NVIDIA | LibTorch CUDA | CPU |
| Linux + AMD | ORT ROCm | CPU |
| Linux + Intel | ORT OpenVINO | CPU |

### 5.5 Presets as data (registry)

HDR10, HLG, ProRes 422/422 HQ/4444 and EXR containers are JSON profiles
(`deliver/profiles/*.json`) ported from `rudra/delivery/profiles.py`: codec,
pixel format, colour tags, filter graph, QC rules. A `PresetRegistry` loads
them. Adding a preset is a data change reviewed against the Python profile,
not new C++.

### 5.6 Command pattern for edits, undo for free

Every user edit is a `GradeCommand { before: GradeParams, after: GradeParams }`
pushed on a `QUndoStack` per shot. Because `GradeParams` is an immutable value,
undo is a pointer swap and the composite simply re-runs. Slider drags coalesce
into one command (`mergeWith`).

### 5.7 MVVM at the Qt boundary

Widgets never call the engine. Each panel has a view model (`QObject`) that
exposes engine state as properties and signals, and turns user intent into
commands.

```
Widget  ⇄  ViewModel (QObject, UI thread)  →  Engine (actors, any thread)
                 ▲                                   │
                 └──── queued signal with value ◄────┘
```

Why: the Pro design and the dense "Full" workspace become two sets of widgets
over the **same** view models. Screenshot tests drive view models directly.

### 5.8 `Result<T>` and typed errors

`std::expected<T, Error>` throughout `core`, `infer`, `media`, `deliver`.
`Error` carries a code, a user-facing sentence and a technical detail. No
exceptions cross a module boundary (LibTorch's exceptions are caught at the
`infer` edge and converted). The UI renders `Error` the same way everywhere,
which is how "refuse, and say why" stays consistent.

### 5.9 Model package with capability negotiation

A model is a folder, not a file:

```
sdr2hdr_shadow_v1/
  model.ts              TorchScript module: frame_pass(), tile_pass()
  model.frame.onnx      ONNX graph of frame_pass (opset pinned)
  model.tile.onnx       ONNX graph of tile_pass
  manifest.json         contract version, corpus_ev, log_scale, max_hdr,
                        heads present {gate, shadow_gate, ...}, tile/overlap, opset,
                        source .pt sha256, torch version, export date
  golden/               16 frames: inputs and expected outputs
  LICENSE               the non-commercial weights licence
```

The engine reads `manifest.json` and enables only what the model declares
(for example, no shadow-weight UI if the model has no shadow gate). A
`contract` major version mismatch is a refusal. This matters now: an
uncommitted change on `main` adds a new model head
(`tests/test_curve_head_2026_09_23.py`); the native app must accept v1 and v2
models without code forks.

---

## 6. Computer-vision and numerics

### 6.1 Export: move every tensor op that affects numbers into the model

`predict_residual_scale` and `predict_shadow_weight` downscale with
`F.interpolate(mode="area")` to ≤512 px for pooled features but read
statistics from the **native** frame (the chroma high-frequency evidence is
destroyed by an area resize: 1.13 sd vs 0.60 sd with the sign inverted, per
the 29 Aug measurement in `rudra/sdr2hdr.py`). Re-implementing that resize or
those statistics in C++ is a parity risk with no upside. So the export wraps
them:

```python
class Exported(torch.nn.Module):
    def frame_pass(self, sdr_native):        # (1,3,H,W) full frame
        return residual_scale, shadow_weight # scalars, same code as today
    def tile_pass(self, sdr_tile, residual_scale, shadow_weight):
        return log_residual_rgb, highlight, shadow
```

The same wrapper is exported twice, `torch.jit` for LibTorch and
`torch.onnx.export` (dynamic H and W) for ONNX Runtime, and both are checked
against eager PyTorch on the goldens before the package is written. If an op
exports badly to ONNX (the area resize is the one to watch), it is rewritten in
the wrapper as an equivalent average pool, and that rewrite is itself checked
against eager.

C++ does only what has no numerical content: tiling geometry, overlap
blending with the **same window** `training/infer_sdr2hdr.py::predict_fields`
uses, and memory layout. The analytic baseline (`sdr_to_baseline_hdr`) is
computed inside the model too, for the tile pass; C++ ports it separately in
`core` only for the composite and for "Baseline" view, with a golden test.

### 6.2 Precision policy

| Stage | Precision | Reason |
|---|---|---|
| network | fp32 default; fp16 opt-in, labelled in UI and sidecar. Core ML and DirectML may run fp16 internally: their tolerance is recorded per backend | parity first, speed second |
| fields storage | fp16, clamped to `MAX_FIELD_MAGNITUDE` exactly as `run_frame` | same as the browser path, halves memory |
| composite (CPU and shader) | fp32 | log-domain add then exp: fp16 loses highlights |
| masters | computed fp32, written EXR half (float optional) | as today |
| measurements | fp32 over the full composite | MaxCLL is a max: one wrong pixel changes it |

### 6.3 Colour pipeline

- **Input decode** mirrors `rudra.video` exactly: tags decide transfer,
  primaries, matrix, range; missing tags require explicit overrides; the same
  rejections. Phase 1 uses libavfilter with the same `zscale` arguments the
  Python path passes, so parity is by construction. A hand-written float
  YUV→RGB path can replace it later, behind a golden test.
- **Working space:** scene-linear, 1.0 = 203 nits, Rec.2020 for the composite
  (Rec.709 input primaries converted with the exact matrix from
  `rudra/delivery/colorspace.py`).
- **View transforms:**
  - SDR out: today's PQ simulation (display-peak exposure + clip), identical
    maths to `compositor.js` `DISPLAY`.
  - HDR out, one shader with a per-swapchain output stage:

    | Swapchain (QRhi) | OS / API | Encoding | Value written |
    |---|---|---|---|
    | `HDRExtendedSrgbLinear` | Windows D3D12; Linux Vulkan where offered | scRGB: linear Rec.709, 1.0 = 80 nits, negatives allowed | `M709←src · nits / 80` |
    | `HDR10` | Windows D3D12 (option) | PQ, Rec.2020, 10-bit | `PQ(M2020←src · nits)` |
    | `HDRExtendedDisplayP3Linear` | macOS Metal (EDR) | linear Display P3, 1.0 = the display's SDR white | `MP3←src · nits / 203` |

    `src` is the composite's primaries, which are the input's (Rec.709 for an
    sRGB still): the network never changes primaries. Revision 1 of this
    table converted from Rec.2020, which the composite never was; the
    normative version is docs/view.spec.md section 9.

    Peak is clamped to what the display reports: max luminance on Windows,
    the live EDR headroom on macOS (it changes with the brightness slider, so
    it is re-read every frame). The pipe bar shows the path and the headroom.
  - Masters: ACES 2065-1 (AP0) or linear Rec.2020 via OpenColorIO, with the OCIO
    config the Python writes (`rudra aces --ocio`) so Resolve and Nuke read the
    same thing.

**Clipped highlights (12 Oct 2026).** The analytic reconstruction's fields are not
always zero: `core/clip_fill` (`clip_fill_fields`, through
`deliver::analytic_fields_for`) fills where the SDR clipped — a clipped channel
from its surviving ones, a fully clipped region by a smooth log2-luminance fill
from its edge plus a dome from the glow outside it, or the artist's peak in nits —
and hands the composite a residual (log1p domain, divided by the default gate so
mode All at strength 1 lands on the fill) with a highlight mask of 1 where it
changes anything. The fill reads the whole frame (regions, distances), so it runs
on the CPU with the fields, once per frame and per change of its settings, never
per slider; the shader is unchanged and GPU parity holds by construction.

### 6.4 Scopes and analysis

- Waveform, RGB histogram, vectorscope: QRhi compute shaders with atomic bins
  over a decimated grid (230 columns × 76 bins, as `server.py scopes()`),
  log-nits axis, on every backend. Only the OpenGL fallback below 4.3 uses the
  CPU path from a downsampled readback.
- **Timeline clip lane** (Pro design): per-frame SDR clipped share and crushed
  share, computed by the media actor at decode time (cheap, no network), stored
  per shot, so the lane fills as the shot is read.

### 6.5 Temporal

Frames are independent in their pixels; the v02 temporal line is closed and
nothing is fetched across frames. What is temporal is the handful of
whole-frame values: the shadow weight, residual scale and curve, and the
anchor's hold are held within a shot (`ShadowSmoother::hold`, reset at the
cut detector's cuts) with a time constant of `--temporal-smoothing` seconds,
0.25 by default (10 Oct 2026), in `rudra video`, `rudra-native video` and the
app's movie exports; while playing, `engine/playback_hold` holds the shadow
weight and the anchor's hold the same way, frames skipped to keep time
counting as elapsed. A stopped frame and Master EXR use the frame's own
values. Every movie report measures flicker: `flicker_ev` per frame and a
`temporal` summary, |ΔEV(HDR) − ΔEV(source)| on a 36×64 area thumbnail of the
luminance, cuts not scored, and `local_flicker_ev`, the same cell by cell.
In movie exports the static hold (`ShadowSmoother::hold_pixels`, `--static-hold`,
on by default) also holds, per pixel, the HDR's gain over the source where the
decoded source is still (3x3 mean luma change under 1.5/255; its own over
6/255), never where it is clipped (largest code >= 0.98) or crushed (<= 0.02),
so only the brightening is held and the source's own change passes through.
Playback runs it on the GPU (11 Oct 2026): `shaders/hold.frag`, after the
composite and before the display pass, writes the held picture and its state
(luma code, largest code, held gain, HDR luminance) to two RGBA32F targets,
the state ping-ponging between frames; `PlaybackHold::pixel_step` gives it
retention^frames and the shot's starts (`ViewerHold`). Its targets are made
the first time a held frame is shown. `rudra-gpu-parity` holds it to
`ShadowSmoother::hold_pixels` on a shot built to reach every branch
(`probe/hold_sequence.hpp`).

### 6.6 Performance budgets (set in Phase 0, recorded here)

| Path | Budget | Measured |
|---|---|---|
| composite + view, 1080p, GPU | ≤ 4 ms | **composite + display pass 0.240 ms (D3D12), 0.248 (D3D11), 0.244 (Vulkan), 0.219 (OpenGL)**, RTX 4080 SUPER, GPU timestamps, 24 Sep; the composite alone 0.118 ms |
| composite + view, 4K, GPU | ≤ 12 ms | **composite + display pass 1.156 ms (D3D12), 1.154 (D3D11), 1.167 (Vulkan), 1.030 (OpenGL)**; the composite alone 0.49 ms |
| inference, 1080p, RTX 4080, LibTorch CUDA fp32 / fp16 | measure | fp32 172 ms untiled, 296 ms tiled 512/64 (RTX 4080 SUPER, fields in host memory); fp16/bf16 not built yet |
| inference, 1080p, RTX 4080, ORT DirectML fp32 | measure | 150 ms untiled, 489 ms tiled 512/64; CPU for reference: LibTorch 2.5 s, ONNX Runtime 3.2 s |
| inference, 1080p and 4K, RTX 4080, ORT DirectML / TensorRT fp16 (`model.tile.fp16.onnx`, roadmap R1) | 1080p ≤ 20 ms | not yet run; the export holds the fp16 graph to 1e-2 in the fields (0.0144 stop), measured 5.9e-3 on CPU |
| inference, 4K, RTX 4080, LibTorch CUDA / ORT DirectML fp32 | measure, then measured + 25 % | not yet run: `NATIVE_GATE_A.ps1 -SkipExport -SkipBuild -Machine rtx4080s-win` times it, and its first run sets the 4K budgets |
| inference, 1080p, Apple M-series, LibTorch MPS / ORT Core ML | measure | [Phase 0] |
| inference, 1080p, CPU on GitHub's ubuntu-24.04 runner (CI, `native` parity job) | ≤ 40 s LibTorch, ≤ 25 s ONNX Runtime, untiled | 16.7 s and 10.1 s untiled (28.7 s and 16.9 s tiled) on a 2-core cloud VM, 2 Oct 2026; loose on purpose, it catches a debug build or a lost thread pool |
| viewer measurements and scopes, CPU, after a slider settles (off the render thread) | ≤ 16 ms | 21 ms at 1080p and 23 ms at 4K (768 x 432 sample) plus 5 ms vectorscope on two 2.1 GHz cloud cores (29 and 7 ms on one): the per-pixel work runs in up to eight chunks whose integer counts merge exactly, the order-dependent sums stay sequential, and the result is bit-identical to the browser's still (`rudra-native bench-scopes`); the desktop number comes from `NATIVE_GATE_A.ps1` |
| first frame after open (warm) | ≤ 2 s | decode plus one inference: 150 to 172 ms of inference at 1080p on the RTX 4080 SUPER (above); end to end from the app on Windows open |
| scrub to cached frame | ≤ 1 display frame | synchronous: a cached frame is delivered inside `FrameEngine::show()` (0.01 ms in the engine test); the upload and passes are the composite + view row |

The budgets live in `native/bench/latency_budgets.json`, per machine label;
`rudra-native bench --budget <file> --machine <label>` exits 1 when a budgeted
row is over (roadmap 3.6), and both gate scripts pass it through (`-Machine`,
`MACHINE=`).

Instrumentation: Tracy zones on every actor message and GPU timer queries on
every render pass (QRhi GPU timestamps), from the first commit.

Read of the numbers (23 Sep 2026): the composite is 35 times inside its 1080p
budget and 24 times inside its 4K budget, so every control runs at display
rate with room for the view pass and scopes. Inference is the only cost that
matters and it is paid once per frame, not per slider move: 150 to 170 ms at
1080p untiled on the RTX 4080 SUPER in true fp32. Tiling costs 1.7x on CUDA and
3.3x on DirectML (per-call overhead on twelve 512 tiles), so tiles are for
memory, not for speed, as the Studio already treats them. A reduced-precision
path (fp16/bf16, own tolerance, never the default) is the first speed item in
Phase 1.

---

## 7. Threading model, summarised

| Thread | Runs | May block on |
|---|---|---|
| UI | widgets, view models, undo | nothing, ever |
| Render | QRhi upload, composite, display, scopes | vsync |
| Media | decode, clip statistics, thumbnails | disk, codec |
| Infer | frame pass, tile pass | GPU |
| Deliver | composite.cpp, measure, write, ffmpeg pipe, QC | disk, child process |
| Pool (N cores) | CPU composite tiles for masters, EXR compression | nothing shared |

Cross-thread communication: bounded queues and queued Qt signals carrying
values. Shared mutable state: none except the caches, which are internally
synchronised and store immutable values.

---

## 8. Persistence and interchange

| File | Format | Compatible with |
|---|---|---|
| `.rudraproj` | JSON, `schema` field, relative paths | native only; migration functions per schema bump |
| sidecar `.json` | same keys as the Python sidecar, plus `backend`, `precision`, `app_version` | Python readers ignore unknown keys |
| `queue.json` + `.state.json` | identical to `rudra batch` | run or resume by either tool |
| settings | `QSettings` | per user |
| caches | `<appData>/RUDRA/cache/` (thumbnails, clip lanes), keyed by content hash | safe to delete |

---

## 9. Errors, logging, diagnostics

- `spdlog` structured JSON logs to `<appData>/RUDRA/logs`, one file per session.
- A **Diagnostics** window: backend info, model manifest, GPU/driver, display
  HDR state, ffmpeg capability probe, last 200 log lines, "Copy report".
- Crash reports stay local (minidump on Windows, `.ips` on macOS); nothing is
  uploaded.
- Every refusal (`Error`) is logged with its code; the code list is documented
  so support can map a screenshot to a cause.

---

## 10. Testing

| Level | Tool | What it proves | Tolerance |
|---|---|---|---|
| Unit | GoogleTest | each function's contract | exact / 1 ulp |
| Golden parity | GoogleTest reading `tests/golden/` emitted by `pytest --emit-golden` | C++ core == Python | per module, table in `tests/golden/TOLERANCES.md` |
| Model parity | `rudra-native diff` on 429 bench frames | LibTorch == eager PyTorch | log-space max abs ≤ 1e-5 (CPU fp32) |
| Composite parity | readback on **each** QRhi backend vs `composite.cpp` | viewer == master on every API | ≤ 2 half ulp |
| Backend parity | each `InferenceBackend` on the 429 bench frames | every runtime == eager PyTorch | per backend, in `TOLERANCES.md` |
| Integration | CLI end to end: clip in, HDR10 out, QC | whole path | QC pass + sidecar keys |
| Queue interop | Python writes queue, C++ resumes it, and back | compatibility | state identical |
| UI | Qt Test + screenshot diff of Pro boards | layout, states | perceptual diff threshold |
| Performance | Google Benchmark in CI on fixed frames | no regressions | ±10% gate |

The golden emitter is the linchpin: it turns the existing Python test suite
into the native specification.

---

## 11. Repository layout and targets

```
native/
  CMakeLists.txt  CMakePresets.json  vcpkg.json
  platform/   rudra_platform   (files, hash, log, threads)
  core/       rudra_core       (types, colour, baseline, composite.cpp, measure, metadata, sidecar)
  media/      rudra_media      (libav reader, EXR/PNG/TIFF sequences, EXR writer)
  infer/      rudra_infer      (InferenceBackend, LibTorch + ONNX Runtime impls, BackendSelector, tiling)
  render/     rudra_render     (ViewerBackend on QRhi, shaders/*.glsl → .qsb, scopes, HDR swapchains)
  deliver/    rudra_deliver    (presets, ffmpeg pipe, QC, queue)
  engine/     rudra_engine     (Session, Scheduler, caches, actors, undo)
  app/        RUDRA            (Qt Widgets, view models, tokens → QSS)
  cli/        rudra-native
  tests/      unit, golden, parity, ui, bench
  design/     tokens.json (from the Pro boards), icons
tools/
  export_model.py        writes the model package (§5.9)
  emit_golden.py         pytest plugin: writes tests/golden/
```

Design tokens (colours, radii, type scale, spacing from the Pro direction)
live in `design/tokens.json` and generate both QSS and a C++ header, so the
look has one source.

---

## 12. What is next: the first ten working days

Goal: answer the two go/no-go questions of Phase 0 and leave a skeleton every
later phase builds on.

| Day | Deliverable | Done when | Status |
|---|---|---|---|
| 1 | `tools/export_model.py`: `frame_pass` + `tile_pass` as TorchScript **and** ONNX, `manifest.json`, 16 golden frames | both reloaded graphs match eager on the 16 frames, max abs ≤ 1e-6 | **done** 23 Sep: TorchScript max \|d\| 0.0, ONNX 5.9e-5 on the shipped model; an all-heads model also passes |
| 2 | `native/` CMake + vcpkg skeleton (Qt with Shader Tools, ONNX Runtime, LibTorch), empty targets, dependency-rule check, CI on Windows/macOS/Linux | three green builds | **done** 23 Sep: 18 GoogleTests green; Qt shell builds and starts; CI in `.github/workflows/native.yml` |
| 3 | `rudra_infer`: `InferenceBackend`, LibTorch CPU + ORT CPU, tiling + overlap blend | `rudra-native diff` runs on 1 frame on both | **done early** 23 Sep: LibTorch and ORT CPU backends; the tiler is bit-exact with `predict_fields` |
| 4 | Model parity on the 429 bench frames: CPU fp32 on both runtimes, then CUDA, DirectML, MPS, Core ML | **Gate A:** ≤ 1e-5 log-space on CPU for both; every GPU backend's delta recorded | **Windows done** 23 Sep, RTX 4080 SUPER: LibTorch CPU 1.2e-7, LibTorch CUDA 1.4e-5 (true fp32, TF32 off; `gpu_fp32` bound 5e-5 + 1e-5 \|ref\|), ONNX Runtime CPU 5.8e-5, DirectML 3.3e-6. 24 Sep: `scripts/native_gate_a.sh` for macOS and Linux (LibTorch MPS, ONNX Runtime Core ML on a Mac); Linux CPU: LibTorch 0.0, ONNX Runtime 5.9e-5. The 429-frame bench, MPS and Core ML runs open |
| 5 | QRhi HDR spike: a bare `QRhi` window on Windows (D3D12, `HDRExtendedSrgbLinear`) and macOS (Metal, `HDRExtendedDisplayP3Linear`), 1 000-nit patch; Linux Vulkan probed | **Gate B:** patch measured above SDR white on Windows and on an XDR display | **Windows passes** 23 Sep: `rudra-hdr-probe` (Qt 6.8, QRhi) on an RTX 4080 SUPER and an ASUS PA279CRV (418-nit peak, SDR white 240): D3D12 scRGB 203 / 1 000 / 2 000 nits exact, D3D12 HDR10 202.9 / 998.9 / 1 991.8 (10-bit PQ), D3D11 scRGB exact; the SDR fallback reports FAIL. XDR Mac open |
| 6 | `core/color` types, `ColorEncoding`, `Image<Space>`, units; baseline port + golden | golden passes on 3 OSes |  |
| 7 | `composite.spec.md` written from `compositor.js`, `composite.cpp`, golden vs browser Studio readback | exact on 5 test frames | **done** 23 Sep: [`composite.spec.md`](composite.spec.md); `composite.cpp` matches `predict_image` on 5 mode/strength/preserve cases on 2 frames (rtol 2e-4), Region EV and the whole master chain to AP0 match `_render_master` stage by stage; browser readback moves to day 8 with the shader |
| 8 | composite shader in GLSL 440 compiled by `qsb`, running in the spike window on D3D12, Metal, Vulkan and GL; readback parity with `composite.cpp` | ≤ 2 half ulp on every backend | **Windows done** 23 Sep: `render/shaders/composite.frag`, `GpuCompositor`, `rudra-gpu-parity`; on an RTX 4080 SUPER D3D12 (fp32 3.0e-6), D3D11, Vulkan and OpenGL (1.7e-6) all pass with fp16 at 1 half ulp, 12 cases each; llvmpipe passes too. Metal open |
| 9 | `measure()` port + MaxCLL/MaxFALL golden; Tracy + QRhi GPU timestamps; first budget numbers in §6.6 | table filled | **port done** 23 Sep: `analyze_frame`, MaxCLL/MaxFALL and the Studio `measure()` match the Python; timing in place: `rudra-native bench` (inference) and `rudra-gpu-parity --bench` (composite pass, QRhi GPU timestamps), run by both gate scripts; §6.6 numbers from the Windows run; Tracy open |
| 10 | Review: ADRs signed, budgets and backend matrix recorded, go/no-go | decision written into `STATUS.md` | **done** 23 Sep: GO for Phase 1 on Windows; macOS conditional on its three gates (`STATUS.md`, line F) |

If Gate A fails, the fix is in the export (usually a traced branch or a
dtype, or for ONNX an op that needs rewriting in the wrapper); nothing else
starts until it passes. If Gate B fails on one OS, that OS ships SDR-out in v1
and HDR-out follows; the renderer does not change.

---

## 13. Decisions, recorded as ADRs

Status after the Phase 0 review, 23 Sep 2026. Accepted means the Phase 0
evidence supports it; accepted, not yet exercised means nothing in Phase 0
could test it and it stands until Phase 1 does.

| ADR | Status | Evidence |
|---|---|---|
| 001 | accepted | both graphs exported and verified; TorchScript bit-exact, ONNX 5.8e-5 |
| 002 | accepted | Qt 6.8.3 builds the probe and the GPU composite on MSVC (VS 2026 Build Tools), GCC and, for the Windows headers, MinGW |
| 003 | accepted | the composite passes readback parity on D3D12, D3D11, Vulkan and OpenGL; Metal open |
| 004 | accepted | four Windows backends pass Gate A; TF32 off by default on CUDA |
| 005 | accepted | scRGB and HDR10 carry 1 000 and 2 000 nits to the swapchain; the SDR fallback reports FAIL |
| 006 | accepted, not yet exercised | decode is Phase 1 |
| 007 | accepted | contract 1.0 read and verified by `rudra-native`; `gpu_fp32` added without a major bump |
| 008 | accepted | `queue.json` state written byte-identical by both sides and resumed across them (Phase 1 step 9) |
| 009 | accepted | Windows DX12 on an RTX 4080 SUPER measured; the Apple Silicon row waits on the Mac run |
| 010 | accepted | the viewer is that window: composite, display and blit on its own swapchain, passing its readback on llvmpipe; the glass run is `NATIVE_GATE_B.ps1` |


1. **ADR-001** Model package carries TorchScript and ONNX; AOTInductor and
   TensorRT are later speed backends, never the only format.
2. **ADR-002** Qt 6 LTS (6.8 or later) with Qt Shader Tools; LGPL dynamic
   linking.
3. **ADR-003** Renderer on QRhi: D3D12 on Windows, Metal on macOS, Vulkan on
   Linux, OpenGL fallback; all QRhi use confined to `render/`.
4. **ADR-004** Two inference runtimes behind `InferenceBackend`: LibTorch
   (CUDA, MPS, CPU) as reference, ONNX Runtime (DirectML, Core ML, ROCm,
   OpenVINO) for universal GPU coverage; `BackendSelector` order in §5.4.
5. **ADR-005** HDR output encodings per swapchain (§6.3), peak from the display,
   never tone-mapped silently.
6. **ADR-006** Decode through libavfilter + `zscale` for parity in v1; hardware
   decode enabled only after it matches software decode on the test clips.
7. **ADR-007** Model package format and contract versioning (§5.9).
8. **ADR-008** `queue.json` and sidecar stay byte-compatible with Python.
9. **ADR-009** Supported hardware: Apple Silicon only on macOS; DX12 GPUs on
   Windows; the Linux GPU and compositor matrix for HDR.
10. **ADR-010** (accepted, Phase 2) The viewer is a `QWindow` with its own QRhi
   swapchain, embedded with `createWindowContainer`; not `QRhiWidget`, whose
   backing-store composite is SDR (section 15).

---

## 14. Phase 1: librudra, the next fifteen working days

Goal (docs/DESKTOP_APP_PLAN.md section 6): every Python module the product
depends on exists in C++ and passes its golden test on three OSes, ending in a
master EXR rendered with no Python on the machine. Same rules as Phase 0: the
Python is the oracle, each module lands with its goldens and tests, the README
is ticked in the same commit.

Already ported in Phase 0: baseline, tiling, composite, Region EV, anchor,
chroma carry, colour-space matrices, `analyze_frame`, MaxCLL/MaxFALL, Studio
`measure`. Added 25 Sep 2026: the highlight grain stage (`rudra/grain.py`,
`settle_highlight_grain`), after the chroma carry.

| # | Deliverable | Oracle | Done when | Days | Status |
|---|---|---|---|---|---|
| 1 | One golden harness: `tools/emit_golden.py` runs every emitter; CI re-emits on all three OSes and runs the native tests against fresh arrays | the emitters | a Python change that moves a number fails CI | 0.5 | **done** 23 Sep: `tools/emit_golden.py` (core, composite, decode, delivery, master, qc, queue, sequence); CI re-emits on Linux and fails on any drift in the exact goldens; since step 11 the `core` job re-emits on all three OSes |
| 2 | Still decode in `media/`: PNG 8/16-bit (grey, alpha, palette), JPEG, TIFF 8/16/float, BMP, WebP; bit depth, padded-16-bit detection and distinct codes reported; scene-linear float refused | `rudra/decode.py` `decode_sdr` | same float pixels, bits and refusals on a fixture set of every format and depth | 2 | **done** 23 Sep: `media/still.cpp` on OpenCV imgcodecs, the decoder the Python uses; 17 fixtures bit-exact, JPEG included, across OpenCV 4.6 (C++) and 4.13 (Python). EXR dropped: the Python refuses it too |
| 3 | Grade controls: exposure, highlight desaturation, shoulder to peak, `apply_grade`, `itm_strength_map` | `rudra/delivery/controls.py` | golden arrays, rtol 1e-12 | 1 | **done** 24 Sep: `core/grade.cpp`; four grades within 2e-7 of the float32 output (numpy's SIMD `exp` is the only difference), the strength map exact |
| 4 | HDR10 and profiles: PQ OETF/EOTF, `master_to_peak`, `master_to_pq`, delivery profiles | `rudra/hdr10.py`, `delivery/profiles.py` | golden arrays; PQ codes exact at 10 and 12 bit | 1 | **done** 24 Sep: `core/hdr10.cpp`, every profile incl. HLG; 12-bit PQ codes exact on 407 levels; float PQ within 2e-5 of code (numpy's float32 `power` is 1 ulp off where glibc is correctly rounded, and PQ's 78.84 exponent amplifies it: a fiftieth of a 10-bit step) |
| 5 | Metadata writers: `detect_shots`, `l1_per_shot`, Dolby Vision generate JSON, HDR10+ JSON, the RUDRA sidecar | `delivery/metadata.py` | byte-identical JSON on a multi-shot fixture | 1.5 | **done** 24 Sep: `core/metadata.cpp`, `deliver/sidecars.cpp`, `platform/pyjson` (Python's `json.dumps` and `repr`) and numpy's pairwise sum; all three sidecars byte-identical on a 12-frame, 3-shot sequence |
| 6 | EXR and ACES writers on OpenEXR: half pixels, chromaticities, provenance attributes, AP0 container | `delivery/exr.py`, `delivery/aces.py` | pixels exact after the half cast; every header attribute equal when read back by Python | 2 | **done** 24 Sep: `deliver/exr.cpp` writes the EXR directly, like the Python (no OpenEXR library needed); half, float, RGBA, ACES AP0 and ACEScg files and the OCIO config byte-identical; float16 rounding exact on 1 012 values incl. subnormals and overflow |
| 7 | **`rudra-native master <package> <image> --out x.exr`**: decode, infer, composite, master chain, measure, EXR, sidecar | `ui/server.py` `_render_master` | the same EXR within 1 half-float ulp and the same sidecar numbers as the Studio master, on three stills, no Python installed | 2 | **done** 24 Sep: `cli/master.cpp`, checked by `rudra-native master-check` (a ctest): three stills (8-bit PNG, 16-bit PNG, JPEG; default, graded linear, highlights-only unanchored) within 1 half ulp on LibTorch and ONNX Runtime (at most 0.8% of values one ulp off), every EXR header attribute equal, sidecars equal and byte-identical in two of three (the third's peak rounds 3235.5 vs 3235.6) |
| 8 | QC: `check_frame`, thresholds file, report text | `rudra/qc.py` | same pass/fail and identical report text on the fixtures | 1.5 | **done** 24 Sep: `deliver/qc.cpp`; six fixtures walk every status (PASS, FAIL, UNMEASURED) of all ten checks and both verdicts; statuses equal, values within 1e-9 (1e-3 for the two blur-based ones, OpenCV's SIMD blur), report text byte-identical |
| 9 | Queue: `queue.json` read, write, lock, atomic save, resume, artifact digests | `rudra/batch.py` | a queue started by Python resumes in C++ and the other way round | 1.5 | **done** 24 Sep: `deliver/queue.cpp`; a fresh run with a failing job and its `--retry-failed` resume write the Python's state files byte for byte, a Python-started state resumes here to the Python's final state, nine malformed queues refused with the same messages, one runner per queue (`busy`) |
| 10 | Sequence open by path: frame folders and numbering rules (video frames wait for libav in Phase 4) | `ui/sequence.py` | same frame list and order on the fixture folders | 1 | **done** 24 Sep: `media/sequence.cpp`; same names, order and messages as `Sequence.open` on 14 cases (natural order across powers of ten, case, leading zeros, dot files, quoted and messy paths, empty and frameless folders); video recognised and refused until Phase 4 |
| 11 | Review: CI green on Windows, macOS, Linux; Mac runs from Phase 0 folded in; Phase 1 exit written into `STATUS.md` | | every module passes its golden on three OSes | 1 | **in progress** 24 Sep: the `core` CI job now re-emits every golden with each runner's Python and builds with OpenCV on Windows (vcpkg, cached), macOS (Homebrew) and Linux; goldens are byte-exact in git (`.gitattributes`) and every Python writer the port matches (sidecars, OCIO config, queue state, golden indexes) writes LF on every OS, so Windows compares the same bytes. Waiting on the first three-OS run and the Mac runs |

New third-party code, none in the public headers (principle P6): OpenCV
core and imgcodecs in `media/src` (`RUDRA_WITH_OPENCV`), chosen over separate
PNG, JPEG and TIFF libraries because it is the decoder `rudra/decode.py` calls,
so the two decode the same bytes to the same floats, quirks included (palette
expansion, grey-alpha, 16-bit TIFF). No OpenEXR: the Python writes EXR itself and
the port does the same, byte for byte. OCIO
waits until a module needs it; nothing in this list does.

Order: 1 first, then 2 to 6 in any order, 7 as soon as 2 and 6 land (it is the
milestone that proves the port end to end), then 8 to 11.

## 15. Phase 2: the QRhi viewer, the next twenty working days

Goal (docs/DESKTOP_APP_PLAN.md section 6): the picture, the probe and every
measurement the browser Studio shows, drawn by QRhi on D3D12, Metal, Vulkan and
OpenGL, into an HDR swapchain where the display has one. Same rules as Phases
0 and 1, with one change of oracle: the viewer ports `ui/compositor.js` and the
scope code in `ui/app.js`, so those files, run unchanged in a headless browser,
are the oracle. The Python stays the oracle for anything numeric it also does
(composite, measure), and the two must already agree.

Already in hand from Phase 0: the composite shader and `GpuCompositor`
(readback parity on four Windows backends), `rudra-hdr-probe` (scRGB, HDR10,
the SDR fallback), `ViewerBackend` and `OutputPath` in `render/`.

| # | Deliverable | Oracle | Done when | Days | Status |
|---|---|---|---|---|---|
| 1 | Browser oracle: `tools/emit_viewer_golden.py` drives `ui/compositor.js` and the scope functions of `ui/app.js`, unmodified, in headless Chromium (Playwright, SwiftShader WebGL2 with float targets) on the composite goldens' frames | `ui/compositor.js`, `ui/app.js` | deterministic across runs; its composite readback matches `composite.cpp` within the `gpu_fp32` bound, closing the browser readback left open in Phase 0 step 7 | 1.5 | **done** 24 Sep: `tools/emit_viewer_golden.py`, `tests/test_viewer.cpp`; two frames from the shipped checkpoint (80x48, and 900x40 so `sample()` downsamples), six composites and seven views, deterministic across runs; the browser composite matches `composite.cpp` within 3e-6 (bound 5e-5 + 1e-5\|ref\|), peak and mean too. It found a Studio defect, fixed in `ui/compositor.js`: `sample()` chose its texel with a filtered lookup and `sourceIndex()` in doubles, and they disagreed on rows where (2y+1)h/(2 sh) is an integer, pairing one pixel with its neighbour's mask; both now use the same integer expression |
| 2 | `docs/view.spec.md` written from the `DISPLAY` shader, `present()`, `probe()`, `sample()` and the scopes: the one V flip, wipe and handle, false-colour zones, log difference ramp, exposure plus hard clip, sRGB encode, sample grid | the same files | every constant and branch in them has a line in the spec | 0.5 | **done** 24 Sep: [`view.spec.md`](view.spec.md) revision 1: orientation, the display pass and its zones, probe, reductions, sample and index, `computeStats`, `buildScopes` and the vectorscope, with evaluation order where it decides a rounding |
| 3 | `core/view.cpp`: CPU reference of the display pass for all three views and the wipe | browser canvas readback | within 1 8-bit code of the browser; false-colour zone index exact; handle columns exact | 1.5 | **done** 24 Sep: `core/view.cpp`; 14 views on two frames (image at 203 and 1 000 nits, baseline, false colour, difference, two wipes) equal to the browser canvas in every byte but 3 of 290 k, which are 1 code off; zones and handle columns exact |
| 4 | `display.frag` in GLSL 440 through `qsb`, run by `rudra-gpu-parity` after the composite | `core/view.cpp` | within 1 8-bit code on D3D12, D3D11, Vulkan, OpenGL (and Metal); llvmpipe in CI | 1.5 | **Linux done** 24 Sep: `render/shaders/display.frag`, `GpuCompositor::view`, seven views per frame in `rudra-gpu-parity`; OpenGL on llvmpipe equal to `core/view.cpp` in every byte (CI runs it). D3D12, D3D11 and Vulkan run with `NATIVE_GATE_B.ps1`; Metal with `native_gate_b.sh` |
| 5 | HDR output from the display pass: scRGB, HDR10 PQ, EDR, with the Rec.2020 to Rec.709 / P3 matrices and the view peak taken from the display instead of a clip at SDR white (ADR-005); SDR keeps today's exposure and clip | `core/view.cpp` extended, `rudra-hdr-probe` patches | readback within 2 half ulp per path; Gate B re-run through the real display pass on the PA279CRV | 2 | **Linux done** 24 Sep: [`view.spec.md`](view.spec.md) section 9, `core/view.cpp` and `display.frag` for scRGB, HDR10 and EDR (P3 and Rec.709), `GpuCompositor::view_values`; 40 cases per run in `rudra-gpu-parity`, on llvmpipe fp32 within 2.8e-5 relative and fp16 within 1 half ulp; unit tests against `pq_oetf` and the gamut matrices. Found that 6.3 converted from a Rec.2020 working space the composite never had; it now converts from the source primaries. The glass re-run of Gate B through this pass needs the viewer window and moves to step 9 |
| 6 | GPU reductions: the `REDUCE` ladder as QRhi passes for peak, mean and MaxFALL | `measure()` (Python), browser `peakNits` / `meanNits` | peak exact, mean within fp32 summation bounds, on every backend | 1 | **done** 24 Sep: `render/shaders/reduce.frag`, `GpuCompositor::reduce`, `core/view.cpp` `reduce_ladder` (the ladder's own fp32 order); peak and sum equal to the browser's bit for bit, MaxCLL and MaxFALL too, and the shader equal to the CPU ladder on llvmpipe. Windows and Metal runs with the gate scripts |
| 7 | Probe: one texel from each float target, nits by Rec.2020 luma, no flip | browser `probe()`, `composite.cpp` | equal at a fixed point set including the four corners | 0.5 | **done** 24 Sep: `core/view.cpp` `probe_pixel`; eight points per frame, corners included, equal to the browser's `probe()` bit for bit. On the GPU it is a one-texel read of the target, done by the viewer (step 9) |
| 8 | Sample and scopes: the 768-side point sample and its source index, the waveform quantiles and histogram, the vectorscope, ported to `core/scopes.cpp` and run on the sample | browser `sample()`, `buildScopes`, `drawVector` accumulation | sample indices exact; waveform, histogram and vectorscope bins exact; the scopes cost recorded (compute shaders only if the CPU path misses its budget) | 1.5 | **done** 24 Sep: `core/scopes.cpp`; the sample grid and index, all 14 `computeStats` numbers, the waveform quantiles, the histogram and the vectorscope image equal the browser's bit for bit on every stored case, and the mask coverage too. Cost at 1080p (768 x 432 sample) on a 2.1 GHz cloud core: 32 ms for the measurements and scopes, 7 ms for the vectorscope; they run off the render thread, after a slider settles, as in the Studio. Compute shaders only if the Windows measurement (step 12) misses a 16 ms budget |
| 9 | The viewer in the Qt shell: a `QWindow` with its own QRhi swapchain inside the widget tree (`createWindowContainer`), fit, 1:1, zoom about the cursor, pan, wipe drag, view switching with no recomposite, resize, device loss | `fitScale` and `zoomAbout` in `ui/app.js` (goldens of viewport maths) | viewport maths equal to the browser's; a still is judged in the app exactly as in the Studio; Gate B re-run through the real display pass on the PA279CRV (scRGB and HDR10) | 3 | **done** 24 Sep. Linux: `render/viewer_window.cpp` (composite, display and blit on its own swapchain, the HDR format from the display, device loss rebuilt from host copies), `core/viewport.cpp` equal to the Studio's own layout (`tools/emit_viewport_golden.py`); `rudra-viewer-check` reads the swapchain back at fit, 2x and 1:1 within 1 code of `core/view.cpp` at device pixel ratios 1, 1.25, 1.5 and 2. Windows, RTX 4080 SUPER and PA279CRV: Gate B through the real display pass passes on D3D12 and D3D11 scRGB (203 exact, 1 000 and 2 000 clipped at the display's 418 nits) and on Vulkan scRGB (418 from DXGI). The first Windows runs found three things, all fixed: the parity check did not allow for texel ties at a 150 % display scale, and Qt's Vulkan swapchain reports a placeholder 1 000-nit peak, now replaced by the DXGI value on Windows; and on D3D12, D3D11 and Vulkan a swapchain readback completes only when its frame slot comes round again, so each window check compared a case with the one before it (reproduced on lavapipe, now waited for with `QRhi::finish`, and lavapipe Vulkan runs in CI). "Actual pixels" is device 1:1. Three Studio viewport defects fixed on the way (view.spec.md section 10) |
| 10 | Frame path: decode, an engine inference job with generations and cancellation, field upload, composite, present; stills and sequences (Phase 1 step 10) with fields cached per frame | Phase 1 modules | scrubbing a 240-frame folder never shows a stale frame; latency recorded | 3 | **done** 24 Sep: `engine/frame_engine.cpp`, the InferActor: one worker owns the backend; `show()` bumps the generation, cancels older queued work, queues the frame and 12 after it; results are cached (32 frames, LRU, the frame on screen never evicted) and delivered only while current. A 240-frame scrub faster than inference never delivers another frame's pixels or fields (fakes tagged by value; ThreadSanitizer clean); with the real package on CPU over the 17 decode fixtures, every delivered frame equals a direct decode, the refused float TIFF is reported as itself, the way back is all cache hits. The app opens a still or a folder through it (comma, full stop, Home, End, Space at 24 fps). Latency at 1080p is measured with step 12 |
| 11 | Guides (new, no Studio oracle): title and action safe, aspect masks, centre cross, specified in `view.spec.md` | the spec | CPU reference test; drawn identically on every backend | 1 | **done** 24 Sep: [`view.spec.md`](view.spec.md) section 11, `core/guides.cpp`, drawn by the blit in device pixels; `rudra-viewer-check` holds the window's readback to the CPU reference with all guides on and a 2.39 and a 4:3 mask, at fit, 2x and 1:1, device pixel ratios 1 and 1.5 (within 1 code); the app's View > Guides (G, Shift+G) |
| 12 | Backend matrix and budgets: everything above on D3D12, D3D11, Vulkan, OpenGL, Metal; composite plus view at 1080p against the 4 ms budget in 6.6 | | matrix and numbers recorded here and in 6.6 | 1.5 | **in progress** 24 Sep: the matrix above; `rudra-gpu-parity --bench` times composite plus display per slider move and `rudra-native bench-scopes` the CPU measurements, both run by the gate scripts; 6.6 filled where measured. Windows complete 24 Sep (03:55 run): GPU parity, the display pass, the HDR paths and the window readback pass on D3D12, D3D11, Vulkan and OpenGL, and Gate B through the viewer on D3D12, D3D11 and Vulkan; open: Metal (the Mac runs) and the desktop scopes timing from `NATIVE_GATE_A.ps1` |
| 13 | Review: Phase 2 exit written into `STATUS.md` | | probe and measurements equal the browser Studio's on every backend | 0.5 | |

Backend matrix for the viewer (step 12), from the gate scripts and CI:

| Backend | Composite (fp32 / fp16) | Display pass (SDR, 7 views) | HDR paths (40 cases) | Reductions | Window readback (fit, 2x, 1:1, guides) | Gate B through the viewer |
|---|---|---|---|---|---|---|
| OpenGL, llvmpipe (Linux, CI) | pass | exact | pass (2.8e-5, 1 ulp) | exact | pass at device pixel ratios 1 to 2 | n/a: no HDR swapchain |
| D3D12, RTX 4080 SUPER | pass (fp32 3.0e-6, fp16 1 ulp) | 1 code | pass, HDR10 near black within 1/20 of a 10-bit code (1.4e-5) | exact | **pass** at device pixel ratio 1.5 (the 03:55 run; below) | **pass**, scRGB, 203 exact, clipped at 418 |
| D3D11, RTX 4080 SUPER | pass (1.7e-6, 1 ulp) | 1 code | as D3D12 | exact | **pass** at device pixel ratio 1.5 | **pass**, scRGB, as D3D12 |
| Vulkan, RTX 4080 SUPER | pass (1.7e-6, 1 ulp) | 1 code | as D3D12 | exact | **pass** at device pixel ratio 1.5 | **pass**, scRGB, the display's 418 nits from DXGI (Qt reports a placeholder 1 000) |
| Vulkan, lavapipe (Linux, CI) | pass | exact | pass | exact | pass at device pixel ratios 1 and 1.5 | n/a: no HDR swapchain |
| OpenGL, RTX 4080 SUPER | pass (1.7e-6, 1 ulp) | 1 code | as D3D12 | exact | **pass** at device pixel ratio 1.5 | n/a: Qt's OpenGL swapchain is SDR on Windows |
| Metal, Apple Silicon | open | open | open | open | open | open (the XDR Mac run) |

The window readback failures on Windows (24 Sep, 03:08 and 03:14 runs) were
the check, not the viewer: the dumps show the placed rectangle off the
intended scale and pan in every failing case (1:1 at 75.7 device pixels wide
instead of 80), so the check window was being scrolled or clicked while it
ran. The check now ignores input (`ViewerWindow::set_input_enabled`) and
records the viewport it saw. With that, the 03:17 run passes on D3D11,
Vulkan and OpenGL within 1 code. On D3D12 the check wrote no report: it hit
the old 30 s limit. With a 90 s limit it stops at the eleventh case (wipe 0.37
at 2x) after ten passes, the window exposed and the event loop alive: the
grab was asked for and no frame followed. The viewer now counts update
requests, presented frames and failed `beginFrame` calls, the check asks
again for a frame once a second while a grab waits (`nudges`, per case in the
report), and a `TIMEOUT` report carries the counters (`stall`), so the next
run says whether D3D12 drops the update request or refuses the frame. The
03:50 and 03:55 runs pass all 18 cases within 1 code, each after exactly two
nudges, and a viewer-side fallback for a lost update request never fired: the
requests arrive, but D3D12 hands a readback over only at a later
`beginFrame`, even after `QRhi::finish`, and nothing asked for those frames.
While a readback is out the viewer now keeps drawing, so a grab lands in the
frames it takes and no nudge is needed. The interactive path is unaffected
(it never reads back).
Found on the way: on Vulkan the window's surface outlived the
`QVulkanInstance` it was made from, and the check crashed on exit after
writing its report (lavapipe, exit 139); the viewer now destroys its platform
window before the instance goes.

Why a `QWindow` and not `QRhiWidget` (ADR-010, proposed): `QRhiWidget` draws
into a texture that the widget backing store composites, and that path is SDR
on every platform today. Gate B already proved the `QWindow` swapchain path
carries scRGB and HDR10 to the glass, so the viewer is that window, embedded in
the widget layout; the widgets around it stay ordinary Qt Widgets.

Why the scopes on the CPU first: they read the 768-side sample the browser
already reads (at most 590 k pixels, a few milliseconds), the result must be
bin-exact with the browser, and QRhi compute is unavailable on the OpenGL
fallback below 4.3. A compute path is added only if step 8's measurement says
the CPU path misses its budget.

Order: 1 and 2 first (the oracle and the spec), then 3 to 8 in order of
dependency (3 before 4 and 5; 6, 7 and 8 need only the composite targets), 9
and 10 together, 11, then 12 and 13.

## 16. Phase 3: the Qt UI, the next fifteen working days

Goal (docs/DESKTOP_APP_PLAN.md section 6): the full Studio workflow in the
native app with no Python installed. Open a package and a shot, scrub it,
reconstruct and grade it, compare, probe, measure and master it, and every
number and file matches what the browser Studio gives for the same actions.
Same rules as before, with the page itself as the oracle for behaviour.
`ui/index.html` names the actions and panels, `ui/app.js` holds the state and
what each control does, `ui/theme.css` holds the colours, and `ui/server.py`
holds the master's naming and parameters. Layout follows section 2.5 of the
desktop plan and the Pro-direction boards.

In hand from Phase 2: the viewer window (with its wipe, flip, zoom, pan and
guides), the frame engine, the display pass in every encoding, and the
measurements and scopes as data, all equal to the Studio's.

| # | Deliverable | Oracle | Done when | Days | Status |
|---|---|---|---|---|---|
| 1 | Theme: QSS generated at build time from the custom properties in `ui/theme.css`; IBM Plex Mono and Plex Sans Condensed embedded (OFL) | `ui/theme.css` | every colour in the QSS is a `theme.css` token (a build-time test), the surround is R = G = B | 1 | **done** 24 Sep: `app/theme/studio.qss.in` names the tokens as the page's CSS does (`var(--panel)`) and `cmake/rudra_theme.cmake` fills them from the `:root` of `ui/theme.css` at build time (no Python, no Qt; an unknown token fails the build); `app/theme.cpp` loads it with a palette from the same tokens under Fusion. `test_theme`: every colour in the sheet is one `ui/theme.css` uses, every grey R = G = B, the only hues the theme's named ones (plus its active-control ink and slider key), every background neutral, the fonts the tokens' first families, no colour literal in the app's C++. IBM's own TTFs (Sans Condensed 400 to 700, Mono 400 and 500, unmodified, OFL): the files carry per-weight legacy family names, so `RUDRA --theme-check` verifies at run time that every weight resolves under the typographic family; it does on Linux (fontconfig), and the Qt shell CI job and `NATIVE_GATE_B.ps1` run it. The first Windows run registered all six faces but looked them up as `IBM Plex Sans Condensed\r`: the generated token file had CRLF there; the generator now strips CR from its inputs and writes LF on every OS, the readers trim, and `test_theme` fails on a CR |
| 2 | Actions: all 33 `data-act` ids as `QAction`s with the Studio's shortcuts and menus; the native menubar on macOS, in-window elsewhere | `ui/index.html` `data-act`, `SHORTCUTS` in `ui/app.js` | a test extracts both from the page and compares them to the app's actions | 1 |  **done** 24 Sep: `engine/actions` holds the Studio's 33 actions (the 32 menu ids and `wipe`) with the page's menus, labels, key hints, check states, keys, wipe nudge, Keyboard sheet and `refreshMenu` enable rules, plus the native ones (open a package or a folder, quit, and the viewer's modes, wipe, guides, aspect masks and view peak in a View menu, on keys the page leaves free); `tools/emit_actions_golden.py` reads the page (`tests/golden/actions`) and `test_actions` holds the table to it. The app's window moved to `app/main_window.cpp` (a library, `rudra_app_ui`); it builds its menubar and shortcuts from the table and runs every action through `run(id)`. `rudra_app_tests` (Qt, offscreen, in CI): the menubar is the spec entry for entry, the page's labels, hints and checks, every page key reaches its action and no key is on two, a real key press runs its action, and the handlers do what the page's do (strength 0.1 a press rounded to hundredths, which the app had at 0.05). Actions whose work is a later step are off and say which |
| 3 | Session model (`engine/session`): the page's `state` in C++, with undo and redo as commands (5.6) where the page pushes undo | `ui/app.js` `state`, `params()`, `pushUndo` | the same scripted actions give byte-identical `params()` JSON (goldens from the page, headless) | 1.5 |  **done** 24 Sep: `engine/session` is the page's grading state (mode, strength, preserve, regions, peak, container, wipe, the B flip) with `snapshot`, `pushUndo` (60 deep, redo cleared), `undo`, `redo` and the handlers that change it: the mode buttons, the strength slider (undo on press), the peak slider (not undone), Preserve, the Region EV drag (0.01 EV a pixel, 0.002 with Shift, clamped to 4 EV, rounded to hundredths, a press that never moves leaves no undo) and double click, the resets, the containers, the wipe keys and the keydown map; `js_number` prints as JavaScript does. `tools/emit_session_golden.py` runs the whole page in headless Chromium (app.js unmodified but for one line exposing its closure) and drives it with real DOM events over 6 scripts; `test_session` replays all 251 states and `params()` is the same bytes, with the same undo and redo depths and the same wipe, bit for bit. The app runs every session action through it, enables Undo and Redo from its depths, and follows a wipe dragged on the plate. The native View peak submenu went: the view peak is the session's peak slider, as on the page (step 6 draws it) |
| 4 | Main window: media rail (drop zone, shot list, open by path), viewer toolbar (compare, layer, probe, guides, zoom, HDR badge), transport (prev, play, next, timecode, scrub), right rail (scopes; Reconstruct, Grade, Deliver tabs; frame measurements), pipe bar; the simple and full workspaces | `ui/index.html`, the Pro-direction boards | every panel present and wired; a side-by-side screenshot review against the boards | 2.5 |  **done** 24 Sep: `app/layout.cpp` builds the page as widgets, each named by the page's id (`app/widgets.cpp`: the segments, check rows, panel labels, scrub bar and the icon and transport buttons drawn as the page's SVGs), and `app/theme/studio.qss.in` styles them as `ui/theme.css` does. `tools/emit_layout_golden.py` renders the page headless at 1600 x 1000 in five states (full, simple, rails and scopes hidden, the Grade and Deliver tabs) and `rudra_app_tests` holds the window to it: a widget for every page id (nine drawn by the viewer or its overlays, named with their reasons), shown and hidden as the page shows them in every state, the page's words (labels, buttons, tool tips, placeholders, checks, fields, notes, slider ranges), the frame within 1 px of the page's, and the shell's controls (workspace, icon rail, tabs, a menu item bringing its tab forward) doing what `shell.js` does. The session gained the Window state (rails, scopes), the Compare source and the view layer. Found on the way, a Studio defect: `index.html` never closed the right rail's `.railscroll`, so the colour pipeline bar the page calls always visible rendered as a 26 px square in the top right corner and Master EXR scrolled away with the column; closed, the bar spans the foot of the window and the actions stay put, as theme.css intended |
| 5 | Scope widgets: waveform, histogram and vectorscope painted from `ScopeData` as `drawScopes` and `drawVector` draw them (zone colours, gridlines, the dashed 203 line, the clip band) | `ui/app.js` `drawScopes`, `drawVector` | a raster of the page's scope SVG and the widget's paint agree within 2 codes on 99 % of pixels | 1.5 |  **done** 24 Sep: the page draws both scopes as SVG, a display list, so the oracle is exact: `core/scope_draw` builds the elements `drawScopes` writes, with the same attributes as the same strings (`js_to_fixed` is JavaScript's `toFixed`, halves up on the exact decimal), and `test_scope_draw` holds them to the page's markup (`tools/emit_scopes_golden.py`, the page headless on five sets of scope data: plain, clipped with MaxCLL, a sparse histogram, MaxCLL above the scale and below it). `app/scope_widgets` paints that list as a browser shows an `<svg>` (viewBox, xMidYMid meet, SVG white space, the thin-stroke rule) and the vectorscope as the page frames its canvas. Rasters, against the page's own element screenshots with Plex served to it: the geometry and colour (labels hidden) within a mean of 1 code and 97 % of pixels within 8 codes, each label where the page puts it within a pixel, the vectorscope within 98.5 %. The plan's 99 % within 2 codes could not hold between two antialiasing rasterisers on one-pixel zig-zag bands and 4 px glyphs; the exact display-list equality is the stronger check of what is drawn, and the raster bounds catch a missing band or a label two pixels out (both tried). Found on the way: the view snaps the vectorscope to whole pixels as the browser does, and draws small text unhinted at its real size |
| 6 | Reconstruct and Grade panels: mode, strength, preserve, view peak, the three-band Region EV editor (the `#regions` drag behaviour), anchor and chroma carry, container and primaries | `ui/app.js` handlers | each control drives the composite, the view and `params()` as the page does (the step 3 goldens) | 2 |  **done** 24 Sep: the controls of step 4 plus `app/region_editor` (the page's `#regions`: a row a band with its swatch, range, value and unit; a press selects, a drag on the value scrubs it in the value's own coordinates, which keep a high-DPI mouse's fractions, a double click zeroes it) and the keys the page's keydown takes before its map (the wipe nudge, Escape, B held). The session golden now also records what the panels show after every gesture (the Region EV rows with their live and selected states, the region count, the strength and peak read-outs, Preserve and its hint, the mode that is on), and `rudra_app_tests` makes all 251 of the page's gestures on the window's own widgets (button clicks, slider drags, pointer drags and double clicks on the EV values, menu items, keys with Shift) and reaches the page's `params()`, undo and redo depths, wipe and panel words at every step. `core/js_format` gained the page's `fmt` (en-US grouping), `signed` (U+2212) and `nitsLabel`. Two fixes on the way: the page maps "z" and "Z" alike, so the letter shortcuts work with Shift too; and the golden's double click is now a browser's (two presses and releases, then dblclick), which also selects the row |
| 7 | Probe: the floating box and the rail panel at the cursor (`probeAt`, `showProbePanel`): nits, stops, baseline and model values, masks, the SDR codes | `ui/app.js` | text identical to the page's for the same pixel | 0.5 |  **done** 24 Sep: `core/readouts` writes the probe panel and the floating box as `showProbePanel` and `showProbe` do (`tests/golden/readouts`: the page's writers run headless on seven pixels, from none to a clipped 12 346-nit specular), and the app reads the pixel under the pointer from the full-resolution composite the measurement keeps (`FrameMeasure::probe_at`, the viewer's `on_hover` in frame pixels); the box is a window of its own so it can sit over the viewer's swapchain, placed as the page places it. Probe on, or Alt held: the page's readout promised Alt and never did it, so the page's `pointermove` now honours Alt too |
| 8 | Frame measurements panel (`showMetrics`), the clip bar, the pipe bar's warning | `ui/app.js` `showMetrics`, `paintClipBar`, `updatePipe` | text identical to the page's for the same frame | 0.5 |  **done** 24 Sep: `engine/measure` is the page's `computeStats` for the app: the chain Phase 2 held to the browser (composite, corrected baseline, exact reductions, the sample, scopes, vectorscope, mask and clip coverage) run on a worker 90 ms after the grade settles, a stale result dropped; `Viewer.MeasureFrameIsThePagesComputeStats` runs it from the frames the page received and gets its coverage to the bit and its metrics within the GPU composite's bound. `core/readouts` writes the Frame panel, the mask and time status, the source line, the pipeline bar and its warning, and the clip bar's widths as the page's `showMetrics`, `updatePipe` and `paintClipBar` do, and the app shows them (`AppMeasure`: panel, bars, scopes, a re-measure on a grade change). Found on the way: `toLocaleString` rounds the shortest decimal form (99.9995 to three places is 100.000) where `toFixed` rounds the exact value, so `js_fmt` does the same; Playwright hands a Python 0.0 to the page as -0, so the harnesses pass their inputs as JSON text; and the page's pipeline bar claimed "PQ · Rec.2020" for the view until a first frame was measured, which its own shell.js calls the wrong thing; the markup now says what updatePipe writes |
| 9 | Deliver tab: a master EXR of the frame or the whole sequence as an engine background job with progress and cancel; `render_master` moves out of the CLI into `deliver` so the app and the CLI share it | `ui/server.py` `/api/master/plan` and `/api/master` | the same paths and names as the plan, and the same EXR and sidecar bytes as the Studio for a 3-frame sequence (within the master goldens' bound) | 2 | **done** 24 Sep: `deliver/master` holds the request, `write_master` and the render plan; `master_targets` is `ui/server.py` `master_targets` on 21 cases (`tools/emit_render_plan_golden.py`: the folder, the name, the image or the numbered sequence, and every refusal with the server's message); `publish_master` writes each EXR and sidecar in a `.rudra-render-*` staging folder and links them into place, a copy when a link is refused, never replacing a file. `engine/master_job` renders the targets in order off the UI thread, reports each frame, stops after the frame in hand on a cancel and on the first failure with what was done (`test_master_job`); the app's Master EXR runs it, the button stops it while it renders (`AppDeliver`). The CLI keeps decode and inference only, and `master-check` still passes the Studio's master goldens through the shared code (pixels within 1 half ulp, headers and sidecars equal) |
| 10 | Checkpoint manager and first run: find, verify and switch model packages and the runtime and device (the page's `#ckpt`, `#device`) without a restart; the first-run wizard runs the viewer's HDR card on the display it opens on | `/api/model`, `/api/checkpoints` | switching packages mid-session keeps the session; the wizard reports the display's real peak | 1.5 | **done** 24 Sep: `engine/model_catalog` is the server's discovery for packages (`find_checkpoint` and `loadable_models` on 11 layouts, `tools/emit_catalog_golden.py`): roots in order, a `models.json` root described not guessed (its default, else the first registered SDR2HDR package, the temporal refiner never listed), a training root by shipped then newest export, `_invalid_*` hidden; a folder of packages with no registry opens its first readable package, since a package says what it is. `infer/self_test` is Gate A's golden check moved out of the CLI (`diff` now calls it): the first time a package runs on a backend its goldens run, and one that drifts is refused (`ModelSelfTest`, with a golden value moved). The app: File > Model packages (the list, the runtime and device, Add folder, Use) and Help > Check the display and the model; `use_model` verifies, opens and tests off the UI thread and swaps the backend with the frames, the frame on screen, the grade and undo kept, the old engine's late frames dropped (`AppModels`: 8 tests); a bare start opens the package used last on its backend, else the catalog's pick, and says where it looked when there is none. The first run shows `core/hdr_card` (Gate B's card, now shared with `rudra-viewer-check`) in a viewer of its own on the display it opened on and reports that display's peak and what will clip (`display_report`). The `#device` pill is the page's `info.gpu`: CPU, or the device's name for a GPU; the GPU's own model name needs the CUDA headers and is left for the Windows pass. `tools/export_model.py` puts `models.json` beside the packages |
| 11 | The rest of the page: the sheets (shortcuts, about, copy metrics, scopes and delivery), drop to open, recent shots, settings kept between runs | `ui/app.js` | every remaining `data-act` works | 0.5 | **done** 24 Sep: Measure > Copy and Deliver > Copy write the page's bytes: `core/js_json` is `JSON.stringify(value, null, 2)` (insertion order, `String(x)` numbers, NaN as null, its escapes) and `core/copy_texts` builds `state.metrics`, `state.scopeData` and `deliveryRecord()` key for key, held to the page's own copy actions run headless with the clipboard recorded (`tools/emit_copy_golden.py`, 5 cases, `test_copy_texts`); `region_ev` only when a region is graded, as `graded()`. The sheets are the page's overlay: non-modal, "Esc, or click anywhere, to close", About's Device the `#device` pill. Open takes several stills and a drop brings frames as `addFiles` does (appended, the first of them shown, "added N frames"), a folder as a shot, a model package folder to the checkpoint manager; the drop zone lights while a drag is over the window, and the viewer's own window forwards drops. File > Open recent keeps the last ten shots, newest first, with Clear recent. The window's place and size, the workspace, the rails and scopes, the inspector tab, the container and the Render fields are kept between runs (`restore_settings` at start, saved on close; tests start clean). No page action waits on a later step now (`AppActions`, `AppCopy`, `AppOpen`, `AppSettings`). Adding frames restarts the engine on the longer list, so the cache is rebuilt; fine at this size, noted for Phase 4 |
| 12 | Review: the whole workflow on Windows with no Python on the machine, scripted and by hand; Phase 3 exit in `STATUS.md` | | open, scrub, grade, compare, probe and master a 240-frame folder with the numbers matching the Studio's | 0.5 | **scripted, Linux passes** 24 Sep; the Windows run is `scripts/NATIVE_PHASE3_EXIT.ps1 -Frames <folder>`. `RUDRA --workflow-check` (`app/workflow_check`) drives the real window: the package on the backend asked for with its goldens checked, the folder, every frame scrubbed with the transport and every 24th compared with its own decode, a grade of five moves undone and redone to the same `params()`, the wipe, the flip and the layers, the probe and the measurements, and image masters of the first, middle and last frames; the report is JSON. `rudra-native master-compare` then renders each of those frames through the CLI master with the parameters the app used and holds the app's EXR and sidecar to it (1 half ulp, headers and sidecars; a moved strength fails it). On Linux, ONNX Runtime CPU, 240 frames of 480 x 270: all seven steps pass, 240 of 240 delivered as themselves (11 checked against their decode), median 933 ms per frame on two cores, and the three graded masters byte-identical to the CLI's (0 half ulp, sidecars byte for byte). The exit script builds RUDRA with ONNX Runtime (DirectML), OpenCV and Qt beside it, runs the app tests, runs the workflow with a PATH of the app's folder and Windows only, compares the masters on the same backend and prints the by-hand checklist (`STATUS.md`) |

**Revision, 24 Sep: the Pro look and the Studio's preview size.** The first
Windows run showed the window as a copy of the browser Studio, where the
target was always the Pro-direction boards, and slow on 2560 x 1440 frames.
Both changed without touching behaviour:

- The look is now the boards' (`app/theme/pro.css`, the one source; the sheet
  generated from it as before). Unified toolbar with the Reconstruct / Grade /
  Deliver tabs in the middle and the machine pill, Probe, Scopes, inspector,
  Export and Help on the right; the sidebar library (open by path, the shot
  row with its picture, Open recent below it, collections counted from the
  clipping lane, the probe card, the model card); the viewer's compare bar and
  the HDR and MaxCLL badges on the surround (a strip rather than floating: a
  widget cannot sit over the viewer's own swapchain window on every platform);
  the colour pipeline as chips; the timeline with a 20 px timecode, round
  transport and a filmstrip of the frames as they arrive over a clipping lane
  (gold where the SDR clipped, violet where the shadow mask covers over 1 %);
  the inspector's grouped cards (Reconstruction, Region exposure, Delivery with
  the Render card and Master EXR, This frame, the scopes, the log); switches
  for the check rows; the welcome and the export sheet from their boards. Type
  is Geist and Geist Mono (OFL, embedded: the boards' named fallback for SF,
  which cannot ship). Every grey stays neutral, R = G = B, where the boards
  use Apple's blue greys: a tinted chrome biases the judgement of the
  picture. The scopes keep the Studio page's plot greys and Plex labels, so
  they stay held to its rasters. Every control keeps the page's id and
  handler: the session, action, measurement, delivery, catalog and copy tests
  pass unchanged; the layout tests now hold the window to the boards (the
  frame, the badges either side of a centred compare bar) and list the few
  words and placements the boards changed, each with its reason.
- Frames preview at the Studio's 1600 on the long side (`media` `fit_max_side`,
  `ui/server.py` `_fit`: INTER_AREA in float32, held to it on 7 cases,
  `tools/emit_fit_golden.py`); the header keeps the source resolution; masters
  still decode at full size.

Order: 1 to 3 first (look, actions and state are what everything else binds
to), then 4, then 5 to 8 in any order, then 9 and 10 (they need the engine
jobs), 11, 12.

The one structural change: step 9 moves the master pipeline, which is in
`cli/master.cpp` today, into a library the app can call. It goes to
`deliver/` (the stages are core and deliver already), and the CLI keeps only
argument parsing, so the layer rule stays as it is.

---

## 17. Phase 4: video delivery, the next twelve working days

Goal (docs/DESKTOP_APP_PLAN.md section 6): a movie in, an HDR10, HLG or
ProRes master out, with its audio, checked before it is published and never
replacing anything; the same queue as `rudra batch`, resumable from either
side. Same rules as the phases before: the Python is the oracle
(`rudra/video.py` convert_video, `rudra/delivery/video.py` encode_sequence,
`rudra/delivery/profiles.py`, `rudra/batch.py`), each step ports one part and
holds it to goldens the Python writes, and a step is done when its test
passes.

**One decision up front.** The plan named libav linked in-process for decode.
The Python drives the ffmpeg and ffprobe programs as subprocesses, for decode
(zscale into rgb48 on a pipe), encode (a 16-bit PNG spool into libx265 or
prores_ks) and QC (ffprobe's JSON); x265 is GPL, and a subprocess keeps it out
of the app. The native port does the same: the same programs with the same
arguments give the same bytes, which is what makes the Python an exact
oracle. In-process libav stays for the viewer's random access into long
movies, a later step, and is not needed for delivery.

| # | Step | Oracle | Done when | Days |
|---|---|---|---|---|
| 1 | Probe and the input contract: find ffmpeg and ffprobe, read ffprobe's JSON, the clock (`timing`: CFR, continuous timestamps) and `input_contract` (HDR, alpha, interlace, rotation, anamorphic, odd sizes, colour tags or explicit overrides) with every refusal | `rudra/video.py` probe, timing, input_contract, has_alpha | the same contract, clock and messages on a set of small clips the emitter makes with ffmpeg | 1| **done** 24 Sep: `platform/process` runs a program with an argument vector, never a shell (`run_process` to completion with stdout and stderr captured; `Process` streams stdout while stderr goes to a log, `kill` on an error path; `CreateProcessW` with the runtime's quoting on Windows, `posix_spawnp` elsewhere; `find_executable` is `shutil.which`), tested with `cmake -E` so it runs on every build machine. `media/video_probe` runs ffprobe with video.py's two argument lists and reads its JSON into `VideoStreamInfo` and per-frame timestamps; `input_contract`, `video_timing`, `has_alpha`, `decoder_filter` and `open_video_source` (convert_video's order: one video stream, contract, clock, alpha, constant frame size) give the Python's contract, clock (exact doubles) and refusal messages. `tools/emit_video_golden.py` makes 14 small clips with ffmpeg (tagged H.264 at 24000/1001 starting at 10 s, untagged, sRGB full range, BT.2020, PQ, HLG, ProRes 4444 with alpha, interlaced, rotated by a display matrix, anamorphic, odd width, a dropped frame, RGB PNG in MOV, two video streams), keeps them once made, and records ffprobe's JSON and the Python's verdict for 23 clip and argument cases (24 and 15 clips since step 3 added colour bars); `test_video` holds the port to them from the recorded JSON on any machine and from a live ffprobe when one is on PATH. One difference: an `avg_frame_rate` of `0/0` raises ZeroDivisionError in the Python and is the zero-rate refusal here |
| 2 | Decode: ffmpeg into 16-bit RGB (and RGBA) on a pipe through `decoder_filter`, frame by frame, a truncated or extra frame refused | convert_video's decode loop | frames equal the Python's decoded arrays, bit for bit | 1| **done** 24 Sep: `media/video_decode`: `decoder_command` is convert_video's ffmpeg command argument for argument (checked against the command the Python itself ran); `VideoDecoder` reads each raw rgb48le or rgba64le frame off the pipe as `read_frame` does, stderr in `decode.log`, and refuses with the Python's words a stream that ends early, a partial frame, extra frames and a failed decoder (with the log's tail); `rgb_from_frame` is `decoded[..., :3].astype(float32) / 65535` as a planar image. The emitter runs convert_video itself on six clips (H.264 limited and full range, untagged with overrides, BT.2020, RGB PNG, ProRes 4444 with alpha) with the predictor stubbed, and records the decoder command and the SHA-256 of every frame `read_frame` returned; the test decodes the clips and holds every frame to those bytes when the ffmpeg is the recording build (its version line is in `decode.json`), and to the frame count and shape otherwise |
| 3 | The video predictor: canonicalise the SDR, convert primaries to Rec.2020, the shadow smoother with its cut detector, residual scale, tiles blended as the Python blends them | `Predictor.predict`, `ShadowSmoother` | HDR frames within the package's tolerance of eager PyTorch on the clips; the same cuts and weights | 1.5| **done** 24 Sep: `core/video_predict` holds the parts around the network in float32 as the tensors are: `canonicalize_sdr` (transfer and range to canonical sRGB code), `srgb_code_to_rec2020`, `area_resize` (aten's adaptive average pool, bins and divisions as it does them), `torch_linspace` (the CPU kernel's fused vector path), `ShadowSmoother` (weight in double, reset at a cut), the tile origins and the video path's own feathers; `engine/video_predictor` runs the frame pass once, smooths its shadow weight, and reconstructs the frame whole or in tiles as the network's fields through the composite with preserve_outside and recovery all, blended and normalised as the Python blends. `tools/emit_video_predict_golden.py` runs `Predictor.predict` on the shipped checkpoint over four sequences (tiled 32/8 with a hard cut half way and retention 0.5, whole-frame BT.2020, RGB with retention 0.9 and cuts off, ProRes 4444 alpha in 24/4 tiles that do not divide the frame), recording the raw 16-bit inputs, the canonical frame and thumbnail it built, the raw and smoothed weights, the cuts and the HDR. `test_video_predict` holds the pure parts to it (linspace and the thumbnail within 1 ulp, the canonical frame within 2e-6, the smoother's weights and cuts exact); `test_video_predict_real` runs the package on LibTorch and ONNX Runtime: every cut and weight the same, HDR within 2.7e-6 of eager PyTorch, tiles included (the package's tolerance is 1e-5 and 3e-4). The emitter added a colour-bars clip to the video goldens so a cut is a real one (24 contract cases, 15 clips, 7 decodes), and `.npy` reads uint16 now |
| 4 | Mastering and the spool: `encode_master` for HDR10, HLG and ProRes (PQ), MaxCLL and MaxFALL per frame, the 16-bit PNG spool (alpha carried), disk space checks | `delivery/profiles.py`, the spool writer | the same code values and the same PNG bytes | 1 | **done** 24 Sep: `deliver/video_master`: `master_video_frame` is the loop body between the predictor and the spool (the finite checks with the Python's messages, `encode_master` for the format, MaxCLL and the frame average as float32 `maxrgb.max()` and `maxrgb.mean()`, the latter numpy's pairwise float32 sum now in `core/numeric`, then `(clip(code) * 65535 + 0.5)` to uint16, BGR, the decoded alpha appended); `light_ceilings` gives the encoder's MaxCLL and MaxFALL; `spool_space_low` is the disk check. `media/png16` writes and reads the spool with OpenCV as `cv2.imwrite` does. `tools/emit_video_master_golden.py` runs convert_video itself on two clips with the step 3 HDR frames standing in for the predictor and stops it at `encode_command`, keeping the spool it wrote and the two ceilings, for HDR10 at 1000 and at 4000 nits with a 1000-nit knee, HLG at 1000 and 600, and ProRes 4444 with alpha (30 frames). `test_video_master`: HLG codes identical, every frame's MaxCLL and average identical, the ceilings identical, the float32 mean identical to numpy's on 12 sizes up to 1080p; PQ codes within one of 65535 on about 1.6 % of samples, because numpy's float32 power is SIMD code (SVML on AVX-512) that is not correctly rounded, so the Python's own PQ codes depend on the CPU, while libm's `powf` here is. PNG bytes are compared when the codes are identical and OpenCV is the recording build (this container's Python has 4.13, the C++ 4.6) |
| 5 | Encode and publish: the ffmpeg command, argument for argument, for all five presets; staged beside the output and renamed into place; nothing replaced | `encode_command` | the same argv; outputs decode | 1| **done** 24 Sep: `deliver/video_encode`: `encode_command` builds the ffmpeg command as the Python does (the x265 parameters with the master-display string rounded half to even and the MaxCLL pair, HLG's own parameters, ProRes profile, tag and alpha bits, the audio map and codec, the start offset and duration as Python's `repr`, `+faststart+write_colr` for MP4 and MOV in any case); `StagingDir` is the temporary folder beside the output, removed with its owner; `publish_video` refuses when either target appeared and otherwise renames the master and its sidecar into place. The step 4 emitter now also records the command convert_video itself built on ten runs (HDR10, HLG, ProRes 422, 422 HQ and 4444 with alpha, AAC with CRF 18 and preset slow, no audio into MKV, HLG into `.MOV`, start 10 s and 0 s); `test_video_encode` matches each argument, encodes the Python run's own spool with the native command for HDR10, HLG and ProRes 4444 when ffmpeg is on PATH (the right codec, transfer and frame count), and checks publishing never replaces a file or a sidecar. `VideoClock` moved to `core/video_clock.hpp` so deliver reads it |
| 6 | QC: `quality_check` (codec, pixel format, tags, frame count, every timestamp, HDR10 SEI and its values, HLG without static metadata, ProRes tag, duration, audio count, rate, channels, offsets, a complete decode) and `check_alpha` | `quality_check`, `check_alpha` | the same pass or the same errors on good and broken files | 1| **done** 24 Sep: `deliver/video_qc`: `evaluate_video_qc` makes every check of `quality_check` on ffprobe's JSON (read in its own key order, so the record keeps it) with the Python's words and order, `qc_verdict` gives "Export QC failed: ..." or the record the sidecar carries, `alpha_verdict` is check_alpha's; `media/video_alpha` extracts the master's alpha on a pipe and compares every pixel with the spool's fourth channel; `engine/video_qc` probes the master, checks it, decodes it completely, then gives the verdict, as convert_video does. `platform/process` took `require_executable` and `run_tool`, and `core/video_clock` took `Fraction`, so deliver reads them. `tools/emit_video_qc_golden.py` has convert_video make five masters end to end (HDR10 with audio copied and with AAC, HLG, ProRes 422, ProRes 4444 with alpha; a clip with audio added to the video goldens), derives five broken ones (a transfer tag changed in the bitstream, a frame dropped, the audio removed, re-encoded without the HDR10 SEI, a wrong ProRes tag) and records 14 verdicts, adding the wrong mode, HDR10 checked as HLG, light metadata that disagrees and ProRes 422 checked as 4444. `test_video_qc`: every verdict and message the same from the recorded probes and live, each passing record byte for byte as `json.dumps` writes it (live when the ffmpeg is the recording build), and the alpha record the same as the sidecar's |
| 7 | `rudra-native video`: convert_video end to end, the sidecar report key for key | `convert_video` | on three clips (HDR10 with audio, HLG, ProRes 4444 with alpha) the published file passes QC and decodes to the Python's frames; the report's keys and values match | 1| **done** 24 Sep: `video/convert` is convert_video: the argument and output checks in the Python's order and words (suffix, ProRes needs MOV, nothing overwritten, the encoders and zscale in this ffmpeg, smoothing, tiles, CRF and mastering, then the peak and knee), the probe and contract, the disk check, the decode, predictor, mastering and spool per frame with the progress the queue reads and the lines the Python prints, the encoder, QC and the alpha check on the staged master, the HLG reference, and the report written as `json.dumps(report, indent=2)` and published beside the master; a cancel flag is checked once a frame for the app. It lives in a new `video/` layer between infer, media and deliver and `engine/`, so `rudra-native video <package> <input> --output ...` (all of video.py's options, plus `--runtime` and `--device`) runs it without Qt; the predictor and QC composer moved there from engine. `tools/emit_video_convert_golden.py` runs convert_video on the checkpoint on three clips (HDR10 with audio copied, HLG at 1200 nits smoothed at 0.5 in 32/8 tiles on colour bars, ProRes 4444 with alpha and no audio) and keeps the masters and reports. `test_video_convert_real` on LibTorch and ONNX Runtime: every report key in the same order with the same value (the paths, spool and staging folders and elapsed time aside; per-frame weights and light within the package's tolerance, a few of them not bit-equal), QC passed; the HDR10 and HLG masters byte-identical to the Python's on both runtimes, the ProRes 4444 master within four 10-bit steps anywhere and 0.35 of a 16-bit code on average when decoded (its PQ codes differ by one in 65535 where numpy's power does, step 4, and ProRes is lossy); every refusal before any work, with the Python's words |
| 8 | Frames to video: `encode_sequence` (a finished HDR sequence to HDR10, HLG or ProRes) | `rudra/delivery/video.py` | the same argv, QC and tags | 1| **done** 24 Sep: `deliver/sequence_encode` ports encode_sequence: the four targets, `encode_sequence_frame` (primaries to Rec.2020 through float32 as the Python goes, the shoulder into the peak, PQ, HLG through the inverse OOTF, 16-bit rounding), the command with the swscale BT.2020 matrix, `+write_colr` and `prores_metadata` when this ffmpeg has them (`ffmpeg_supports`, cached), the x265 VUI and HDR10 parameters; frames go down ffmpeg's stdin one at a time (`platform/process` gained a stdin-fed `Process::start_writer`, SIGPIPE ignored as a broken pipe is in Python), and the tags are read back where each format keeps them (`colour_tags` through ffprobe with its old-build retry, `prores_frame_tags` from the frame header, `container_colr`), refusing an untagged file with the Python's words. `rudra-native deliver <frames> --output <stem> ...` is `rudra deliver`: .exr and .npy frames in name order, MaxCLL and MaxFALL measured after the shoulder, the same JSON report. `tools/emit_sequence_encode_golden.py` records _encode_frame's codes for every target from Rec.709, Rec.2020 and P3 with and without the shoulder, and `rudra deliver` on three 128 x 72 frames for each target (the command it ran, its report, the tags and colr atom of the file). `test_sequence_encode`: codes within one of 65535 (numpy's SIMD power and log are not correctly rounded, libm's are), every command argument, MaxCLL and MaxFALL, the tags of live encodes, and the CLI's report byte for byte. Found on the way: x265 3.5 crashes (exit 139) at 48 x 32 with preset slow, in the Python as here, so the goldens use 128 x 72; and two native tests iterated a temporary's JSON (a dangling range-for) and silently ran no cases, now fixed |
| 9 | The queue runs video jobs: `run_queue` with its locks, digests, retry and resume | `rudra/batch.py` | a three-clip queue killed mid-clip resumes to the Python's final state; each side resumes the other's queue | 1| **done** 24 Sep: `video/queue_runner` makes convert_video the queue's runner: a job names its checkpoint as the Python does (the `.pt`, whose digest is its identity), and the package that runs it is the one exported from that checkpoint, by the manifest's source SHA-256 (`--package`, or `RUDRA_PACKAGE_ROOTS`, `dist/models` and the queue's folder); the backend is opened once per checkpoint and device; progress goes into the state as the Python's dict. A stop (`ErrorCode::Cancelled`, from Ctrl+C in the CLI or the app's flag, checked once a frame) is the Python's KeyboardInterrupt: the job is left `interrupted` with its words and the queue ends. `rudra-native batch run <queue> [--retry-failed] [--package] [--runtime] [--device]` and `batch status`. `tools/emit_video_queue_golden.py` runs a three-clip queue (HDR10 with audio, HLG smoothed, ProRes 4444 with alpha) through `run_queue` straight and stopped at the second clip, keeping the stopped project. `test_video_queue_real`: the Python's stopped queue resumes here (job 1 verified and skipped, its master untouched) to the Python's final state key for key, artifacts held to the files; a native run stopped the same way leaves the Python's interrupted state and resumes to the final one; a job without its package fails and the queue moves on. By hand: `rudra-native batch run` stopped with Ctrl+C at the second clip, then `rudra batch run` in Python on the same queue: job 1 verified, skipped, the rest complete, exit 0 |
| 10 | ffmpeg on the machine: capability probe (encoders, zscale) and a 16-frame HDR10 self-test per ffmpeg binary, cached by its hash | the probe in convert_video | a missing encoder or a broken build is reported before any work | 0.5| **done** 24 Sep: `video/ffmpeg_check`: `probe_ffmpeg` finds ffmpeg and ffprobe, reads the encoder and filter tables for libx265, prores_ks, zscale and alphaextract (whole names, so `libx265rgb` is not `libx265`), asks for `write_colr` and `prores_metadata`, and hashes both binaries; `missing()` says in words what a delivery would lack. `ffmpeg_self_test` runs the real pipeline on 16 frames (a tagged SDR clip every build can make, lavfi into FFV1, decoded through zscale, mastered, spooled, encoded to HDR10 with its SEI, QC'd) and keeps a pass in the cache (`default_cache_dir`: `RUDRA_CACHE_DIR`, `%LOCALAPPDATA%\RUDRA`, `~/Library/Caches/RUDRA` or `$XDG_CACHE_HOME/rudra`) keyed by both binaries' SHA-256 and the version line (a packaged ffmpeg is a small binary over shared libraries); a build without libx265 or zscale fails with convert_video's own words before anything runs. `rudra-native ffmpeg-check [--ffmpeg] [--ffprobe] [--force] [--no-self-test]` prints the report and exits 1 when something is missing. `test_ffmpeg_check`: the PATH build's capabilities, a stand-in ffmpeg without libx265 and zscale refused before any work, the self-test passing in 0.7 s and cached until the build changes. The queue keeps the Python's behaviour (each job reports a missing encoder itself); the app runs this check before its first export (step 11) |
| 11 | The app: a movie opens as a shot (frames decoded on demand), the export sheet's HDR10, HLG and ProRes tiles go live as queue jobs, a queue window with progress and resume | the Pro export board | a movie scrubs, grades and exports from the window | 1.5| **done** 24 Sep: a movie opens as a shot as the Studio opens it (`media/sequence`: ui/sequence.py's video half, counted by packets with ffprobe, the rate as a float, each frame extracted on first use with `-accurate_seek -ss` into the Studio's cache folder, `sha1` of the resolved path, written then renamed; `ensure_frame_file` lets the engine and the master decode a frame that is not there yet; `platform/hash` gained SHA-1). In the window: Open and a drop take movies, the shot's title, frame names (`<stem>_000001`) and rate are the movie's. The export sheet's HDR10, HLG and ProRes 422 HQ tiles are live for a movie: the file is named from the Deliver tab, this ffmpeg is asked for libx265 or prores_ks and zscale first, the export is written as a queue file in batch.py's format beside the master (`<name>.<format>.queue.json`, the package's manifest as its checkpoint) and run on a worker (`app/video_queues`, one queue at a time, on the backend in use); nothing existing is replaced. The queue window (`app/queue_window`) shows each export's state as the runner writes it (waiting, reconstructing frame N of M, encoding, checking, complete, failed with its reason, stopped), with Stop, Resume and Remove, and the list is kept between runs. `RUDRA --workflow-check ... --movie CLIP` adds the movie to the scripted workflow: opened, every frame scrubbed, HDR10 exported through the queue and its QC read back. Tests: `Sequence.AVideoOpensAndReadsLikeThePython` (the Studio's describe() and its extracted PNGs byte for byte), `AppVideo` (a dropped movie opens, scrubs and names its frames; the tiles, the queue file, the window's words, refusals and the list kept). On Linux with ONNX Runtime the workflow's movie step passes and its HDR10 master is byte-identical to the one `rudra video` makes from the same clip |
| 12 | Review: the scripted and by-hand pass on Windows (an ffmpeg with libx265 and zscale beside the app), `STATUS.md` | | a clip with audio in, an HDR10 master out that passes QC, from the app and from the queue | 0.5| **scripted, Linux passes** 24 Sep; the Windows run is `scripts/NATIVE_PHASE4_EXIT.ps1 -Clip <movie>`: the Phase 3 build with the native tests, `rudra-native ffmpeg-check` on the machine's ffmpeg, the video pipeline's tests against the goldens, `rudra-native video` to HDR10 with audio and to ProRes 422 HQ (QC read back from each report), a three-job queue stopped hard as its second job starts and run again to completion, and `RUDRA --workflow-check --movie` on a PATH of the app, ffmpeg and Windows only (the Phase 3 workflow on the clip's first 48 frames, then the movie scrubbed and exported through the app's queue), with the by-hand checklist. On Linux (ONNX Runtime CPU) every part passes; the app's movie export is byte-identical to `rudra video`'s |

Order: 1 to 7 in order (each needs the one before), 8 and 10 any time after 5,
9 after 7, 11 after 9, 12 last.
