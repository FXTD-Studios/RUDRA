# RUDRA user guide

RUDRA turns SDR footage (stills, frame sequences, movies) into scene-linear
HDR: an ACES 2065-1 EXR master for grading, or HDR10, HLG and ProRes movies
for delivery. It always starts from an analytic inverse of the SDR's tone
curve (the *baseline*), fills what the SDR clipped, and can add a learned
model's reconstruction on top (optional, off by default), and it shows you
where it made something up.

This guide is for the desktop app, RUDRA 1.2.4. The illustrated guide is at
https://www.fxtdstudios.com/rudra-docs/. Help > Getting started shows the short
version inside the app; F1 opens this page.

## 1. Install

- **Windows 10 or 11 (x64):** run `RUDRA-<version>-windows-x64-setup.exe`
  (installs for your user, no administrator prompt), or unzip the portable
  ZIP anywhere and run `RUDRA.exe`. ffmpeg comes with the package.
- **macOS 13 or later (Apple silicon):** open the DMG and drag RUDRA to
  Applications. Movies need an ffmpeg with `libx265`, `prores_ks` and
  `zscale` on the PATH (`brew install ffmpeg`) unless the DMG says it carries
  one.

**The first start.** *Welcome to RUDRA* checks the display (HDR or SDR, and
its real peak brightness, shown on an HDR test card), names the GPU it found
(with or without a model), and, if a model package is installed, loads and
tests it on the backend you pick (**Load and test**).
The model is optional: **Continue** or **Start on CPU** both get you to work,
and nothing runs a model until Reconstruct > Use the model is on. Then
*Getting started* shows the five steps below, once (and once again after an
update that changes them). Help > Check the display and the model runs the
check again; Help > Getting started shows the steps.

The viewer opens as a comparison: a wipe with the SDR original on the left
and RUDRA on the right, at a 1,000-nit display peak. A project opens at the
peak it was saved with.

## 2. The five steps

### Source: open the shot

The Source card reports movie dimensions, pixel format, primaries, transfer,
matrix and range from the file headers. Missing tags say "not reported";
these are reported tags, not a measured tone curve. Limited-range movies
show the current super-white decoding limitation (not a claim that such
pixels were detected), and PQ/HLG inputs show an HDR-source warning.
Still/sequence inspection shows the current decoded frame's recognised profile
and primaries, any Rec.709 fallback, and applied EXIF orientation. It updates
when you change frames; unavailable information stays explicit. Profile names
are displayed as plain text. This inspection does not override decoding or your
grade and does not identify the original tone mapper.

- **File > Open frames…** (O) adds stills; **File > Open folder of frames…**
  opens a numbered sequence; a movie (`.mov`, `.mp4`, `.mxf`, `.mkv`, …)
  opens as a shot of its own. Dropping files or a folder on the window does
  the same.
- **Stills keep their colour and orientation.** A still's own colour tag
  (an ICC profile, a PNG cICP / sRGB / cHRM chunk) sets the primaries the
  master converts from: Display P3 (phones), Adobe RGB (1998), Rec.2020 or
  sRGB / Rec.709. Untagged files are read as sRGB / Rec.709, as before. A
  profile RUDRA does not recognise is read as sRGB / Rec.709, and you should
  check the colours. The EXIF orientation of a phone or camera photo is
  applied, so portrait shots come out upright. The viewer still shows the
  picture as Rec.709; the master converts correctly.
- **Limited-range video above white** (codes 236–254, "super-whites") is
  clipped at decode in 1.0, and Fill clipped highlights rebuilds it. If that
  detail matters, keep the original and validate a preprocessing workflow
  that maps headroom into the supported range. Merely switching the range
  tag to full does not guarantee preservation (docs/SUPER_WHITES_DESIGN.md).
- **Reconstruct > Source** says how the SDR was made. This matters more than
  anything else: the baseline is the inverse of that curve.
  - *BT.1886* (the default): SDR as a display shows it, each code to the
    power 2.4, white at 203 nits. Right for graded and broadcast video, and
    the best measured on real SDR by far (docs/RESULTS.md). On a still read
    as sRGB the mid-tones come out about a third of a stop darker.
  - *BT.1886 shadows* (opt-in): BT.1886 from SDR code 40 up, with the blacks
    real HDR masters keep below it. Measured on five Netflix Open Content
    titles, real graded HDR sits 2–7 stops above code^2.4 in deep shadow.
    Try it when the default looks crushed in the darks. On held-out real SDR
    it scored +0.04 to +1.3 dB PU21 over BT.1886, but on very dark scenes it
    can lift blacks about half a stop above some grades, so judge it on an
    HDR display (docs/ai/SHADOW_CORRECTION_RESULT.md).
  - *Unknown (ACES inverse)*: RUDRA's default before 13 Oct 2026; projects
    saved with it keep it.
  - *ACES*, *filmic (Hable)*, *AgX*: CG renders and games with those tone mappers.
  - *Camera log*: a log clip viewed through a LUT you know.
  - *Rec.709, plain clip*: video that was simply clipped at white.

**Generated video** (text-to-video and image-to-video tools, renders from
game engines, upscaler output): these are 8-bit SDR with clipped highlights
and no real camera curve. Start with the default, *Source: BT.1886*; if the picture has a
filmic shoulder (soft roll-off into white), try *filmic (Hable)* or *AgX* and
keep the one whose baseline looks most natural at a high view peak. Leave the
model's strength low (or mode *Highlights*): generated frames change from
frame to frame, and a strong reconstruction can flicker. Check a few frames
across the clip with the scrub bar before exporting.

### Calibrate (optional)

On the Reconstruct tab, **Calibrate** lets you click up to three patches
(black, an 18% grey card, a highlight) and type the nits each should be. The
curve is fitted through them. **Reference** fits the curve to a graded HDR
version of the same frame (EXR, or 16-bit PQ PNG/TIFF) when you have one.

### Reconstruct

- **Analytic or AI-assisted.** By default RUDRA reconstructs analytically: the
  inverse of the source curve with your calibration, reference and grade; no
  model runs and none needs to be installed. **Reconstruct > Use the model
  (AI-assisted)** adds the model's reconstruction on top; the status bar says
  which is in use and every master's sidecar records it. Movie exports
  follow it too, with your whole grade.

- **Learned ACES 2.0, and when not to use it.** The learned ACES 2.0 model
  inverts the ACES 2.0 SDR output exactly, so its master renders back to the
  SDR you delivered. Use it for SDR that was made through ACES 2.0 (set the
  Source curve to ACES). On a grade made another way, bright areas parked just
  under white, an open door, a window, a sky, come back far brighter and more
  saturated than they were, and the Learned ACES 2.0 trims do not reach them;
  the card and the Deliver page say so and point at the analytic route
  (Deliver > Source > Analytic). From 1.2.1 the route opens on the **HDR
  1000** monitor (the ACES 2.0 HDR output, a deliverable's picture) rather
  than *Scene* (the unbounded master through exposure and clip), and an AI
  fill preview's Fill and Master pictures go through the same monitor as the
  live frame.

- **Exposure.** The slider at the top of the Reconstruct card moves the whole
  master brighter or darker, -3 to +3 stops, live on the viewer. It is part of
  your grade: it survives the anchor (mid-tones keep the offset), the Region
  EV bands see the exposed picture, and masters, movie exports and projects
  carry it. Ctrl+Shift+Up / Down: a third of a stop; double-click: back to 0.

- **Clipped highlights.** Where the SDR clipped (a blown sky, a lamp, the
  sun), the inverse alone leaves a flat ceiling. **Reconstruct > Fill clipped
  highlights** (on by default) puts something sensible there with no model:
  a channel that clipped while the others did not is rebuilt from them, a
  blown sky gets a smooth fill from its edge, and a lamp or the sun a peak
  and a falloff from the glow around it. Nothing is made up as texture, and
  the *Invented* layer still shows every value it set. **Set the peak of a
  clipped region…** then a click on the region asks for its peak in nits
  (0 removes it); **Clear clipped peaks** removes them all. Strength scales
  the fill, *Off* removes it. With the model on, the model fills instead.
  Where a highlight was only just above the clip the fill can overshoot (by
  about a quarter of a stop), and small bright sparks such as fireworks look
  wrong: lower Strength, set the peak, or turn the fill off for those shots.
- **Highlight detail** (1.2.1). An SDR's shoulder parks a bright sky, a
  window or an open door just under white with its structure flattened to a
  few codes, and the inverse shows it as a flat wall. The slider amplifies
  the structure that survives there (1.00 leaves it as the source has it;
  1.5-2 is the range to judge), the same on every channel so the hue holds,
  and leaves one code of noise alone. It is part of the clipped-highlight
  fill: off with it, and only on the analytic route. Where the source is
  truly flat (every pixel at the last two or three codes) there is nothing
  to amplify, and it changes nothing; that is the AI fill's territory.
- **Mode** (1 2 3 4): what the model may change: *All*, *Highlights*,
  *Shadows*, or *Off* (the baseline alone).
- **Strength** ([ and ]): how much of the model's residual is added.
- **Limit to a luminance region** (1.1): confine the reconstruction to a
  range of the SDR's brightness. *Highlights + shadows* gives each its own
  threshold (Highlights from, Shadows below, as SDR luma 0 to 1), softness
  and strength; *Band* reconstructs only between Band low and Band high.
  Every pixel outside the region keeps the analytic baseline exactly, bit
  for bit, in the viewer, the master and movie exports; the master's sidecar
  and EXR record the region (`reconstruction_region`). The region only ever
  narrows what Mode allows. Not available with Keep super-whites. Under the
  sliders a **histogram** of the frame on screen shows its brightness with the
  region's weight drawn over it and how much of the frame the region reaches;
  **Show on the viewer** tints the region on the picture as you move the
  sliders (and on every frame you scrub to).
- **Preserve outside masks**: with painted masks, keep everything outside
  them at the baseline.
- Hold **B** to flip to the baseline; **W** wipes baseline (left) against
  RUDRA (right); drag the image to move the wipe.

### Play

- **Space** plays. With the model on, it runs ahead of the playhead on a
  smaller copy of each frame (**Clip > While playing**: 960 px, 640 px or full
  size) and the frame you stop on is reconstructed again at full size.
- **Keep time** (on by default) skips frames the model has not reached so the
  clip plays at its own rate; turn it off to see every frame. The status bar
  shows the rate reached, and the log says it when you stop.
- **Clip > Hold steady within a shot** (on by default) keeps the values RUDRA
  works out for a whole frame (the model's shadow weight, and the anchor's
  hold) steady across a shot, so the picture does not pump with grain or
  busy content; they start again at each cut. Movie exports do the same, so
  what plays is what exports. A stopped frame shows its own values, as Master
  EXR does.
- Movie exports also hold still areas steady: where the source pixel did not
  change, how much RUDRA brightened it is held, so grain lifted by the
  expansion stops shimmering (anything that moves is left to each frame).
  Playback does the same while Hold steady within a shot is on.

### Check

- **View peak**: how bright the viewer shows the HDR. It only changes the
  view, never the master. The Compare line under the viewer says what RUDRA
  changed and whether the peak hides it.
- **False colour** shows luminance zones in nits; **Difference** what the
  network changed.
- **Invented** marks in magenta the values RUDRA made up where the SDR
  clipped or crushed. Look at these before you deliver.
- The scopes (waveform, histogram, vectorscope) and the probe (hold Alt over
  the picture) read the HDR values.
- **Grade > Region EV** pushes a range of nits up or down; painted masks
  limit a band to part of the frame.

### Deliver

- **AI fill** (experimental, off by default) draws detail inside fully
  clipped areas. Optional **Highlight / Shadow prompts** steer what it draws
  in each region (only there). **Prompt strength** (1.1, 0 to 2) sets how
  strongly the prompts steer: 1 is how AI fill v3 was tested, 0 ignores them,
  above 1 is experimental. **Detail strength** (0 to 2) sets how much the
  drawn shape varies the brightness; 0 is a flat fill. **Suggest a prompt**
  (1.1) looks at the frame on screen: the size, place and shape of its fully
  clipped areas and the colour just around them (and, on a moving shot, how
  much a warm area changes) and offers a prompt with the reason, beside the
  presets (clear blue sky, overcast sky, sunset sky, sun, lamp, window
  daylight, specular glints, flame, shadow detail). Picking one fills the
  prompt box; you can still edit it. No model runs for the suggestion. A
  preset marked *ready* is already embedded, so the fill starts without
  loading the 11 GB text model; `scripts\GENFILL.ps1 -PrecachePrompts` embeds
  them all once. With **Limit to a
  luminance region** on (Reconstruct), the fill acts only inside that region
  and every pixel outside it is the master's, bit for bit. No 8-bit code of
  the SDR view ever changes, and every drawn pixel is marked in
  `rudra.generated`.
- **Master EXR** (M): ACES 2065-1 (or linear Rec.2020) EXR, a frame, all
  frames or a range, with a JSON sidecar describing exactly how it was made.
- **Containers** (1.1): the analytic master writes ACES 2065-1, ACEScg,
  linear Rec.2020 or linear Rec.709 (Deliver › Gamut).
- **AI fill on the analytic route** (1.1): with the analytic master in ACES
  2065-1, AI fill runs after the render as it does on the learned route, so
  the luminance region, its mattes and the prompts work on one render.
- **Write mattes (EXR)** (1.1): beside each analytic EXR master (for a
  movie: one per frame in `<name>_mattes`, beside its frames folder),
  `<name>.mattes.exr` with float channels for compositing:
  `rudra.highlight` and `rudra.shadow` (how much each reconstruction acted),
  `rudra.changed` (1 exactly where the reconstruction differs from the
  baseline), `rudra.region` (the luminance region, when on) and
  `rudra.paint.N` (each painted mask). They describe the reconstruction
  before the grade (Region EV and exposure). The AI fill's EXRs split
  `rudra.generated` into `rudra.generated.highlight` and
  `rudra.generated.shadow`, which add up to it exactly.
- **Write EV brackets** (1.1): beside each analytic EXR master,
  `<name>.ev-2.png`, `.ev+0.png` and `.ev+2.png`: the master as written, read
  back and shown on an SDR screen with diffuse white (203 nits) at 0 EV.
  −2 EV shows the highlights up to about 800 nits, +2 EV the shadows. The
  sidecar's `brackets.preview_vs_export` says how far the written master is
  from what the viewer showed, in 8-bit codes (0 for a float32 master, at
  most 1 for a half master).
- With **Write mattes**, also `<name>.regions.png`: every pixel's class over
  a grey picture: grey preserved (bit for bit the baseline, i.e. the source
  decoded) or within 0.1 stop of it; cyan reconstructed (the SDR has detail
  there); magenta estimated (the SDR is clipped or crushed, so the value is
  an extrapolation); amber generated by the AI fill; white lines the edge of
  the luminance region. The mattes EXR adds `rudra.class` and
  `rudra.confidence` (1 where the SDR pins the value, falling as the value
  moves away from it, at most 0.5 where the SDR only bounds it, 0 for AI
  fill: a constraint score, not a probability), and the sidecar the share of
  each class (`pixel_classes`). In the viewer, the **Invented** layer shows
  the same reconstructed / estimated split live.
- **More detail in the filled area** (AI fill, off by default): the fill model works at about
  832 × 480. On, it sees only a box around the shot's clipped areas (one box for the whole
  shot, so the fill still moves as one picture) instead of the whole frame, so a blown sky in a
  door a third of the frame wide is drawn at roughly twice the detail. Small specks far from the
  main area keep the master there; `genfill.json` gives the box and the share left out
  (`focus`). Off is AI fill v3 as tested.
- **Drop flickering fill frames** (AI fill, on by default): a frame whose
  fill jumps more than a quarter stop into it and out of it is written as
  the master's own frame; a fill that starts or ends is kept. A fill that is
  not a finite number always falls back. `genfill.json` lists every
  fallback (`fell_back`).
- **Technical details** (1.2.4): the range line under the viewer's tools, the
  pipe bar under the picture and the frame's timings show when **Help >
  Technical details** is ticked. RUDRA starts without them.
- The pipe bar under the viewer ends with the **display signal**: the
  transfer (sRGB, scRGB linear, PQ or EDR linear), primaries, the reference
  white (203 nits) and the display's peak.
  The EXR and the sidecar both record:
  - the app version and build commit (`rudra:appVersion`,
    `rudra:buildCommit`);
  - the source file's SHA-256 (`rudra:sourceSha256`);
  - with the model on, the checkpoint's SHA-256 (`rudra:checkpointSha256`);
  - whether the network ran in tiles (`rudra:tiled`).
- For a movie, the export sheet adds **HDR10**, **HLG**, **ProRes 422 HQ** and
  **ProRes 4444** (graded PQ, or scene-referred ACEScct / ARRI LogC4) with
  the audio. Exports run in a queue you can stop and resume (the export
  sheet's Queue button shows it).
- A colour too saturated for the movie's peak (a clipped blue sky can carry
  more than 1,000 nits of blue at a few hundred nits of brightness) keeps its
  brightness and loses a little saturation, so the movie is as bright as the
  master. `rudra-native deliver --peak-fit scale` scales such a pixel down
  whole instead (the older behaviour: hue and saturation kept, darker).
- **Anchor to source exposure** keeps mid-tones where the SDR had them, read
  through the Source you picked (BT.1886 reads the SDR as a BT.1886 display
  shows it) and your calibration or reference; the **Anchor knee** says where
  that lets go.
- HDR10 and ProRes (PQ) exports write their **Dolby Vision and HDR10+
  metadata** per shot beside the file: `<file>_hdr10plus.json`,
  `<file>_dovi_generate.json` (for `dovi_tool generate` or your finishing
  tool), `<file>_hdr_analysis.json` and `<file>_hdr10plus_scenes.json`. HDR10
  carries HDR10+ inside the file when the ffmpeg's x265 can write it; the
  report (`hdr_metadata`) says whether it did and, if not, why.
- A movie's report (`<file>.json`) measures flicker: `flicker_ev` for each
  frame and `temporal.flicker_ev_mean` / `flicker_ev_max` for the clip, the
  EV the HDR's average moved from one frame to the next beyond what the
  source did (not scored at a cut), and `local_flicker_ev`, the same measured
  area by area (a 36 × 64 grid) and averaged. A few thousandths are below what you can
  see; from about 0.02 EV (1.4 %) a steady shot can visibly pump.

## 3. Projects and autosave

- **File > Save project** (Ctrl+S / Cmd+S) writes a `.rudra` file: the shot,
  the frame, the model and every setting of the grade, the view peak and the
  Deliver tab. Painted masks go beside it as `<name>.rudra.masks.png`.
- **File > Open project…** (Ctrl+O), a drop on the window, or on Windows a
  double-click on a `.rudra` file opens one. A project moved together with its footage
  still opens: paths under the project's folder are stored relative to it.
  Missing footage or a missing model is named in the log; the grade still
  opens.
- The session is **autosaved** a few seconds after every change. If RUDRA
  closed unexpectedly, **File > Reopen last session** brings it back. With
  two RUDRA windows open, the first one keeps the autosave.
- Opening another project, or closing RUDRA, with unsaved changes to a
  project asks whether to save them first.

## 4. Updates

RUDRA asks GitHub once a day whether a newer release exists (a beta looks
for betas too) and says so in the status bar and the log. Nothing is
downloaded or installed for you. **Help > Check for updates…** asks now.
To turn the daily check off, set `updates/auto=false` in RUDRA's settings or
start it with the environment variable `RUDRA_NO_UPDATE_CHECK=1`.

## 5. Command line

`rudra-native` (beside `RUDRA.exe`, or `RUDRA.app/Contents/MacOS/`) runs the
same pipeline without the window: `video` (a movie in, HDR10/HLG/ProRes
out), `deliver`, `batch` (a queue file), `diff`, `info`, `bench` and
`ffmpeg-check` (is this ffmpeg complete?), and `bench-clip-fill` (the
clipped-highlight fill as a bench tree). Run `rudra-native` alone for the
commands and their options. In a `--params` or `--grade` settings file,
`"clip_fill": false` turns the fill off and `"clip_peaks": [{"x": 0.5,
"y": 0.3, "nits": 2500}]` sets peaks (x and y across the frame, 0 to 1).

The packaged ffmpeg is used first. To use your own instead, set
`RUDRA_FFMPEG_DIR` to its folder, or `RUDRA_FFMPEG_DIR=path` for the one on
the PATH.

## 6. When something goes wrong

- **Help > Open log folder** opens the log (`rudra.log`, kept to 5 MB, three
  old copies). Attach it to a report.
- A failed write says why: the disk is full (with the space free and
  needed), access is denied (Windows: Security > Controlled folder access),
  or the folder is missing.
- "no Qt platform plugin could be initialized" should no longer happen;
  if it does, the log names the setting that caused it.
- Report issues at https://github.com/FXTD-Studios/RUDRA/issues with the
  version (Help > About) and the log.

## Keyboard

| Key | Action |
| --- | --- |
| O | Open frames |
| Ctrl+O / Ctrl+S / Ctrl+Shift+S | Open / save / save project as |
| M | Master EXR |
| , / . | Previous / next frame |
| Home / End | First / last frame |
| Space | Play / pause |
| [ / ] | Weaker / stronger residual |
| 1 2 3 4 | Recovery: all, highlights, shadows, off |
| P | Preserve outside masks |
| B (hold) | Flip to the baseline |
| W | Wipe |
| F | Fit image to window (while not typing in a text field) |
| Z / Y | Undo / redo |
| G / Shift+G | Action / title safe guides |
| F1 | This guide |
| ? | The shortcut sheet |

On macOS, Ctrl is Cmd.
