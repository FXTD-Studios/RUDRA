cmake_minimum_required(VERSION 3.24)

# RUDRA native: the layered C++ app described in docs/NATIVE_ARCHITECTURE.md.
# The dependency rule (a layer links only to layers below it) is enforced by
# PRIVATE linkage here and by tools/check_layers.py in CI.
project(RudraNative VERSION 1.2.4 LANGUAGES CXX)   # 1.2.0: the ACES 2 lock (package contract major 3); 1.2.1-1.2.3: first-run feedback; 1.2.4: security review
# The release label after the version: "beta.5" for the fifth public beta,
# empty for a final release. RUDRA_VERSION_LABEL is what the app shows.
set(RUDRA_RELEASE "" CACHE STRING "Pre-release tag appended to the version (empty for a release)")
if(RUDRA_RELEASE)
  set(RUDRA_VERSION_LABEL "${PROJECT_VERSION}-${RUDRA_RELEASE}")
else()
  set(RUDRA_VERSION_LABEL "${PROJECT_VERSION}")
endif()

# The commit the build was configured from, for master provenance (deliver/).
# Configure-time: rebuild after re-configuring to refresh it; "unknown" outside git.
set(RUDRA_BUILD_COMMIT "unknown")
find_package(Git QUIET)
if(GIT_FOUND)
  execute_process(COMMAND "${GIT_EXECUTABLE}" --no-optional-locks rev-parse --short=12 HEAD
                  WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}" OUTPUT_VARIABLE _rudra_commit
                  OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_QUIET RESULT_VARIABLE _rudra_git_rc)
  if(_rudra_git_rc EQUAL 0 AND _rudra_commit)
    set(RUDRA_BUILD_COMMIT "${_rudra_commit}")
  endif()
endif()

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

option(RUDRA_BUILD_TESTS       "Build the GoogleTest suite"                        ON)
option(RUDRA_BUILD_CLI         "Build the headless rudra-native CLI"              ON)
option(RUDRA_BUILD_APP         "Build the Qt application (needs Qt 6)"            OFF)
option(RUDRA_BUILD_HDR_PROBE   "Build rudra-hdr-probe and rudra-gpu-parity (Qt 6.6+)" OFF)
option(RUDRA_BUILD_RENDER      "Build the QRhi render library (Qt 6.6+)"          OFF)
if(RUDRA_BUILD_HDR_PROBE)
  set(RUDRA_BUILD_RENDER ON CACHE BOOL "" FORCE)
endif()
option(RUDRA_WITH_LIBTORCH     "Build the LibTorch inference backend"             OFF)
option(RUDRA_WITH_ONNXRUNTIME  "Build the ONNX Runtime inference backend"         OFF)
option(RUDRA_WITH_OCIO         "ACES v2 view through OpenColorIO 2.5.2 (infer/)"   OFF)
option(RUDRA_WITH_OPENCV       "Still decode in media/ (OpenCV core + imgcodecs)"  OFF)
option(RUDRA_BUILD_OFX         "Build the OFX plug-in (needs the OpenFX SDK)"       OFF)
set(ONNXRUNTIME_ROOT "" CACHE PATH "ONNX Runtime package root (include/, lib/)")

list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/cmake")
include(RudraDeps)
include(RudraWarnings)
include(RudraTheme)

if(RUDRA_BUILD_TESTS)
  enable_testing()   # before app/, which adds its own Qt tests
endif()

add_subdirectory(platform)
add_subdirectory(core)
add_subdirectory(infer)
add_subdirectory(media)
add_subdirectory(render)
add_subdirectory(deliver)
add_subdirectory(video)
add_subdirectory(engine)
add_subdirectory(ofx)   # roadmap 5.1: the picture always, the plug-in with RUDRA_BUILD_OFX

if(RUDRA_BUILD_CLI)
  add_subdirectory(cli)
endif()
if(RUDRA_BUILD_APP)
  add_subdirectory(app)
endif()
if(RUDRA_BUILD_TESTS)
  add_subdirectory(tests)
  # Shot keyframes, conform, correction logging, Dolby Vision RPU (20 Oct 2026):
  # their own test executable, rudra_conform_tests.
  add_subdirectory(tests/conform)
endif()

message(STATUS "RUDRA native: tests=${RUDRA_BUILD_TESTS} cli=${RUDRA_BUILD_CLI} app=${RUDRA_BUILD_APP} hdr_probe=${RUDRA_BUILD_HDR_PROBE} render=${RUDRA_BUILD_RENDER} "
               "libtorch=${RUDRA_WITH_LIBTORCH} onnxruntime=${RUDRA_WITH_ONNXRUNTIME} opencv=${RUDRA_WITH_OPENCV} ocio=${RUDRA_WITH_OCIO} ofx=${RUDRA_BUILD_OFX}")
