#include "rudra/deliver/exr.hpp"

#include "rudra/core/timecode.hpp"

#include <algorithm>
#include <bit>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <limits>

#include "rudra/core/gamut.hpp"
#include "rudra/platform/io_error.hpp"
#include "rudra/platform/pyjson.hpp"

namespace rudra {

const Chromaticities kAp0Chromaticities{0.7347, 0.2653, 0.0, 1.0, 0.0001, -0.077, 0.32168, 0.33767};
const Chromaticities kAp1Chromaticities{0.713, 0.293, 0.165, 0.830, 0.128, 0.044, 0.32168, 0.33767};
const Chromaticities kRec2020Chromaticities{0.708, 0.292, 0.170, 0.797, 0.131, 0.046, 0.3127, 0.3290};
const Chromaticities kRec709Chromaticities{0.640, 0.330, 0.300, 0.600, 0.150, 0.060, 0.3127, 0.3290};

namespace {

constexpr std::int32_t kMagic = 20000630;

void put_i32(std::vector<std::uint8_t>& o, std::int32_t v) {
    const auto u = static_cast<std::uint32_t>(v);
    for (int k = 0; k < 4; ++k) o.push_back(std::uint8_t(u >> (8 * k)));
}
void put_u64(std::vector<std::uint8_t>& o, std::uint64_t v) {
    for (int k = 0; k < 8; ++k) o.push_back(std::uint8_t(v >> (8 * k)));
}
void put_f32(std::vector<std::uint8_t>& o, float f) { put_i32(o, std::bit_cast<std::int32_t>(f)); }
void put_str(std::vector<std::uint8_t>& o, const std::string& s) {
    o.insert(o.end(), s.begin(), s.end());
    o.push_back(0);
}
void attr(std::vector<std::uint8_t>& o, const std::string& name, const std::string& type,
          const std::vector<std::uint8_t>& payload) {
    put_str(o, name);
    put_str(o, type);
    put_i32(o, static_cast<std::int32_t>(payload.size()));
    o.insert(o.end(), payload.begin(), payload.end());
}

}  // namespace

std::uint16_t float_to_half(float f) noexcept {
    const std::uint32_t x = std::bit_cast<std::uint32_t>(f);
    const std::uint32_t sign = (x >> 16) & 0x8000u;
    const std::uint32_t abs = x & 0x7fffffffu;
    if (abs >= 0x7f800000u) {   // inf or nan
        return std::uint16_t(sign | (abs > 0x7f800000u ? 0x7e00u : 0x7c00u));
    }
    if (abs >= 0x477ff000u) return std::uint16_t(sign | 0x7c00u);   // rounds to inf
    if (abs < 0x38800000u) {   // half subnormal or zero
        if (abs < 0x33000000u) return std::uint16_t(sign);   // below half the smallest subnormal
        const int e = int(abs >> 23);
        const std::uint32_t mant = (abs & 0x7fffffu) | 0x800000u;
        const int shift = 126 - e;   // the value in units of 2^-24 is mant >> shift
        const std::uint32_t q = mant >> shift;
        const std::uint32_t rem = mant & ((1u << (shift)) - 1u);
        const std::uint32_t half = 1u << (shift - 1);
        std::uint32_t r = q;
        if (rem > half || (rem == half && (q & 1u))) ++r;
        return std::uint16_t(sign | r);
    }
    // Normal: rebias exponent, round the 13 dropped mantissa bits to nearest even.
    std::uint32_t h = ((abs - 0x38000000u) >> 13);
    const std::uint32_t rem = abs & 0x1fffu;
    if (rem > 0x1000u || (rem == 0x1000u && (h & 1u))) ++h;
    return std::uint16_t(sign | h);
}

namespace {
// The bytes of an uncompressed scanline EXR whose channel i is `names[i]`, read from `planes[i]`
// (w x h floats each), written in name order as the format asks.
std::vector<std::uint8_t> planes_bytes(const std::vector<std::string>& names, const std::vector<const float*>& planes,
                                       int w, int h, bool half, const std::optional<Chromaticities>& chroma,
                                       const ExrAttributes& attributes, const ExrTypedAttributes& typed);
}  // namespace

Result<std::vector<std::uint8_t>> exr_bytes(const PlanarBuffer& rgb, bool half,
                                            const std::optional<Chromaticities>& chroma, const ExrAttributes& attributes,
                                            const PlanarBuffer* reconstruction_mask, const ExrTypedAttributes& typed) {
    const int n_ch = rgb.channels();
    if (n_ch != 3 && n_ch != 4) return make_error(ErrorCode::InvalidArgument, "expected a 3 or 4 channel image");
    const int w = rgb.width(), h = rgb.height();
    if (reconstruction_mask && (reconstruction_mask->channels() != 1 ||
        reconstruction_mask->width() != w || reconstruction_mask->height() != h ||
        !std::all_of(reconstruction_mask->span().begin(), reconstruction_mask->span().end(),
            [](float v) { return std::isfinite(v) && v >= 0 && v <= 1; })))
        return make_error(ErrorCode::InvalidArgument, "reconstruction mask must be finite HxW values in [0, 1]");
    std::vector<std::string> names = {"R", "G", "B"};
    if (n_ch == 4) names.push_back("A");
    if (reconstruction_mask) names.push_back("rudra.reconstructed");
    std::vector<const float*> planes;
    for (int c = 0; c < n_ch; ++c) planes.push_back(rgb.plane(c));
    if (reconstruction_mask) planes.push_back(reconstruction_mask->plane(0));
    return planes_bytes(names, planes, w, h, half, chroma, attributes, typed);
}

Result<void> write_mattes_exr(const std::filesystem::path& path, const NamedPlanes& planes,
                              const ExrAttributes& attributes) {
    if (planes.empty()) return make_error(ErrorCode::InvalidArgument, "a mattes EXR needs at least one matte");
    const int w = planes.front().second.width(), h = planes.front().second.height();
    std::vector<std::string> names;
    std::vector<const float*> data;
    for (const auto& [name, p] : planes) {
        if (name.empty() || name == "R" || name == "G" || name == "B" || name == "A" ||
            std::find(names.begin(), names.end(), name) != names.end())
            return make_error(ErrorCode::InvalidArgument, "matte names must be unique and not R, G, B or A", name);
        if (p.channels() != 1 || p.width() != w || p.height() != h ||
            !std::all_of(p.span().begin(), p.span().end(), [](float v) { return std::isfinite(v) && v >= 0 && v <= 1; }))
            return make_error(ErrorCode::InvalidArgument, "a matte must be finite HxW values in [0, 1], all one size", name);
        names.push_back(name);
        data.push_back(p.plane(0));
    }
    const auto bytes = planes_bytes(names, data, w, h, false, std::nullopt, attributes, {});
    std::error_code ec;
    if (path.has_parent_path()) std::filesystem::create_directories(path.parent_path(), ec);
    std::ofstream out(path, std::ios::binary);
    if (!out) return make_error(ErrorCode::IoError, "Cannot write the mattes EXR.", path.string());
    out.write(reinterpret_cast<const char*>(bytes.data()), std::streamsize(bytes.size()));
    out.close();
    if (!out) return make_error(ErrorCode::IoError, "Cannot write the mattes EXR.", path.string());
    return {};
}

namespace {
std::vector<std::uint8_t> planes_bytes(const std::vector<std::string>& names, const std::vector<const float*>& planes,
                                       int w, int h, bool half, const std::optional<Chromaticities>& chroma,
                                       const ExrAttributes& attributes, const ExrTypedAttributes& typed) {
    std::vector<int> order(names.size());
    for (std::size_t i = 0; i < names.size(); ++i) order[i] = static_cast<int>(i);
    std::sort(order.begin(), order.end(), [&](int a, int b) { return names[a] < names[b]; });

    std::vector<std::uint8_t> head;
    {
        std::vector<std::uint8_t> ch;
        for (int i : order) {
            put_str(ch, names[i].c_str());
            put_i32(ch, half ? 1 : 2);
            ch.insert(ch.end(), {0, 0, 0, 0});
            put_i32(ch, 1);
            put_i32(ch, 1);
        }
        ch.push_back(0);
        attr(head, "channels", "chlist", ch);
    }
    attr(head, "compression", "compression", {0});
    std::vector<std::uint8_t> box;
    for (int v : {0, 0, w - 1, h - 1}) put_i32(box, v);
    attr(head, "dataWindow", "box2i", box);
    attr(head, "displayWindow", "box2i", box);
    attr(head, "lineOrder", "lineOrder", {0});
    std::vector<std::uint8_t> f1, v2;
    put_f32(f1, 1.0f);
    put_f32(v2, 0.0f);
    put_f32(v2, 0.0f);
    attr(head, "pixelAspectRatio", "float", f1);
    attr(head, "screenWindowCenter", "v2f", v2);
    attr(head, "screenWindowWidth", "float", f1);
    if (chroma) {
        std::vector<std::uint8_t> c;
        for (double v : *chroma) put_f32(c, static_cast<float>(v));
        attr(head, "chromaticities", "chromaticities", c);
    }
    for (const auto& [k, v] : attributes) attr(head, k, "string", std::vector<std::uint8_t>(v.begin(), v.end()));
    for (const auto& t : typed) attr(head, t.name, t.type, t.payload);
    head.push_back(0);

    const int bpp = half ? 2 : 4;
    const std::int64_t row_size = std::int64_t(w) * bpp * static_cast<std::int64_t>(names.size());
    const std::int64_t chunk = 8 + row_size;
    const std::int64_t data_start = 8 + std::int64_t(head.size()) + 8 * std::int64_t(h);

    std::vector<std::uint8_t> out;
    out.reserve(std::size_t(data_start + chunk * h));
    put_i32(out, kMagic);
    put_i32(out, 2);
    out.insert(out.end(), head.begin(), head.end());
    for (int y = 0; y < h; ++y) put_u64(out, std::uint64_t(data_start + std::int64_t(y) * chunk));

    auto clean = [half](float v) {
        if (std::isnan(v)) v = 0.0f;
        else if (v == std::numeric_limits<float>::infinity()) v = 3.4e38f;
        else if (v == -std::numeric_limits<float>::infinity()) v = 0.0f;
        if (half) v = std::clamp(v, -65504.0f, 65504.0f);
        return v;
    };
    for (int y = 0; y < h; ++y) {
        put_i32(out, y);
        put_i32(out, static_cast<std::int32_t>(row_size));
        for (int c : order) {
            const float* row = planes[std::size_t(c)] + std::size_t(y) * std::size_t(w);
            for (int x = 0; x < w; ++x) {
                const float v = clean(row[x]);
                if (half) {
                    const std::uint16_t hv = float_to_half(v);
                    out.push_back(std::uint8_t(hv));
                    out.push_back(std::uint8_t(hv >> 8));
                } else {
                    put_f32(out, v);
                }
            }
        }
    }
    return out;
}
}  // namespace

Result<void> write_exr(const std::filesystem::path& path, const PlanarBuffer& rgb, bool half,
                       const std::optional<Chromaticities>& chroma, const ExrAttributes& attributes,
                       const PlanarBuffer* reconstruction_mask, const ExrTypedAttributes& typed) {
    auto bytes = exr_bytes(rgb, half, chroma, attributes, reconstruction_mask, typed);
    if (!bytes) return bytes.error();
    std::error_code ec;
    if (path.has_parent_path()) std::filesystem::create_directories(path.parent_path(), ec);
    // errno is cleared first so a reason left over from earlier is never
    // reported as this one's, and the file is closed here, not by the
    // destructor: the last buffered bytes reach the disk on close, and a full
    // disk there used to pass as a written master.
    errno = 0;
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) {
        const int err = errno;
        return make_error(ErrorCode::IoError,
                          "The EXR file could not be created (" + io_failure_reason(path, err, bytes->size()) + ").",
                          path.string());
    }
    f.write(reinterpret_cast<const char*>(bytes->data()), static_cast<std::streamsize>(bytes->size()));
    f.close();
    if (!f) {
        const int err = errno;
        std::string reason = io_failure_reason(path, err, bytes->size());
        std::filesystem::remove(path, ec);   // never leave a truncated master behind
        return make_error(ErrorCode::IoError, "The EXR file could not be written (" + reason + ").", path.string());
    }
    return {};
}

const char* primaries_name(Primaries p) noexcept {
    switch (p) {
        case Primaries::Rec709: return "rec709";
        case Primaries::Rec2020: return "rec2020";
        case Primaries::P3D65: return "p3d65";
        case Primaries::Ap0: return "ap0";
        case Primaries::Ap1: return "ap1";
        case Primaries::Awg4: return "awg4";
        case Primaries::AdobeRgb: return "adobe_rgb";
    }
    return "?";
}

namespace {

Result<void> write_aces_like(const std::filesystem::path& path, const PlanarBuffer& rgb, Primaries source,
                             Primaries dst, double exposure, const ExrAttributes& provenance, bool ap0, bool half,
                             const PlanarBuffer* reconstruction_mask, const ExrTypedAttributes& typed,
                             const PlanarBuffer* alpha) {
    if (alpha && (alpha->channels() != 1 || alpha->height() != rgb.height() || alpha->width() != rgb.width()))
        return make_error(ErrorCode::InvalidArgument, "The alpha must be one plane the size of the picture.");
    PlanarBuffer scaled = rgb;
    const float k = static_cast<float>(exposure);
    for (float& v : scaled.span()) v = v * k;
    PlanarBuffer out = convert_primaries(scaled, source, dst);
    if (alpha) {   // RGB premultiplied by A, then A: OpenEXR's associated alpha
        PlanarBuffer rgba(4, rgb.height(), rgb.width());
        for (std::size_t i = 0; i < out.plane_size(); ++i) {
            const float a = std::clamp(alpha->plane(0)[i], 0.0f, 1.0f);
            for (int c = 0; c < 3; ++c) rgba.plane(c)[i] = out.plane(c)[i] * a;
            rgba.plane(3)[i] = a;
        }
        out = std::move(rgba);
    }
    ExrAttributes attrs;
    ExrTypedAttributes all_typed = typed;
    // SMPTE ST 2065-4 says acesImageContainerFlag is an int (= 1), only on a file
    // that is the container: AP0, RGB(A), uncompressed scanlines (28 Oct 2026 review).
    if (ap0 && !reconstruction_mask) all_typed.push_back({"acesImageContainerFlag", "int", {1, 0, 0, 0}});
    else attrs.emplace_back("rudra:container", ap0 ? "AP0 linear with reconstruction mask" : "ACEScg (AP1)");
    attrs.emplace_back("rudra:sourceSpace", primaries_name(source));
    attrs.emplace_back("rudra:exposureConvention", "0.18 = 18% grey (scene), diffuse white = 1.0");
    attrs.emplace_back("rudra:exposureScale", pyjson::repr(exposure));
    if (alpha) attrs.emplace_back("rudra:alpha", "the source's straight alpha as A; RGB premultiplied by it (OpenEXR associated alpha)");
    if (!provenance.empty()) {
        pyjson::Dict d;
        for (const auto& [kk, v] : provenance) d.emplace_back(kk, v);
        attrs.emplace_back("rudra:provenance", pyjson::dumps(d, -1, true));
    }
    return write_exr(path, out, half, ap0 ? kAp0Chromaticities : kAp1Chromaticities, attrs, reconstruction_mask, all_typed);
}

}  // namespace

Result<void> write_aces_exr(const std::filesystem::path& path, const PlanarBuffer& rgb, Primaries source,
                            double exposure, const ExrAttributes& provenance, bool half, const PlanarBuffer* reconstruction_mask,
                            const ExrTypedAttributes& typed, const PlanarBuffer* alpha) {
    return write_aces_like(path, rgb, source, Primaries::Ap0, exposure, provenance, true, half, reconstruction_mask, typed, alpha);
}

Result<void> write_acescg_exr(const std::filesystem::path& path, const PlanarBuffer& rgb, Primaries source,
                              double exposure, const ExrAttributes& provenance, bool half, const PlanarBuffer* reconstruction_mask,
                              const ExrTypedAttributes& typed, const PlanarBuffer* alpha) {
    return write_aces_like(path, rgb, source, Primaries::Ap1, exposure, provenance, false, half, reconstruction_mask, typed, alpha);
}

ExrTypedAttributes exr_timecode_attributes(const std::string& timecode, double fps, const std::string& reel) {
    ExrTypedAttributes out;
    auto u32 = [](std::vector<std::uint8_t>& b, std::uint32_t v) {
        for (int i = 0; i < 4; ++i) b.push_back(std::uint8_t(v >> (8 * i)));
    };
    if (fps > 0) {
        // framesPerSecond as the exact rational for the NTSC rates (24000/1001 ...).
        std::int32_t num = std::int32_t(std::lround(fps * 1000.0)), den = 1000;
        if (std::abs(fps - std::round(fps)) < 1e-6) num = std::int32_t(std::lround(fps)), den = 1;
        else if (std::abs(fps * 1.001 - std::round(fps * 1.001)) < 1e-3)
            num = std::int32_t(std::lround(fps * 1.001)) * 1000, den = 1001;
        std::vector<std::uint8_t> r;
        u32(r, std::uint32_t(num));
        u32(r, std::uint32_t(den));
        out.push_back({"framesPerSecond", "rational", std::move(r)});
    }
    if (auto tc = parse_timecode(timecode)) {
        const auto packed = exr_timecode(*tc);
        std::vector<std::uint8_t> b;
        u32(b, packed[0]);
        u32(b, packed[1]);
        out.push_back({"timeCode", "timecode", std::move(b)});
    }
    if (!reel.empty()) out.push_back({"reelName", "string", std::vector<std::uint8_t>(reel.begin(), reel.end())});
    return out;
}

namespace {
float half_to_float(std::uint16_t h) noexcept {
    const std::uint32_t sign = std::uint32_t(h & 0x8000u) << 16;
    std::uint32_t exp = (h >> 10) & 0x1fu, mant = h & 0x3ffu;
    std::uint32_t bits;
    if (exp == 0) {
        if (mant == 0) bits = sign;
        else {
            int e = -1;
            do { ++e; mant <<= 1; } while (!(mant & 0x400u));
            bits = sign | std::uint32_t(127 - 15 - e) << 23 | (mant & 0x3ffu) << 13;
        }
    } else if (exp == 31) {
        bits = sign | 0x7f800000u | mant << 13;
    } else {
        bits = sign | (exp + 112) << 23 | mant << 13;
    }
    return std::bit_cast<float>(bits);
}
}  // namespace

Result<ExrImage> read_exr(const std::filesystem::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return make_error(ErrorCode::NotFound, "The EXR file could not be opened.", path.string());
    const std::vector<std::uint8_t> raw((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    auto bad = [&](const char* why) { return make_error(ErrorCode::ParseError, "The EXR file is not readable.", path.string() + ": " + why); };
    // The file is not trusted (security review, 11 Nov 2026): a reference image or a master can come
    // from anywhere. Every read is checked against the file's size first, a scanline must name a row
    // inside the data window, and nothing is allocated until the file is seen to hold the pixels its
    // header promises. Before this a crafted scanline row wrote outside the pixel buffer.
    const std::size_t n = raw.size();
    auto has = [&](std::size_t at, std::size_t len) { return at <= n && len <= n - at; };
    std::size_t pos = 0;
    auto i32 = [&](std::size_t at) {   // the caller has checked has(at, 4)
        std::int32_t v;
        std::memcpy(&v, raw.data() + at, 4);
        return v;
    };
    if (n < 8 || i32(0) != kMagic) return bad("not an EXR file");
    if (i32(4) & 0x1a00) return bad("tiled, deep or multi-part");
    pos = 8;
    auto cstr = [&](std::size_t& at, std::string& s) {   // false: no terminator before the end of the file
        const std::size_t start = at;
        while (at < n && raw[at] != 0) ++at;
        if (at >= n) return false;
        s.assign(raw.begin() + std::ptrdiff_t(start), raw.begin() + std::ptrdiff_t(at));
        ++at;
        return true;
    };
    ExrImage img;
    std::vector<std::string> channels;
    int x0 = 0, y0 = 0, x1 = -1, y1 = -1, compression = 0;
    for (;;) {
        if (pos >= n) return bad("truncated header");
        if (raw[pos] == 0) break;
        std::string name, type;
        if (!cstr(pos, name) || !cstr(pos, type) || !has(pos, 4)) return bad("truncated header");
        const std::int32_t declared = i32(pos);
        pos += 4;
        if (declared < 0 || !has(pos, static_cast<std::size_t>(declared))) return bad("truncated header");
        const auto size = static_cast<std::size_t>(declared);
        std::vector<std::uint8_t> payload(raw.begin() + std::ptrdiff_t(pos), raw.begin() + std::ptrdiff_t(pos + size));
        if (type == "chlist") {
            const std::size_t end = pos + size;
            std::size_t c = pos;
            for (;;) {
                if (c >= end) return bad("bad channel list");
                if (raw[c] == 0) break;
                std::string channel;
                if (!cstr(c, channel) || c > end || end - c < 16) return bad("bad channel list");
                const std::int32_t pixel_type = i32(c);
                if (pixel_type < 0 || pixel_type > 2) return bad("bad channel list");
                channels.push_back(std::move(channel));
                img.pixel_types.push_back(pixel_type);
                c += 16;
            }
        } else if (type == "compression") {
            if (size < 1) return bad("bad compression attribute");
            compression = payload[0];
        } else if (name == "dataWindow") {
            if (size < 16) return bad("bad data window");
            x0 = i32(pos); y0 = i32(pos + 4); x1 = i32(pos + 8); y1 = i32(pos + 12);
        }
        img.attribute_types.emplace_back(name, type);
        img.attributes.emplace_back(name, std::move(payload));
        pos += size;
    }
    ++pos;
    if (compression != 0) return bad("compressed");
    // In 64 bits: x1 - x0 + 1 overflows an int for a hostile window.
    const std::int64_t w64 = std::int64_t(x1) - std::int64_t(x0) + 1, h64 = std::int64_t(y1) - std::int64_t(y0) + 1;
    if (w64 <= 0 || h64 <= 0 || channels.empty()) return bad("empty data window");
    constexpr std::int64_t kMaxSide = 1 << 20;   // far past any frame; keeps the products below in range
    if (w64 > kMaxSide || h64 > kMaxSide) return bad("data window too large");
    const int w = static_cast<int>(w64), h = static_cast<int>(h64);
    // The file must hold the offset table and h scanlines of every channel before anything is allocated.
    std::size_t line_bytes = 8;   // each scanline: its row, its size, then the channels
    for (int t : img.pixel_types) {
        line_bytes += std::size_t(w) * (t == 1 ? 2 : 4);
        if (line_bytes > n) return bad("truncated data");
    }
    if (!has(pos, 8 * std::size_t(h))) return bad("truncated data");
    pos += 8 * std::size_t(h);
    if ((n - pos) / line_bytes < std::size_t(h)) return bad("truncated data");
    static const char* order[] = {"R", "G", "B", "A"};
    const int nout = int(std::count(channels.begin(), channels.end(), std::string("A"))) ? 4 : 3;
    img.pixels = PlanarBuffer(nout, h, w);
    if (std::find(channels.begin(), channels.end(), "rudra.reconstructed") != channels.end())
        img.reconstruction_mask.emplace(1, h, w);
    const bool all_half = std::all_of(img.pixel_types.begin(), img.pixel_types.end(), [](int t) { return t == 1; });
    if (all_half) img.half_bits.assign(std::size_t(nout) * std::size_t(w) * std::size_t(h), 0);
    for (int r = 0; r < h; ++r) {
        if (!has(pos, 8)) return bad("truncated data");
        const std::int64_t row = std::int64_t(i32(pos)) - std::int64_t(y0);
        if (row < 0 || row >= h64) return bad("scanline outside the data window");
        const int y = static_cast<int>(row);
        pos += 8;
        for (std::size_t c = 0; c < channels.size(); ++c) {
            int plane = -1;
            for (int k = 0; k < nout; ++k)
                if (channels[c] == order[k]) plane = k;
            const bool half = img.pixel_types[c] == 1;
            const std::size_t bytes = std::size_t(w) * (half ? 2 : 4);
            if (!has(pos, bytes)) return bad("truncated data");
            const bool is_mask = channels[c] == "rudra.reconstructed";
            PlanarBuffer* other = nullptr;
            if (plane < 0 && !is_mask) {   // any other channel, kept by name (5 Nov 2026)
                auto it = std::find_if(img.other.begin(), img.other.end(), [&](const auto& p) { return p.first == channels[c]; });
                if (it == img.other.end()) {
                    img.other.emplace_back(channels[c], PlanarBuffer(1, h, w));
                    it = img.other.end() - 1;
                }
                other = &it->second;
            }
            {
                for (int x = 0; x < w; ++x) {
                    float v;
                    if (half) {
                        std::uint16_t hv;
                        std::memcpy(&hv, raw.data() + pos + std::size_t(x) * 2, 2);
                        v = half_to_float(hv);
                        if (all_half && plane >= 0) img.half_bits[(std::size_t(plane) * std::size_t(h) + std::size_t(y)) * std::size_t(w) + std::size_t(x)] = hv;
                    } else {
                        std::memcpy(&v, raw.data() + pos + std::size_t(x) * 4, 4);
                    }
                    if (is_mask) img.reconstruction_mask->at(0, y, x) = v;
                    else if (other) other->at(0, y, x) = v;
                    else img.pixels.at(plane, y, x) = v;
                }
            }
            pos += bytes;
        }
    }
    return img;
}

std::string ocio_config_text() {
    auto matrix_yaml = [](const Mat3& m) {
        std::string s = std::string(8, ' ') + "- !<MatrixTransform> {matrix: [";
        const double m4[16] = {m[0][0], m[0][1], m[0][2], 0, m[1][0], m[1][1], m[1][2], 0,
                               m[2][0], m[2][1], m[2][2], 0, 0, 0, 0, 1};
        for (int i = 0; i < 16; ++i) {
            char b[64];
            std::snprintf(b, sizeof b, "%.10f", m4[i]);
            s += b;
            if (i < 15) s += ", ";
        }
        return s + "]}";
    };
    struct Space { const char* name; Primaries src; const char* label; };
    const Space spaces[] = {{"RUDRA Scene Linear (Rec.2020)", Primaries::Rec2020, "Rec.2020"},
                            {"Linear Rec.709", Primaries::Rec709, "Linear Rec.709"},
                            {"ACEScg", Primaries::Ap1, "ACEScg"}};
    std::string blocks;
    for (const auto& sp : spaces) {
        blocks += "  - !<ColorSpace>\n    name: " + std::string(sp.name) +
                  "\n    family: Scene\n    encoding: scene-linear\n    bitdepth: 32f\n    description: |\n      Linear " +
                  sp.label +
                  " to ACES2065-1 via Bradford CAT.\n      Generated by rudra.delivery.aces; matrices derived from "
                  "primaries, not copied.\n    to_scene_reference: !<GroupTransform>\n      children:\n" +
                  matrix_yaml(rgb_to_rgb_matrix(sp.src, Primaries::Ap0)) + "\n";
    }
    return std::string(
           "ocio_profile_version: 2\n"
           "\n"
           "description: RUDRA delivery working spaces (pair with the official ACES OCIO config for display transforms)\n"
           "name: rudra-delivery\n"
           "\n"
           "roles:\n"
           "  scene_linear: RUDRA Scene Linear (Rec.2020)\n"
           "  aces_interchange: ACES2065-1\n"
           "  default: RUDRA Scene Linear (Rec.2020)\n"
           "  data: Raw\n"
           "\n"
           "file_rules:\n"
           "  - !<Rule> {name: Default, colorspace: default}\n"
           "\n"
           "colorspaces:\n"
           "  - !<ColorSpace>\n"
           "    name: ACES2065-1\n"
           "    family: Scene\n"
           "    encoding: scene-linear\n"
           "    bitdepth: 32f\n"
           "    description: SMPTE ST 2065-1 AP0 primaries, ACES white. Reference space.\n"
           "\n"
           "  - !<ColorSpace>\n"
           "    name: Raw\n"
           "    family: Utility\n"
           "    encoding: data\n"
           "    isdata: true\n"
           "\n") +
           blocks;
}

}  // namespace rudra
