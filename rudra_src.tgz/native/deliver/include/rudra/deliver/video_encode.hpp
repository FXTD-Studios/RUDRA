#pragma once
// The encoder's command and publishing (Phase 4, step 5): rudra/video.py
// encode_command, argument for argument, for the five delivery profiles, and
// convert_video's publish: the master and its sidecar staged beside the
// output and renamed into place, never replacing anything.

#include <filesystem>
#include <optional>
#include <string>
#include <vector>

#include "rudra/core/video_clock.hpp"
#include "rudra/platform/result.hpp"

namespace rudra {

// The video.py arguments the encoder reads (argparse defaults).
struct VideoEncodeRequest {
    std::string format = "hdr10";   // hdr10, hlg, prores422, prores422hq, prores4444
    std::string preset = "medium";  // x265 preset
    int crf = 12;
    std::string audio = "copy";     // copy, aac, none
    double peak_nits = 1000.0;
    double min_nits = 0.005;
    bool alpha = false;             // args.preserve_alpha
    // HDR10+ (10 Oct 2026): x265's --dhdr10-info file, for HDR10 when this
    // ffmpeg's x265 can write it (video.py encode_command hdr10plus=).
    std::optional<std::filesystem::path> hdr10plus;
};

// A path inside -x265-params: ffmpeg splits the options on ':' and reads each
// value as a token where a backslash escapes, a quote quotes and blanks at
// either end are dropped; all of those are escaped (video.py x265_param_path).
std::string x265_param_path(const std::filesystem::path& path);

// x265's master-display string, luminances in 0.0001-nit units (round half even).
std::string mastering_display(double peak_nits, double min_nits);
// The mastering display's primaries in the HDR10 SEI (28 Oct 2026 review): "rec2020"
// (the Python's, the default here) or "p3d65" (what most specs and the grading monitor
// are; the app sets it from Deliver > Export). Process-wide; false for an unknown name.
bool set_mastering_display_primaries(const std::string& name);
std::string mastering_display_primaries();
// "G(...)B(...)R(...)WP(...)" of the current primaries.
std::string mastering_display_primaries_text();

// encode_command: ffmpeg reading the spool (spool/%08d.png) at the clip's rate,
// the source for audio and metadata, into `output`.
Result<std::vector<std::string>> encode_command(const std::string& ffmpeg, const VideoEncodeRequest& request,
                                                const VideoClock& clock, const std::filesystem::path& spool,
                                                const std::filesystem::path& source,
                                                const std::filesystem::path& output, int max_cll, int max_fall);

// A staging folder on the output's volume (tempfile.TemporaryDirectory(prefix,
// dir=output.parent)), removed when this goes out of scope.
class StagingDir {
public:
    static Result<StagingDir> create(const std::filesystem::path& parent, const std::string& prefix);
    StagingDir(StagingDir&&) noexcept;
    StagingDir& operator=(StagingDir&&) noexcept;
    StagingDir(const StagingDir&) = delete;
    StagingDir& operator=(const StagingDir&) = delete;
    ~StagingDir();
    const std::filesystem::path& path() const noexcept { return path_; }

private:
    StagingDir() = default;
    std::filesystem::path path_;
};

// convert_video's last lines: "Output appeared during processing; refusing
// overwrite" when either target exists, else the two renames.
Result<void> publish_video(const std::filesystem::path& staged, const std::filesystem::path& staged_sidecar,
                           const std::filesystem::path& output, const std::filesystem::path& sidecar);

}  // namespace rudra
