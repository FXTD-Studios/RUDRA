#include "export_sheet.hpp"
#include "rudra/deliver/video_encode.hpp"
#include "paths.hpp"

#include <QComboBox>
#include <QDir>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QSettings>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPushButton>
#include <QSpinBox>
#include <QStyle>
#include <QVBoxLayout>

#include <functional>
#include <initializer_list>
#include <utility>
#include <map>

#include "main_window.hpp"
#include "widgets.hpp"

namespace rudra::app {
namespace {

QLabel* label(const QString& text, const QString& id, const QString& role, QWidget* parent) {
    auto* l = new QLabel(text, parent);
    if (!id.isEmpty()) l->setObjectName(id);
    if (!role.isEmpty()) l->setProperty("role", role);
    return l;
}

// A format tile: a click picks it.
class Tile : public QWidget {
public:
    Tile(const QString& id, const QString& name, const QString& sub, bool offered, QWidget* parent)
        : QWidget(parent) {
        setObjectName(id);
        setProperty("role", "tile");
        setAttribute(Qt::WA_StyledBackground, true);
        setFixedHeight(84);
        set_offered(offered);
        auto* v = new QVBoxLayout(this);
        v->setContentsMargins(12, 10, 12, 10);
        v->setSpacing(3);
        v->addStretch(1);
        v->addWidget(label(name, {}, "tile-name", this));
        auto* s = label(sub, {}, "tile-sub", this);
        s->setWordWrap(true);
        v->addWidget(s);
    }
    std::function<void()> picked;
    void set_offered(bool offered) {
        setEnabled(offered);
        setCursor(offered ? Qt::PointingHandCursor : Qt::ArrowCursor);
        setToolTip(offered ? QString()
                           : "For a movie or a folder of frames. A single still goes out as EXR.");
    }
    void set_on(bool on) {
        setProperty("on", on);
        style()->unpolish(this);
        style()->polish(this);
    }

protected:
    void mousePressEvent(QMouseEvent* e) override {
        if (e->button() == Qt::LeftButton && picked) picked();
    }
};

}  // namespace

ExportSheet::ExportSheet(MainWindow* w) : QDialog(w), w_(w) {
    setObjectName("exportSheet");
    setWindowTitle("Export");
    setModal(true);
    setFixedWidth(800);
    auto* v = new QVBoxLayout(this);
    v->setContentsMargins(26, 22, 26, 16);
    v->setSpacing(14);

    auto* head = new QWidget(this);
    auto* hv = new QVBoxLayout(head);
    hv->setContentsMargins(0, 0, 0, 0);
    hv->setSpacing(2);
    title_ = label("Export", "exportTitle", "title", head);
    sub_ = label("", "exportSub", "note", head);
    hv->addWidget(title_);
    hv->addWidget(sub_);
    v->addWidget(head);

    auto* tiles = new QWidget(this);
    auto* tg = new QGridLayout(tiles);
    tg->setContentsMargins(0, 0, 0, 0);
    tg->setSpacing(8);
    const struct { const char* id; const char* name; const char* sub; bool offered; } formats[] = {
        {"exr-aces", "EXR", "ACES 2065-1, float32", true},
        {"exr-linear", "EXR linear", "Rec.2020 linear, float32", true},
        {"hdr10", "HDR10", "HEVC 10-bit, streaming", false},
        {"hlg", "HLG", "HEVC 10-bit, broadcast", false},
        {"prores", "422 HQ", "ProRes, editorial", false},
        {"prores4444", "4444", "ProRes, finishing", false},
        {"ffv1rgb16", "RGB 16-bit", "FFV1 .mkv, lossless PQ", false},
        {"rgb16mov", "MOV 16-bit", "Uncompressed RGB, lossless PQ", false}};
    int col = 0;
    for (const auto& f : formats) {
        auto* t = new Tile(f.id, f.name, f.sub, f.offered, tiles);
        tiles_[f.id] = t;
        const QString id = f.id;
        t->picked = [this, id] { pick(id); };
        tg->addWidget(t, col / 4, col % 4);
        tg->setColumnStretch(col % 4, 1);
        ++col;
    }
    v->addWidget(tiles);

    auto* card = new QWidget(this);
    card->setProperty("role", "card");
    card->setAttribute(Qt::WA_StyledBackground, true);
    auto* cv = new QVBoxLayout(card);
    cv->setContentsMargins(14, 2, 14, 2);
    cv->setSpacing(0);
    auto row = [&](const QString& key, QLabel* value) {
        auto* r = new QWidget(card);
        r->setProperty("role", "field");
        auto* h = new QHBoxLayout(r);
        h->setContentsMargins(0, 10, 0, 10);
        h->addWidget(label(key, {}, "key", r));
        h->addStretch(1);
        value->setProperty("role", "value");
        h->addWidget(value);
        cv->addWidget(r);
    };
    {
        // ProRes only: graded PQ, or the scene-referred master in a camera log.
        enc_row_ = new QWidget(card);
        enc_row_->setObjectName("exportEncodingRow");
        enc_row_->setProperty("role", "field");
        auto* h = new QHBoxLayout(enc_row_);
        h->setContentsMargins(0, 8, 0, 8);
        h->addWidget(label("Encoding", {}, "key", enc_row_));
        h->addStretch(1);
        auto* seg = enc_seg_ = new Seg("exportEncoding", {{"pq", "PQ"}, {"acescct", "ACEScct"}, {"logc4", "LogC4"}}, enc_row_);
        seg->button("pq")->setToolTip("Rec.2020 PQ, graded to the peak and knee on the Deliver tab");
        seg->button("acescct")->setToolTip("ACEScct in ACES AP1: the scene-linear master, no peak or knee");
        seg->button("logc4")->setToolTip("ARRI LogC4 in ARRI Wide Gamut 4: the scene-linear master, no peak or knee");
        seg->clicked = [this](const QString& k) { set_encoding(k); };
        h->addWidget(seg);
        cv->addWidget(enc_row_);
    }
    {
        // A folder of frames has no clock of its own: the movie's frame rate.
        fps_row_ = new QWidget(card);
        fps_row_->setObjectName("exportFpsRow");
        fps_row_->setProperty("role", "field");
        auto* h = new QHBoxLayout(fps_row_);
        h->setContentsMargins(0, 8, 0, 8);
        h->addWidget(label("Frame rate", {}, "key", fps_row_));
        h->addStretch(1);
        fps_ = new QComboBox(fps_row_);
        fps_->setObjectName("exportFps");
        for (const auto& [text, value] : std::initializer_list<std::pair<const char*, double>>{
                 {"23.976", 24000.0 / 1001.0}, {"24", 24.0}, {"25", 25.0}, {"29.97", 30000.0 / 1001.0},
                 {"30", 30.0}, {"48", 48.0}, {"50", 50.0}, {"59.94", 60000.0 / 1001.0}, {"60", 60.0}})
            fps_->addItem(text, value);
        fps_->setCurrentIndex(1);
        h->addWidget(fps_);
        cv->addWidget(fps_row_);
    }
    {
        // The HDR10 SEI's mastering display (28 Oct 2026 review): P3-D65 is what most specs and grading
        // monitors are; Rec.2020 is the Python's. Kept between runs.
        auto* md_row = new QWidget(card);
        md_row->setObjectName("exportMasteringRow");
        md_row->setProperty("role", "field");
        auto* h = new QHBoxLayout(md_row);
        h->setContentsMargins(0, 8, 0, 8);
        h->addWidget(label("Mastering display", {}, "key", md_row));
        h->addStretch(1);
        auto* md = new Seg("exportMastering", {{"p3d65", "P3-D65"}, {"rec2020", "Rec.2020"}}, md_row);
        md->setToolTip("The primaries HDR10 metadata (SMPTE ST 2086) names for the mastering display");
        md->set_on(QString::fromStdString(mastering_display_primaries()));
        md->clicked = [md](const QString& k) {
            if (set_mastering_display_primaries(k.toStdString())) QSettings().setValue("deliver/masteringDisplay", k);
            md->set_on(k);
        };
        h->addWidget(md);
        cv->addWidget(md_row);
    }
    signal_ = label("", "exportSignal", {}, card);
    frames_ = label("", "exportFrames", {}, card);
    dest_ = label("", "exportDest", {}, card);
    row("Signal", signal_);
    row("Frames", frames_);
    row("Save to", dest_);
    row("White", label("diffuse 1.0 = 203 nits", {}, {}, card));
    v->addWidget(card);
    hint_ = label("", "exportHint", "note", this);
    hint_->setWordWrap(true);
    v->addWidget(hint_);

    auto* checks = new QWidget(this);
    auto* chv = new QVBoxLayout(checks);
    chv->setContentsMargins(0, 0, 0, 0);
    chv->setSpacing(8);
    chv->addWidget(label("Checked before the file is published", {}, "note", checks));
    auto* chips = new QWidget(checks);
    auto* chh = new QHBoxLayout(chips);
    chh->setContentsMargins(0, 0, 0, 0);
    chh->setSpacing(6);
    for (const char* c : {"The render plan", "Every name", "Nothing replaced", "Staged, then linked"})
        chh->addWidget(label(c, {}, "chip", chips));
    chh->addStretch(1);
    chv->addWidget(chips);
    auto* side = label("A sidecar with the model, the settings and the frame's measurements is written beside each "
                       "file. Edit the folder and the name on the Deliver tab.",
                       {}, "note", checks);
    side->setWordWrap(true);
    chv->addWidget(side);
    v->addWidget(checks);

    auto* foot = new QWidget(this);
    auto* fh = new QHBoxLayout(foot);
    fh->setContentsMargins(0, 8, 0, 0);
    fh->setSpacing(10);
    fh->addStretch(1);
    auto* queue = new QPushButton("Queue", foot);
    queue->setObjectName("exportQueue");
    queue->setToolTip("The exports queued, with their progress");
    connect(queue, &QPushButton::clicked, this, [this] { w_->open_queue_window(); });
    fh->insertWidget(0, queue);
    auto* cancel = new QPushButton("Cancel", foot);
    cancel->setObjectName("exportCancel");
    auto* go = new QPushButton("Export", foot);
    go->setObjectName("exportGo");
    go->setProperty("role", "primary");
    connect(cancel, &QPushButton::clicked, this, &QDialog::reject);
    connect(go, &QPushButton::clicked, this, [this] { export_now(); });
    fh->addWidget(cancel);
    fh->addWidget(go);
    v->addWidget(foot);
    refresh();
}

namespace {
bool is_video_format(const QString& id) {
    return id == "hdr10" || id == "hlg" || id == "prores" || id == "prores4444" || id == "ffv1rgb16" || id == "rgb16mov";
}
bool is_prores(const QString& id) { return id == "prores" || id == "prores4444"; }
}  // namespace

double ExportSheet::fps() const { return fps_ ? fps_->currentData().toDouble() : 24.0; }

void ExportSheet::set_encoding(const QString& e) {
    if (e != "pq" && e != "acescct" && e != "logc4") return;
    encoding_ = e;
    refresh();
}

QString ExportSheet::video_format() const {
    const QString base = picked_ == "prores" ? QString("prores422hq") : picked_;
    return is_prores(picked_) && encoding_ != "pq" ? base + "_" + encoding_ : base;
}

void ExportSheet::pick(const QString& id) {
    if (is_video_format(id)) {
        if (!w_->shot_is_video() && !w_->shot_is_frame_folder()) return;
        picked_ = id;
        refresh();
        return;
    }
    if (id != "exr-aces" && id != "exr-linear") return;
    picked_ = id;
    // The container is the session's: the same switch as Deliver > container.
    w_->run(id == "exr-aces" ? "container-aces" : "container-linear");
    refresh();
}

void ExportSheet::refresh() {
    const bool folder = !w_->shot_is_video() && w_->shot_is_frame_folder();
    const bool movie = w_->shot_is_video() || folder;
    if (folder) encoding_ = "pq";   // from frames: the graded PQ targets only
    for (const char* id : {"hdr10", "hlg", "prores", "prores4444", "ffv1rgb16", "rgb16mov"})
        if (auto it = tiles_.find(id); it != tiles_.end()) static_cast<Tile*>(it->second)->set_offered(movie);
    if (!(movie && is_video_format(picked_))) picked_ = w_->container() == "linear" ? "exr-linear" : "exr-aces";
    for (const char* id : {"exr-aces", "exr-linear", "hdr10", "hlg", "prores", "prores4444", "ffv1rgb16", "rgb16mov"})
        if (auto* t = findChild<QWidget*>(id)) {
            t->setProperty("on", picked_ == id);
            t->style()->unpolish(t);
            t->style()->polish(t);
        }
    const auto& frames = w_->frames();
    const QString shot = frames.empty() ? QStringLiteral("no shot") : w_->shot_title();
    title_->setText("Export " + shot);
    sub_->setText(QStringLiteral("%1 frame%2 loaded").arg(frames.size()).arg(frames.size() == 1 ? "" : "s"));
    const QString dir = w_->findChild<QLineEdit*>("renderDir")->text().trimmed();
    const QString name = w_->findChild<QLineEdit*>("renderName")->text().trimmed();
    const bool prores = is_prores(picked_);
    enc_row_->setVisible(prores && !folder);
    fps_row_->setVisible(folder && is_video_format(picked_));
    if (enc_seg_) enc_seg_->set_on(encoding_);
    const QString pr = picked_ == "prores4444" ? "ProRes 4444" : "ProRes 422 HQ 10-bit";
    const bool log = prores && encoding_ != "pq";
    hint_->setVisible(log);
    hint_->setText(encoding_ == "acescct"
                       ? "Scene-referred: the master before peak and knee. Set the clip's input to ACEScct (AP1) in "
                         "Resolve, or read it as ACEScct in an ACES pipeline."
                       : "Scene-referred: the master before peak and knee. Set the clip to ARRI LogC4 / AWG4 in "
                         "Resolve, or apply ARRI's LogC4 input transform.");
    if (is_video_format(picked_)) {
        signal_->setText(picked_ == "hdr10"  ? "PQ · Rec.2020 · HEVC 10-bit · HDR10 metadata"
                         : picked_ == "hlg" ? "HLG · Rec.2020 · HEVC 10-bit"
                         : picked_ == "ffv1rgb16" ? "PQ · Rec.2020 · FFV1 · lossless 16-bit RGB"
                         : picked_ == "rgb16mov" ? "PQ · Rec.2020 · uncompressed 16-bit RGB MOV"
                         : encoding_ == "acescct" ? "ACEScct · AP1 · " + pr + " · scene-referred"
                         : encoding_ == "logc4"   ? "LogC4 · ARRI Wide Gamut 4 · " + pr + " · scene-referred"
                                                  : "PQ · Rec.2020 · " + pr);
        const QString ext = picked_ == "ffv1rgb16" ? ".mkv" : picked_.startsWith("prores") || picked_ == "rgb16mov" ? ".mov" : ".mp4";
        if (folder) {
            frames_->setText(QStringLiteral("All %1, mastered as EXR, then as a movie (no audio)").arg(frames.size()));
            const QString base = w_->frames_movie_base(video_format());
            dest_->setText(dir.isEmpty() ? QStringLiteral("choose a folder on the Deliver tab")
                                         : QDir::toNativeSeparators(dir) + QDir::separator() + base + ext);
        } else {
            frames_->setText(QStringLiteral("All %1, as a movie with its audio").arg(frames.size()));
            const QString file = (name.isEmpty() ? from_path(w_->shot_video()->path.stem()) + "_" +
                                                       video_format()
                                                 : name + (log ? "_" + encoding_ : QString())) +
                                 ext;
            dest_->setText(dir.isEmpty() ? QStringLiteral("choose a folder on the Deliver tab")
                                         : QDir::toNativeSeparators(dir) + QDir::separator() + file);
        }
    } else {
        signal_->setText(picked_ == "exr-aces" ? "Scene linear · AP0 · float32" : "Scene linear · Rec.2020 · float32");
        auto* mode = w_->findChild<QComboBox*>("renderMode");
        const bool sequence = mode && mode->currentData().toString() == "sequence";
        frames_->setText(sequence ? QStringLiteral("All %1, as a sequence").arg(frames.size()) : QStringLiteral("The frame on screen"));
        dest_->setText(dir.isEmpty() ? QStringLiteral("choose a folder on the Deliver tab")
                                     : QDir::toNativeSeparators(dir) + QDir::separator() + name +
                                           (sequence ? QStringLiteral(".######.exr") : QStringLiteral(".exr")));
    }
    if (auto* go = findChild<QPushButton*>("exportGo")) go->setEnabled(!dir.isEmpty() && !frames.empty());
}

void ExportSheet::export_now() {
    if (is_video_format(picked_) && !w_->shot_is_video()) {
        if (w_->export_frames_to_movie(video_format(), fps())) accept();
        return;
    }
    if (is_video_format(picked_)) {
        if (w_->queue_video_export(video_format())) {
            accept();
            w_->open_queue_window();
        }
        return;
    }
    accept();
    w_->master();   // the analytic Master EXR (the Deliver tab's Render may be set to a movie)
}

void MainWindow::open_export_sheet() {
    if (!export_sheet_) export_sheet_ = new ExportSheet(this);
    static_cast<ExportSheet*>(export_sheet_.data())->refresh();
    export_sheet_->show();
    export_sheet_->raise();
}

}  // namespace rudra::app
