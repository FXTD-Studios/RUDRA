#include "rudra/core/composite.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>

#include "rudra/core/baseline.hpp"
#include "rudra/core/compare.hpp"

namespace rudra {
namespace {

// rudra/hdr10.py REC2020_LUMA is a float32 array; controls.py multiplies
// float64 nits by it, so the weights are the float32-rounded values, widened.
constexpr double kLuma2020f[3] = {static_cast<double>(0.2627f), static_cast<double>(0.6780f),
                                  static_cast<double>(0.0593f)};

inline float sigmoidf(float x) noexcept { return 1.0f / (1.0f + std::exp(-x)); }

}  // namespace

std::vector<RegionBand> default_region_bands() {
    return {{400.0, 2000.0, 0.0}, {2000.0, 8000.0, 0.0}, {0.05, 12.0, 0.0}};
}

std::vector<float> baseline_curve_params(const FrameScalars& scalars, const CompositeParams& params, float corpus_ev) {
    std::vector<float> out = effective_curve_params(scalars.curve_params, params.source);
    std::vector<float> cal;
    if (!params.reference.empty()) cal = reference_params(params.reference, params.source, corpus_ev);
    else if (!params.calibration.empty() && calibration_is_monotone(params.calibration, params.source, corpus_ev))
        cal = calibration_params(params.calibration, params.source, corpus_ev);
    if (cal.empty()) return out;
    if (out.size() < 3) return cal;   // nothing else: the calibration alone
    if (out.size() == cal.size()) {
        for (std::size_t i = 1; i < out.size(); ++i) out[i] += cal[i];
        return out;
    }
    // A CurveHead with its own knot count and no source: resample it onto the
    // calibration's codes and add.
    std::vector<float> merged(cal);
    merged[0] += out[0];
    for (int i = 0; i < kSourceCurveKnots; ++i)
        merged[1 + i] += curve_correction_log2(float(i) / (kSourceCurveKnots - 1), out) - out[0];
    return merged;
}

std::vector<float> anchor_target_knots(const CompositeParams& params) {
    const bool plain = (params.source == SourceCurve::Unknown || params.source == SourceCurve::Aces) &&
                       params.calibration.empty() && params.reference.empty();
    if (plain) return {};
    PlanarBuffer ramp(3, 1, kSourceCurveKnots);
    for (int k = 0; k < kSourceCurveKnots; ++k)
        for (int c = 0; c < 3; ++c) ramp.at(c, 0, k) = float(k) / float(kSourceCurveKnots - 1);
    CompositeParams curve_only;
    curve_only.source = params.source;
    curve_only.calibration = params.calibration;
    curve_only.reference = params.reference;
    const NetworkLinearImage base =
        corrected_baseline(SdrImage(std::move(ramp)), 0.0f, baseline_curve_params(FrameScalars{}, curve_only, 0.0f));
    std::vector<float> knots(std::size_t(kSourceCurveKnots), 0.0f);
    for (int k = 1; k < kSourceCurveKnots; ++k) {
        const double want = double(base.buffer().at(1, 0, k)) * (10000.0 / 203.0);
        const double have = double(srgb_to_linear(float(k) / float(kSourceCurveKnots - 1)));
        knots[std::size_t(k)] = (want > 0.0 && have > 0.0) ? float(std::log2(want / have)) : 0.0f;
    }
    knots[0] = knots[1];   // 0/0 at black: the code-1 ratio, flat into black
    return knots;
}

float anchor_target_log2(float code, std::span<const float> knots) noexcept {
    if (knots.size() < 2) return 0.0f;
    const int n = int(knots.size());
    const float pos = std::clamp(code, 0.0f, 1.0f) * float(n - 1);
    const int lo = std::min(int(std::floor(pos)), n - 2);
    const float frac = pos - float(lo);
    const float v0 = knots[std::size_t(lo)], v1 = knots[std::size_t(lo + 1)];
    return v0 + (v1 - v0) * frac;
}

double exposure_gain(double ev) noexcept { return std::isfinite(ev) ? std::exp2(ev) : 1.0; }

std::string reconstruction_region_error(const ReconstructionRegion& r) {
    const float v[] = {r.highlight_from, r.highlight_softness, r.highlight_strength, r.shadow_below,
                       r.shadow_softness, r.shadow_strength, r.band_low, r.band_high, r.band_softness};
    for (float x : v)
        if (!std::isfinite(x)) return "every reconstruction region value must be finite";
    for (float x : {r.highlight_from, r.shadow_below, r.band_low, r.band_high})
        if (x < 0.0f || x > 1.0f) return "reconstruction region thresholds are SDR luma, 0 to 1";
    for (float x : {r.highlight_softness, r.shadow_softness, r.band_softness})
        if (x < 0.0f || x > 0.5f) return "reconstruction region softness is 0 to 0.5";
    for (float x : {r.highlight_strength, r.shadow_strength})
        if (x < 0.0f || x > 2.0f) return "reconstruction region strength is 0 to 2";
    if (!(r.band_low < r.band_high)) return "the reconstruction band's low must be below its high";
    return {};
}

float region_ramp_up(float y, float at, float softness) noexcept {
    if (!(softness > 0.0f)) return y >= at ? 1.0f : 0.0f;
    const float t = std::clamp((y - (at - 0.5f * softness)) / softness, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

float region_ramp_down(float y, float at, float softness) noexcept {
    if (!(softness > 0.0f)) return y <= at ? 1.0f : 0.0f;
    const float t = std::clamp(((at + 0.5f * softness) - y) / softness, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

void region_weights(float y, const ReconstructionRegion& r, float& highlight, float& shadow) noexcept {
    if (!r.enabled) {
        highlight = shadow = 1.0f;
        return;
    }
    if (r.band) {
        const float b = region_ramp_up(y, r.band_low, r.band_softness) * region_ramp_down(y, r.band_high, r.band_softness);
        highlight = b * r.highlight_strength;
        shadow = b * r.shadow_strength;
        return;
    }
    highlight = region_ramp_up(y, r.highlight_from, r.highlight_softness) * r.highlight_strength;
    shadow = region_ramp_down(y, r.shadow_below, r.shadow_softness) * r.shadow_strength;
}

float reconstruction_gate(float y, float shadow_weight, const CompositeParams& params) noexcept {
    float hp = sigmoidf((y - 0.82f) * 24.0f);
    float sp = sigmoidf((0.10f - y) * 24.0f) * shadow_weight;
    if (params.region.enabled) {   // revision 2; off leaves revision 1's arithmetic untouched
        float wh = 1.0f, ws = 1.0f;
        region_weights(y, params.region, wh, ws);
        hp *= wh;
        sp *= ws;
    }
    float gate = 0.0f;
    switch (params.mode) {
        case RecoveryMode::All: gate = std::max(hp, sp); break;
        case RecoveryMode::Highlights: gate = hp; break;
        case RecoveryMode::Shadows: gate = sp; break;
        case RecoveryMode::Off: gate = 0.0f; break;
    }
    return gate * params.strength;
}

PixelClassMap classify_pixels(const SdrImage& sdr, const NetworkLinearImage& reconstruction,
                              const NetworkLinearImage& baseline, const PlanarBuffer* generated) {
    const int h = sdr.height(), w = sdr.width();
    PixelClassMap m;
    m.width = w;
    m.height = h;
    const std::size_t n = std::size_t(h) * std::size_t(w);
    m.cls.assign(n, 0);
    m.confidence = PlanarBuffer(1, h, w);
    const PlanarBuffer& s = sdr.buffer();
    const PlanarBuffer& r = reconstruction.buffer();
    const PlanarBuffer& b = baseline.buffer();
    const bool gen = generated && generated->channels() == 1 && generated->height() == h && generated->width() == w;
    std::array<std::size_t, kPixelClasses> count{};
    for (std::size_t i = 0; i < n; ++i) {
        bool exact = true;
        float rm = 0.0f, bm = 0.0f, code = 0.0f;
        for (int c = 0; c < 3; ++c) {
            exact = exact && r.plane(c)[i] == b.plane(c)[i];
            rm = std::max(rm, r.plane(c)[i]);
            bm = std::max(bm, b.plane(c)[i]);
            code = std::max(code, std::clamp(s.plane(c)[i], 0.0f, 1.0f));
        }
        const double floor = kChangeFloorNits / 10000.0;
        const double d = std::log2((std::max(double(rm), 0.0) + floor) / (std::max(double(bm), 0.0) + floor));
        PixelClass k;
        float conf;
        if (gen && generated->plane(0)[i] > 0.0f) {
            k = PixelClass::Generated;
            conf = 0.0f;
        } else if (exact) {
            k = PixelClass::Preserved;
            conf = 1.0f;
        } else if (std::abs(d) <= kChangeStops) {
            k = PixelClass::Follows;
            conf = 1.0f;
        } else if (sdr_has_no_information(code)) {
            k = PixelClass::Estimated;
            conf = float(0.5 / (1.0 + std::abs(d)));
        } else {
            k = PixelClass::Reconstructed;
            conf = float(1.0 / (1.0 + std::abs(d)));
        }
        m.cls[i] = std::uint8_t(k);
        m.confidence.plane(0)[i] = conf;
        ++count[std::size_t(k)];
    }
    for (int k = 0; k < kPixelClasses; ++k) m.share[std::size_t(k)] = n ? double(count[std::size_t(k)]) / double(n) : 0.0;
    return m;
}

CompositeParams ungraded(CompositeParams params) {
    params.regions.clear();
    params.exposure_ev = 0.0;
    return params;
}

ReconstructionMattes reconstruction_mattes(const SdrImage& sdr, const Fields& fields, const FrameScalars& scalars,
                                           const CompositeParams& params, const NetworkLinearImage& reconstruction,
                                           const NetworkLinearImage& baseline) {
    const int h = sdr.height(), w = sdr.width();
    assert(reconstruction.height() == h && baseline.height() == h);
    ReconstructionMattes m{PlanarBuffer(1, h, w), PlanarBuffer(1, h, w), PlanarBuffer(1, h, w), std::nullopt};
    if (params.region.enabled) m.region.emplace(1, h, w);
    const PlanarBuffer& s = sdr.buffer();
    const float* hl = fields.highlight.plane(0);
    const float* sh = fields.shadow.plane(0);
    const bool want_h = params.mode == RecoveryMode::All || params.mode == RecoveryMode::Highlights;
    const bool want_s = params.mode == RecoveryMode::All || params.mode == RecoveryMode::Shadows;
    const std::size_t n = std::size_t(h) * std::size_t(w);
    for (std::size_t i = 0; i < n; ++i) {
        auto code = [&](int c) { return std::clamp(s.plane(c)[i], 0.0f, 1.0f); };
        const float y = 0.2126f * code(0) + 0.7152f * code(1) + 0.0722f * code(2);
        float hp = sigmoidf((y - 0.82f) * 24.0f);
        float sp = sigmoidf((0.10f - y) * 24.0f) * scalars.shadow_weight;
        float wh = 1.0f, ws = 1.0f;
        region_weights(y, params.region, wh, ws);
        if (params.region.enabled) {
            hp *= wh;
            sp *= ws;
            m.region->plane(0)[i] = std::clamp(std::max(wh, ws), 0.0f, 1.0f);
        }
        const float rec = params.preserve_outside ? std::max(hl[i], sh[i]) : 1.0f;
        m.highlight.plane(0)[i] = want_h ? std::clamp(hp * params.strength * rec, 0.0f, 1.0f) : 0.0f;
        m.shadow.plane(0)[i] = want_s ? std::clamp(sp * params.strength * rec, 0.0f, 1.0f) : 0.0f;
        bool differs = false;
        for (int c = 0; c < 3; ++c) differs = differs || reconstruction.buffer().plane(c)[i] != baseline.buffer().plane(c)[i];
        m.changed.plane(0)[i] = differs ? 1.0f : 0.0f;
    }
    return m;
}

bool any_graded(std::span<const RegionBand> bands) noexcept {
    return std::any_of(bands.begin(), bands.end(), [](const RegionBand& b) { return b.ev != 0.0; });
}

float qualifier_mask(double luma_nits, double low_nits, double high_nits, double softness_stops) noexcept {
    const double y = std::max(luma_nits, 1e-6);
    const double log_y = std::log2(y);
    const double soft = std::max(softness_stops, 1e-3);
    const double rise = std::clamp((log_y - (std::log2(low_nits) - soft)) / soft, 0.0, 1.0);
    const double fall = std::clamp(((std::log2(high_nits) + soft) - log_y) / soft, 0.0, 1.0);
    const double m = std::min(rise, fall);
    return static_cast<float>(m * m * (3.0 - 2.0 * m));
}

double region_ev_gain(const double rgb_nits[3], std::span<const RegionBand> bands, double softness_stops,
                      const float* weights) noexcept {
    double y = 0.0;
    for (int c = 0; c < 3; ++c) y += std::max(rgb_nits[c], 0.0) * kLuma2020f[c];
    double total = 0.0;
    std::size_t i = 0;
    for (const auto& b : bands) {
        const std::size_t band = i++;
        if (b.ev == 0.0) continue;
        // numpy: a Python float times a float32 array is a float32 product
        // (NEP 50), widened only when it is added to the float64 total.
        float term = static_cast<float>(b.ev) * qualifier_mask(y, b.low_nits, b.high_nits, softness_stops);
        if (weights && band < std::size_t(kMaxMaskBands)) term *= weights[band];   // the painted mask (3.3)
        total += static_cast<double>(term);
    }
    return std::exp2(total);
}

NetworkLinearImage composite(const SdrImage& sdr, const Fields& fields, const FrameScalars& scalars,
                             const ModelConstants& model, const CompositeParams& params,
                             std::vector<float>* grade_gain) {
    const int h = sdr.height(), w = sdr.width();
    assert(fields.residual.channels() == 3 && fields.residual.height() == h && fields.residual.width() == w);
    assert(fields.highlight.height() == h && fields.shadow.height() == h);

    // The baseline reads the clamped SDR, as forward() does.
    PlanarBuffer clamped = sdr.buffer();
    for (float& v : clamped.span()) v = std::clamp(v, 0.0f, 1.0f);
    const SdrImage sdr_c(std::move(clamped));
    const NetworkLinearImage base = corrected_baseline(sdr_c, model.corpus_ev, baseline_curve_params(scalars, params, model.corpus_ev));

    const float log_scale = model.log_scale;
    const float log_ceiling = std::log1p(model.max_hdr * log_scale);
    const bool banded = any_graded(params.regions);
    const double exposure = exposure_gain(params.exposure_ev);
    const bool graded = banded || exposure != 1.0;
    const bool masked = banded && params.masks && !params.masks->empty();
    const double ceiling_nits = static_cast<double>(model.max_hdr) * 10000.0;

    NetworkLinearImage out(h, w);
    const std::size_t n = static_cast<std::size_t>(h) * w;
    const PlanarBuffer& s = sdr_c.buffer();
    const PlanarBuffer& b = base.buffer();
    const PlanarBuffer& r = fields.residual;
    const float* hl = fields.highlight.plane(0);
    const float* sh = fields.shadow.plane(0);
    PlanarBuffer& o = out.buffer();
    if (grade_gain) grade_gain->assign(n, 1.0f);

    for (std::size_t i = 0; i < n; ++i) {
        const float y = 0.2126f * s.plane(0)[i] + 0.7152f * s.plane(1)[i] + 0.0722f * s.plane(2)[i];
        const float gate = reconstruction_gate(y, scalars.shadow_weight, params);
        // Revision 2: outside the region (gate exactly 0) the pixel is the baseline itself.
        const bool keep_base = params.region.enabled && gate == 0.0f;
        const float recovery = std::max(hl[i], sh[i]);
        float px[3];
        for (int c = 0; c < 3; ++c) {
            const float base_c = b.plane(c)[i];
            if (keep_base) {
                px[c] = base_c;
                continue;
            }
            const float pred_log = std::clamp(std::log1p(base_c * log_scale) + r.plane(c)[i] * gate, 0.0f, log_ceiling);
            float pred = std::expm1(pred_log) / log_scale;
            if (params.preserve_outside) pred = base_c + recovery * (pred - base_c);
            px[c] = pred;
        }
        if (graded) {
            // The exposure first; the bands read the exposed nits (13 Oct 2026).
            double nits[3] = {px[0] * 10000.0 * exposure, px[1] * 10000.0 * exposure, px[2] * 10000.0 * exposure};
            float mw[kMaxMaskBands];
            if (masked) params.masks->weights(int(i % std::size_t(w)), int(i / std::size_t(w)), w, h, mw);
            const double band = banded ? region_ev_gain(nits, params.regions, params.region_softness_stops, masked ? mw : nullptr) : 1.0;
            const double g = band * exposure;
            for (int c = 0; c < 3; ++c) nits[c] /= exposure;
            if (grade_gain) (*grade_gain)[i] = static_cast<float>(g);
            for (int c = 0; c < 3; ++c)
                px[c] = static_cast<float>(std::clamp(nits[c] * g, 0.0, ceiling_nits) / 10000.0);
        }
        for (int c = 0; c < 3; ++c) o.plane(c)[i] = px[c];
    }
    return out;
}

}  // namespace rudra
