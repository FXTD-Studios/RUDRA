#include "rudra/core/source_curve.hpp"

#include <algorithm>
#include <array>
#include <cmath>

#include "rudra/core/baseline.hpp"

namespace rudra {
namespace {

// The picker's order: BT.1886, the app's default since 13 Oct 2026, beside
// Unknown; its measured-shadows variant (opt-in) right after it.
constexpr std::array<SourceCurve, 8> kAll = {SourceCurve::Unknown,   SourceCurve::Bt1886, SourceCurve::Bt1886Shadows,
                                             SourceCurve::Aces,      SourceCurve::Hable,  SourceCurve::Agx,
                                             SourceCurve::CameraLog, SourceCurve::Clip};

// pipeline/sdr_render.py, float32 as numpy runs it; the constants are its.
float forward_aces(float x) noexcept {
    return std::clamp((x * (2.51f * x + 0.03f)) / (x * (2.43f * x + 0.59f) + 0.14f), 0.0f, 1.0f);
}

float forward_hable(float x) noexcept {
    constexpr float a = 0.15f, b = 0.50f, c = 0.10f, d = 0.20f, e = 0.02f, f = 0.30f;
    const auto h = [](float v) { return (v * (a * v + c * b) + d * e) / (v * (a * v + b) + d * f) - e / f; };
    return std::clamp(h(x * 2.0f) / h(11.2f), 0.0f, 1.0f);
}

float forward_agx(float x) noexcept {
    constexpr float lo = -12.47f, hi = 4.03f, contrast = 1.0f;
    float t = (std::log2(std::max(x, std::exp2(lo))) - lo) / (hi - lo);
    t = std::clamp(t, 0.0f, 1.0f);
    const float s = 1.0f / (1.0f + std::exp(-(t - 0.6f) * 10.0f * contrast));
    const float s0 = 1.0f / (1.0f + std::exp(0.6f * 10.0f * contrast));
    const float s1 = 1.0f / (1.0f + std::exp(-0.4f * 10.0f * contrast));
    return std::pow(std::clamp((s - s0) / (s1 - s0), 0.0f, 1.0f), 2.2f);
}

float forward_camera_log(float x) noexcept {
    constexpr float contrast = 1.0f;
    float lg = std::log2(std::max(x, 1e-6f) / 0.18f) / 14.0f + 0.5f;
    lg = std::clamp(lg, 0.0f, 1.0f);
    const float k = 7.0f * contrast;
    const float s = 1.0f / (1.0f + std::exp(-(lg - 0.5f) * k));
    const float s0 = 1.0f / (1.0f + std::exp(0.5f * k));
    const float s1 = 1.0f / (1.0f + std::exp(-0.5f * k));
    return std::pow(std::clamp((s - s0) / (s1 - s0), 0.0f, 1.0f), 2.4f);
}

float forward_clip(float x) noexcept { return std::clamp(x, 0.0f, 1.0f); }

// BT.1886 at zero black, 100 % = diffuse white: scene = code^2.4, `code` the
// BT.709 code of the video. RUDRA reads BT.709 video through the inverse of
// the BT.709 OETF (canonicalize_sdr "rec709"), so the light it holds is
// that inverse; the BT.709 OETF of it is the code again.
float bt709_oetf(float x) noexcept { return x < 0.018f ? 4.5f * x : 1.099f * std::pow(x, 0.45f) - 0.099f; }
float bt709_inverse_oetf(float v) noexcept { return v < 0.081f ? v / 4.5f : std::pow((v + 0.099f) / 1.099f, 1.0f / 0.45f); }
float forward_bt1886(float x) noexcept { return bt709_inverse_oetf(std::pow(std::clamp(x, 0.0f, 1.0f), 1.0f / 2.4f)); }
float inverse_bt1886(float display) noexcept { return std::pow(bt709_oetf(std::clamp(display, 0.0f, 0.995f)), 2.4f); }

// BT.1886 shadows (14 Oct 2026). log2 scene-linear (diffuse white 1.0 = 203
// nits) at SDR codes 1..39: the median target of the training titles (Cosmos
// Laundromat, Nocturne, Sol Levante; 60 frames each, equal title weight),
// blended back to BT.1886 over codes 20..39, monotone, rising at least 0.02
// stop per code. tools/shadow_correction_eval.py fit + relut (fit_v3.json,
// SHA256 183d772e...); scored through this exact knot path on held-out Sparks
// and Meridian (docs/ai/SHADOW_CORRECTION_RESULT.md). rudra/source_baseline.py
// holds the same numbers. Code 0 stays 0, as every curve here.
constexpr int kShadowKnee = 40;
constexpr std::array<float, kShadowKnee> kShadowLog2Scene = {
    0.0f,   // code 0: unused, the inverse is 0 there
    -14.685428f, -14.249545f, -14.009058f, -13.741516f, -13.537101f, -13.242504f,
    -13.008029f, -12.860731f, -12.457915f, -12.053934f, -12.033934f, -12.013934f,
    -11.993934f, -11.973934f, -11.252472f, -10.590089f, -10.570089f, -10.389724f,
    -10.164267f, -10.013963f, -9.968597f, -9.929899f, -9.870572f, -9.778883f,
    -9.693991f, -9.599686f, -9.497595f, -9.392905f, -9.292866f, -9.197775f,
    -9.111351f, -9.028863f, -8.925111f, -8.815446f, -8.703925f, -8.587965f,
    -8.450235f, -8.357113f, -8.253048f,
};

float linear_to_srgb_code(float lin) noexcept {   // display-linear -> 8-bit code, continuous
    const float x = std::clamp(lin, 0.0f, 1.0f);
    const float v = x <= 0.0031308f ? x * 12.92f : 1.055f * std::pow(x, 1.0f / 2.4f) - 0.055f;
    return v * 255.0f;
}

float shadow_scene_at(float code) noexcept {      // code in [0, kShadowKnee]
    if (code <= 0.0f) return 0.0f;
    if (code < 1.0f) return code * std::exp2(kShadowLog2Scene[1]);
    const float knee = std::log2(inverse_bt1886(srgb_to_linear(float(kShadowKnee) / 255.0f)));
    const int i = std::min(int(code), kShadowKnee - 1);
    const float t = code - float(i);
    const float a = kShadowLog2Scene[std::size_t(i)];
    const float b = i + 1 < kShadowKnee ? kShadowLog2Scene[std::size_t(i + 1)] : knee;
    return std::exp2(a + (b - a) * t);
}

float inverse_bt1886_shadows(float display) noexcept {
    // Branch on the display value of the knee code, not a re-encoded code, so
    // code 40 and above are BT.1886 bit for bit.
    static const float knee_display = srgb_to_linear(float(kShadowKnee) / 255.0f);
    if (display >= knee_display) return inverse_bt1886(display);
    return shadow_scene_at(std::min(linear_to_srgb_code(display), float(kShadowKnee)));
}

float forward_bt1886_shadows(float x) noexcept {
    const float knee_scene = shadow_scene_at(float(kShadowKnee));
    if (x >= knee_scene) return forward_bt1886(x);
    float lo = 0.0f, hi = float(kShadowKnee);   // shadow_scene_at is increasing in the code
    for (int k = 0; k < 40; ++k) {
        const float mid = 0.5f * (lo + hi);
        (shadow_scene_at(mid) < x ? lo : hi) = mid;
    }
    return srgb_to_linear(0.5f * (lo + hi) / 255.0f);
}

// A dense monotone table of (display, scene) over 22 stops of exposure, read
// by bisection and linear interpolation. Every curve above is non-decreasing.
struct InverseTable {
    static constexpr int kN = 8001;
    static constexpr double kLo = -16.0, kHi = 6.0;
    std::array<float, kN> x{}, y{};

    explicit InverseTable(SourceCurve c) {
        for (int i = 0; i < kN; ++i) {
            x[i] = static_cast<float>(std::exp2(kLo + (kHi - kLo) * i / (kN - 1)));
            y[i] = source_curve_forward(c, x[i]);
        }
        for (int i = 1; i < kN; ++i) y[i] = std::max(y[i], y[i - 1]);   // float noise never breaks the order
    }

    float at(float display) const noexcept {
        const float v = std::clamp(display, 0.0f, 0.995f);
        const auto it = std::lower_bound(y.begin(), y.end(), v);
        if (it == y.begin()) return 0.0f;
        const auto i = static_cast<int>(it - y.begin());
        if (it == y.end()) return x[kN - 1];
        const float y0 = y[i - 1], y1 = y[i];
        const float t = y1 > y0 ? (v - y0) / (y1 - y0) : 0.0f;
        return x[i - 1] + (x[i] - x[i - 1]) * t;
    }
};

const InverseTable& table(SourceCurve c) {
    static const InverseTable hable(SourceCurve::Hable), agx(SourceCurve::Agx), camera(SourceCurve::CameraLog),
        clip(SourceCurve::Clip);
    switch (c) {
        case SourceCurve::Hable: return hable;
        case SourceCurve::Agx: return agx;
        case SourceCurve::CameraLog: return camera;
        default: return clip;
    }
}

std::vector<float> build_params(SourceCurve c) {
    std::vector<float> p(1 + kSourceCurveKnots, 0.0f);
    for (int code = 0; code < kSourceCurveKnots; ++code) {
        const float display = srgb_to_linear(static_cast<float>(code) / 255.0f);
        const float want = source_curve_inverse(c, display);
        const float have = inverse_aces_approx(display);
        // Both inverses are 0 at code 0; the ratio there is a convention, and
        // the one that keeps the knot line flat into black is the code-1 value.
        p[1 + code] = (want > 0.0f && have > 0.0f) ? std::log2(want / have) : 0.0f;
    }
    p[1] = p[2];
    return p;
}

}  // namespace

std::string_view source_curve_id(SourceCurve c) noexcept {
    switch (c) {
        case SourceCurve::Aces: return "aces";
        case SourceCurve::Hable: return "hable";
        case SourceCurve::Agx: return "agx";
        case SourceCurve::CameraLog: return "camera_log";
        case SourceCurve::Clip: return "clip";
        case SourceCurve::Bt1886: return "bt1886";
        case SourceCurve::Bt1886Shadows: return "bt1886_shadows";
        default: return "unknown";
    }
}

std::optional<SourceCurve> parse_source_curve(std::string_view id) noexcept {
    for (SourceCurve c : kAll)
        if (source_curve_id(c) == id) return c;
    return std::nullopt;
}

std::span<const SourceCurve> all_source_curves() noexcept { return kAll; }

std::string_view source_curve_label(SourceCurve c) noexcept {
    switch (c) {
        case SourceCurve::Aces: return "ACES";
        case SourceCurve::Hable: return "Filmic";
        case SourceCurve::Agx: return "AgX";
        case SourceCurve::CameraLog: return "Camera log";
        case SourceCurve::Clip: return "Rec.709";
        case SourceCurve::Bt1886: return "BT.1886";
        case SourceCurve::Bt1886Shadows: return "BT.1886 shadows";
        default: return "Unknown";
    }
}

std::string_view source_curve_detail(SourceCurve c) noexcept {
    switch (c) {
        case SourceCurve::Aces: return "Narkowicz";
        case SourceCurve::Hable: return "Hable";
        case SourceCurve::Agx: return "sigmoid";
        case SourceCurve::CameraLog: return "log to 709";
        case SourceCurve::Clip: return "plain clip";
        case SourceCurve::Bt1886: return "display 2.4";
        case SourceCurve::Bt1886Shadows: return "BT.1886, measured real-SDR blacks below code 40";
        default: return "ACES, as before";
    }
}

float source_curve_forward(SourceCurve c, float x) noexcept {
    switch (c) {
        case SourceCurve::Hable: return forward_hable(x);
        case SourceCurve::Agx: return forward_agx(x);
        case SourceCurve::CameraLog: return forward_camera_log(x);
        case SourceCurve::Clip: return forward_clip(x);
        case SourceCurve::Bt1886: return forward_bt1886(x);
        case SourceCurve::Bt1886Shadows: return forward_bt1886_shadows(x);
        default: return forward_aces(x);
    }
}

float source_curve_inverse(SourceCurve c, float display) noexcept {
    switch (c) {
        case SourceCurve::Unknown:
        case SourceCurve::Aces: return inverse_aces_approx(display);
        case SourceCurve::Bt1886: return inverse_bt1886(display);
        case SourceCurve::Bt1886Shadows: return inverse_bt1886_shadows(display);
        default: return table(c).at(display);
    }
}

std::span<const float> source_curve_params(SourceCurve c) {
    static const std::vector<float> none;
    static const std::vector<float> hable = build_params(SourceCurve::Hable), agx = build_params(SourceCurve::Agx),
                                    camera = build_params(SourceCurve::CameraLog), clip = build_params(SourceCurve::Clip),
                                    bt1886 = build_params(SourceCurve::Bt1886),
                                    bt1886_shadows = build_params(SourceCurve::Bt1886Shadows);
    switch (c) {
        case SourceCurve::Hable: return hable;
        case SourceCurve::Agx: return agx;
        case SourceCurve::CameraLog: return camera;
        case SourceCurve::Clip: return clip;
        case SourceCurve::Bt1886: return bt1886;
        case SourceCurve::Bt1886Shadows: return bt1886_shadows;
        default: return none;
    }
}

std::vector<float> effective_curve_params(std::span<const float> model_params, SourceCurve source) {
    const std::span<const float> src = source_curve_params(source);
    if (src.empty()) return std::vector<float>(model_params.begin(), model_params.end());
    std::vector<float> out(src.begin(), src.end());
    if (model_params.size() < 3) return out;   // no CurveHead: the source alone
    // The model's knots, resampled at the source's codes, add in log2.
    out[0] += model_params[0];
    const int knots = kSourceCurveKnots;
    for (int i = 0; i < knots; ++i)
        out[1 + i] += curve_correction_log2(static_cast<float>(i) / (knots - 1), model_params) - model_params[0];
    return out;
}

}  // namespace rudra
