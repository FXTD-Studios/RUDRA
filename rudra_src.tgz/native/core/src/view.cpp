#include "rudra/core/view.hpp"

#include "rudra/core/compare.hpp"
#include "rudra/core/composite.hpp"
#include "rudra/core/gamut.hpp"
#include "rudra/core/hdr10.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>

namespace rudra {
namespace {

constexpr float kPeak = 10000.0f;   // network units to nits

// Zone upper bounds (nits) and colours, docs/view.spec.md section 2.
constexpr std::array<float, 9> kZoneBelow{0.1f, 1.0f, 10.0f, 100.0f, 160.0f, 250.0f, 1000.0f, 4000.0f, 10000.0f};
constexpr std::array<std::array<float, 3>, 10> kZoneColour{{
    {0.169f, 0.122f, 0.239f}, {0.184f, 0.294f, 0.561f}, {0.184f, 0.561f, 0.722f},
    {0.200f, 0.627f, 0.416f}, {0.604f, 0.655f, 0.698f}, {0.914f, 0.929f, 0.945f},
    {0.910f, 0.765f, 0.290f}, {0.910f, 0.529f, 0.227f}, {0.816f, 0.263f, 0.184f},
    {0.780f, 0.290f, 0.780f},
}};

float lum2020(float r, float g, float b) noexcept {
    return r * kRec2020Luma[0] + g * kRec2020Luma[1] + b * kRec2020Luma[2];
}

float srgb_to_linear(float c) noexcept {
    c = std::clamp(c, 0.0f, 1.0f);
    return c > 0.04045f ? std::pow((c + 0.055f) / 1.055f, 2.4f) : c / 12.92f;
}

using Mat3f = std::array<float, 9>;
Mat3f to_float(const Mat3& m) {
    Mat3f f{};
    for (int i = 0; i < 9; ++i) f[std::size_t(i)] = float(m[std::size_t(i / 3)][std::size_t(i % 3)]);
    return f;
}

// Absolute nits in the target's primaries -> the value the swapchain takes.
float encode(const DisplayTarget& t, float nits) noexcept {
    return t.path == OutputPath::Hdr10 ? pq_oetf(nits) : nits / float(t.unit_nits);
}

}  // namespace

int false_colour_zone(float nits) noexcept {
    for (int i = 0; i < int(kZoneBelow.size()); ++i)
        if (nits < kZoneBelow[std::size_t(i)]) return i;
    return int(kZoneBelow.size());   // NaN lands here too, as in the shader
}

std::array<float, 3> false_colour(int zone) noexcept {
    return kZoneColour[std::size_t(std::clamp(zone, 0, int(kZoneColour.size()) - 1))];
}

float linear_to_srgb(float x) noexcept {
    x = std::clamp(x, 0.0f, 1.0f);
    return x > 0.0031308f ? 1.055f * std::pow(x, 1.0f / 2.4f) - 0.055f : 12.92f * x;
}

std::array<float, 3> range_colour(float stops) noexcept {
    if (!(stops >= -6.0f)) return {0.08f, 0.08f, 0.10f};   // NaN and -inf (black) land here
    if (stops < 0.0f) {
        const float g = 0.15f + 0.45f * (stops + 6.0f) / 6.0f;
        return {g, g, g};
    }
    if (stops < 1.0f) return {0.20f, 0.55f, 0.85f};
    if (stops < 2.0f) return {0.25f, 0.75f, 0.45f};
    if (stops < 3.0f) return {0.95f, 0.85f, 0.25f};
    if (stops < 4.0f) return {0.95f, 0.55f, 0.20f};
    return {0.90f, 0.25f, 0.25f};
}

std::vector<float> sdr_light_rgba(const SdrImage* sdr, std::span<const float> target_knots) {
    if (!sdr) return {};
    const PlanarBuffer& c = sdr->buffer();
    const std::size_t n = c.plane_size();
    std::vector<float> out(n * 4);
    const float white = kSdrWhiteNits / kPeak;   // network units of the code's white
    for (std::size_t i = 0; i < n; ++i) {
        int flags = 0;
        float mx = 0.0f;
        for (int k = 0; k < 3; ++k) {
            const float v = c.plane(k)[i];
            float light = srgb_to_linear(v);
            if (!target_knots.empty()) light *= std::exp2(anchor_target_log2(v, target_knots));
            out[i * 4 + std::size_t(k)] = light * white;
            if (v >= kSdrClipCode) flags |= (1 << k);
            mx = std::max(mx, v);
        }
        if (mx <= kSdrCrushCode) flags |= kFlagCrush;
        out[i * 4 + 3] = float(flags);
    }
    return out;
}

std::vector<float> sdr_max_codes(const SdrImage* sdr, int width, int height) {
    const std::size_t n = std::size_t(width) * std::size_t(height);
    std::vector<float> out(n, 0.5f);
    if (!sdr || sdr->width() != width || sdr->height() != height) return out;
    const PlanarBuffer& c = sdr->buffer();
    for (std::size_t i = 0; i < n; ++i) out[i] = std::max(std::max(c.plane(0)[i], c.plane(1)[i]), c.plane(2)[i]);
    return out;
}

namespace {
// core/master.cpp srgb_to_linear_d: the anchor's own decode, in double.
double srgb_to_linear_dbl(double c) noexcept {
    c = std::clamp(c, 0.0, 1.0);
    return c > 0.04045 ? std::pow((c + 0.055) / 1.055, 2.4) : c / 12.92;
}
}  // namespace

double anchor_hold(const NetworkLinearImage& model, const SdrImage& sdr, double knee, double softness,
                   const std::vector<float>* grade_gain, std::span<const float> target_knots) {
    // anchor_to_sdr's hold, on the composite in network units (x 10 000 = nits).
    const std::size_t n = model.buffer().plane_size();
    const PlanarBuffer& m = model.buffer();
    const PlanarBuffer& s = sdr.buffer();
    constexpr double eps = 1e-4, luma[3] = {0.2627, 0.6780, 0.0593};
    std::vector<double> want, band;
    want.reserve(n);
    for (std::size_t i = 0; i < n; ++i) {
        double target = 0.0, actual = 0.0, mx = -1.0;
        for (int c = 0; c < 3; ++c) {
            const double v = s.plane(c)[i];
            double light = srgb_to_linear_dbl(v);
            if (!target_knots.empty()) light *= std::exp2(double(anchor_target_log2(float(v), target_knots)));
            target += light * luma[c];
            actual += double(m.plane(c)[i]) * 10000.0 * luma[c];
            mx = std::max(mx, v);
        }
        target *= 203.0;
        if (grade_gain && i < grade_gain->size()) target *= double((*grade_gain)[i]);
        const double g = (target + eps) / (actual + eps);
        want.push_back(g);
        if (mx > knee - softness && mx < knee + softness && actual > 1e-9) band.push_back(g);
    }
    auto median = [](std::vector<double> v) {
        if (v.empty()) return 1.0;
        const std::size_t mid = v.size() / 2;
        std::nth_element(v.begin(), v.begin() + std::ptrdiff_t(mid), v.end());
        double hi = v[mid];
        if (v.size() % 2 == 0) {
            const double lo = *std::max_element(v.begin(), v.begin() + std::ptrdiff_t(mid));
            return (lo + hi) * 0.5;
        }
        return hi;
    };
    const double hold = band.size() >= 64 ? median(std::move(band)) : median(std::move(want));
    return std::isfinite(hold) ? hold : 1.0;
}

float anchor_gain_f(float target_luma, float r, float g, float b, float max_code, float knee, float softness,
                    float hold) noexcept {
    const float eps = 1e-4f;
    const float target = target_luma * 203.0f;
    const float actual = (0.2627f * r + 0.6780f * g + 0.0593f * b) * kPeak;
    float gain = (target + eps) / (actual + eps);
    const float t = std::clamp((max_code - (knee - softness)) / (2.0f * softness), 0.0f, 1.0f);
    const float ramp = t * t * (3.0f - 2.0f * t);
    gain = gain * (1.0f - ramp) + hold * ramp;
    return std::isfinite(gain) ? gain : 1.0f;
}

PlanarBuffer render_view(const NetworkLinearImage& model, const NetworkLinearImage& baseline,
                         const ViewParams& p, const SdrImage* sdr) {
    assert(model.width() == baseline.width() && model.height() == baseline.height());
    const int w = model.width(), h = model.height();
    const PlanarBuffer& m = model.buffer();
    const PlanarBuffer& b = baseline.buffer();
    const bool wiping = p.wipe >= 0.0;
    const bool painting = p.paint_band >= 0 && p.masks && p.masks->has(p.paint_band);
    // RUDRA 1.1: the region overlay, from the same 8-bit weights the GPU pass samples.
    const std::vector<std::uint8_t> region_w = p.region_overlay && p.overlay_region.enabled
                                                   ? region_overlay_rgba8(sdr, p.overlay_region, w, h, p.overlay_gate)
                                                   : std::vector<std::uint8_t>{};
    // Revision 6: the Sdr source (the plate as light) and the wipe's A | B.
    const bool have_sdr = sdr && sdr->width() == w && sdr->height() == h;
    const bool needs_light = view_needs_sdr_light(p);
    const std::vector<float> light = (needs_light && have_sdr) ? sdr_light_rgba(sdr, p.anchor_knots) : std::vector<float>{};
    PlanarBuffer sdr_pic;
    if (!light.empty()) {
        sdr_pic = PlanarBuffer(3, h, w);
        for (std::size_t i = 0; i < sdr_pic.plane_size(); ++i)
            for (int k = 0; k < 3; ++k) sdr_pic.plane(k)[i] = light[i * 4 + std::size_t(k)];
    }
    // Without an SDR the Sdr source falls back to the baseline (the app disables it).
    auto pick = [&](ViewSource s) -> const PlanarBuffer& {
        return s == ViewSource::Model ? m : (s == ViewSource::Sdr && !light.empty()) ? sdr_pic : b;
    };
    const PlanarBuffer& source = wiping ? m : pick(p.show);
    const PlanarBuffer& left_pic = pick(p.wipe_left);
    const PlanarBuffer& right_pic = pick(p.wipe_right);
    const float view_gain = float(std::exp2(p.view_ev));
    const bool gamma_on = p.view_gamma != 1.0;
    const float inv_gamma = float(1.0 / std::clamp(p.view_gamma, 0.2, 5.0));
    // Uniforms reach the shader as fp32.
    const float scale = float(double(kPeak) / std::max(p.display_nits, 1e-3));
    const float wipe = wiping ? float(std::clamp(p.wipe, 0.0, 1.0)) : -1.0f;
    const float half_width = float(p.wipe_half_width);
    const float log_gain = std::log2(1.0f + float(std::max(p.diff_gain, 1.0)));

    const bool hdr = p.target.path != OutputPath::SdrPqSimulation;
    // HDR paths: the picture in absolute nits, clipped at the lower of the view
    // peak and the display's peak, never tone-mapped (ADR-005); overlays (false
    // colour, difference, the wipe handle) are graphics at the SDR white.
    const float ceiling = float(std::min(p.display_nits, p.target.peak_nits));
    const Mat3f picture_m = to_float(rgb_to_rgb_matrix(p.source, p.target.primaries));
    const Mat3f graphics_m = to_float(rgb_to_rgb_matrix(Primaries::Rec709, p.target.primaries));
    const float graphics_white = float(kDiffuseWhite.v);
    const bool anchoring = p.anchor && sdr != nullptr;
    const std::vector<float> codes =
        (p.mode == ViewMode::Invented || anchoring) ? sdr_max_codes(sdr, w, h) : std::vector<float>{};
    const float knee = float(p.anchor_knee), softness = float(p.anchor_softness), hold = float(p.anchor_hold);
    const PlanarBuffer* sdr_buf = anchoring ? &sdr->buffer() : nullptr;

    PlanarBuffer out(3, h, w);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            const float u = (float(x) + 0.5f) / float(w);
            const PlanarBuffer& pic = wiping ? (u < wipe ? left_pic : right_pic) : source;
            const std::size_t pix = std::size_t(y) * std::size_t(w) + std::size_t(x);
            const int flags = light.empty() ? 0 : int(light[pix * 4 + 3]);
            float hr = pic.at(0, y, x), hg = pic.at(1, y, x), hb = pic.at(2, y, x);
            // The anchor (3.3) on the model's picture only: the baseline is the
            // inverse as it is, on its own or on the wipe's left.
            if (anchoring && &pic == &m) {
                const std::size_t i = std::size_t(y) * std::size_t(w) + std::size_t(x);
                float target = 0.0f;
                for (int k = 0; k < 3; ++k) {
                    const float v = sdr_buf->plane(k)[i];
                    float light = srgb_to_linear(v);
                    if (!p.anchor_knots.empty()) light *= std::exp2(anchor_target_log2(v, p.anchor_knots));
                    target += kRec2020Luma[std::size_t(k)] * light;
                }
                if (p.grade_gain && i < p.grade_gain->size()) target *= (*p.grade_gain)[i];
                const float gain = anchor_gain_f(target, hr, hg, hb, codes[i], knee, softness, hold);
                hr *= gain, hg *= gain, hb *= gain;
            }
            float c[3];
            bool screen_clip = false;
            switch (p.mode) {
                case ViewMode::FalseColour: {
                    const auto fc = false_colour(false_colour_zone(lum2020(hr, hg, hb) * kPeak));
                    c[0] = fc[0], c[1] = fc[1], c[2] = fc[2];
                    break;
                }
                case ViewMode::Difference: {
                    const float d = lum2020(std::abs(source.at(0, y, x) - b.at(0, y, x)),
                                            std::abs(source.at(1, y, x) - b.at(1, y, x)),
                                            std::abs(source.at(2, y, x) - b.at(2, y, x)));
                    const float v = std::clamp(std::log2(1.0f + d * kPeak) / log_gain, 0.0f, 1.0f);
                    c[0] = v * 0.95f, c[1] = v * 0.62f, c[2] = v * 0.28f;
                    break;
                }
                case ViewMode::Invented: {
                    const float g = kMapGrey * linear_to_srgb(lum2020(hr, hg, hb) * scale);
                    const float mn = std::max(std::max(m.at(0, y, x), m.at(1, y, x)), m.at(2, y, x)) * kPeak;
                    const float bn = std::max(std::max(b.at(0, y, x), b.at(1, y, x)), b.at(2, y, x)) * kPeak;
                    const float a = kMapMix * std::abs(change_weight(mn, bn));
                    const auto& col = sdr_has_no_information(codes[std::size_t(y) * std::size_t(w) + std::size_t(x)])
                                          ? kInventedColour : kReinterpretedColour;
                    for (int k = 0; k < 3; ++k) c[k] = g * (1.0f - a) + col[std::size_t(k)] * a;
                    break;
                }
                case ViewMode::Range: {
                    const float mx = std::max(std::max(hr, hg), hb) * kPeak;
                    const auto rc = range_colour(std::log2(mx / kSdrWhiteNits));
                    c[0] = rc[0], c[1] = rc[1], c[2] = rc[2];
                    if ((flags & (kFlagClipR | kFlagClipG | kFlagClipB)) && ((x + y) & (kZebraPeriod - 1)) == 0)
                        for (float& v : c) v = v * (1.0f - kRangeHatchMix) + kRangeHatchMix;
                    break;
                }
                case ViewMode::Image:
                default: {
                    // Revision 6: the viewer exposure, then the viewer gamma
                    // pivoting on the view peak, then the clip.
                    const float hv[3] = {hr * view_gain, hg * view_gain, hb * view_gain};
                    for (int k = 0; k < 3; ++k) {
                        float v = hdr ? hv[k] * kPeak : hv[k] * scale;
                        if (gamma_on) {
                            const float pivot = hdr ? ceiling : 1.0f;
                            const float a = std::abs(v) / pivot;
                            v = std::copysign(pivot * std::pow(a, inv_gamma), v);
                        }
                        if (hdr) {
                            screen_clip = screen_clip || v >= ceiling;
                            c[k] = std::clamp(v, 0.0f, ceiling);
                        } else {
                            screen_clip = screen_clip || v >= 1.0f;
                            c[k] = linear_to_srgb(v);
                        }
                    }
                    break;
                }
            }
            if (p.show_changes && p.mode == ViewMode::Image) {
                // Model against baseline at this pixel, whichever side is shown.
                const float mn = std::max(std::max(m.at(0, y, x), m.at(1, y, x)), m.at(2, y, x)) * kPeak;
                const float bn = std::max(std::max(b.at(0, y, x), b.at(1, y, x)), b.at(2, y, x)) * kPeak;
                const float cw = change_weight(mn, bn);
                if (cw != 0.0f) {
                    const auto& col = cw > 0.0f ? kChangeUp : kChangeDown;
                    const float a = kChangeTintMix * std::abs(cw);
                    for (int k = 0; k < 3; ++k) {
                        const float t = hdr ? graphics_white * srgb_to_linear(col[std::size_t(k)]) : col[std::size_t(k)];
                        c[k] = c[k] * (1.0f - a) + t * a;
                    }
                }
            }
            if (painting && p.mode == ViewMode::Image) {
                // The mask being painted (3.3), tinted over whichever side is shown.
                const float a = kMaskTintMix * p.masks->weight(p.paint_band, x, y, w, h);
                if (a > 0.0f)
                    for (int k = 0; k < 3; ++k) {
                        const float t = hdr ? graphics_white * srgb_to_linear(p.paint_tint[std::size_t(k)]) : p.paint_tint[std::size_t(k)];
                        c[k] = c[k] * (1.0f - a) + t * a;
                    }
            }
            if (!region_w.empty() && p.mode == ViewMode::Image) {
                const std::size_t ri = (std::size_t(y) * std::size_t(w) + std::size_t(x)) * 4;
                const float a = kRegionTintMix * (float(region_w[ri]) / 255.0f);
                const auto& tint = region_w[ri + 1] > 127 ? p.region_shadow_tint : p.region_tint;   // shadows blue, highlights warm
                if (a > 0.0f)
                    for (int k = 0; k < 3; ++k) {
                        const float t = hdr ? graphics_white * srgb_to_linear(tint[std::size_t(k)]) : tint[std::size_t(k)];
                        c[k] = c[k] * (1.0f - a) + t * a;
                    }
            }
            if (p.mode == ViewMode::Image && (p.clamp_zebra || p.clip_zebra)) {
                // Revision 6 overlays, in frame pixels: the source's clamp on one
                // diagonal, the screen's clip on the other.
                auto mix_in = [&](const std::array<float, 3>& col) {
                    for (int k = 0; k < 3; ++k) {
                        const float t = hdr ? graphics_white * srgb_to_linear(col[std::size_t(k)]) : col[std::size_t(k)];
                        c[k] = c[k] * (1.0f - kZebraMix) + t * kZebraMix;
                    }
                };
                const int d1 = (x + y) & (kZebraPeriod - 1), d2 = (x - y) & (kZebraPeriod - 1);
                if (p.clamp_zebra) {
                    const int clip = flags & (kFlagClipR | kFlagClipG | kFlagClipB);
                    if (clip == (kFlagClipR | kFlagClipG | kFlagClipB)) {
                        if (d1 < 3) mix_in(kClampAllColour);
                    } else if (clip != 0) {
                        if (d1 < 1) mix_in(kClampSomeColour);
                    } else if ((flags & kFlagCrush) && d1 < 3) {
                        mix_in(kCrushColour);
                    }
                }
                if (p.clip_zebra && screen_clip && d2 < 2) mix_in(kScreenClipColour);
            }
            const bool handle = wiping && std::abs(u - wipe) < half_width;
            if (!hdr) {
                if (handle)
                    for (float& v : c) v = 1.0f - v;
                for (int k = 0; k < 3; ++k) out.at(k, y, x) = c[k];
                continue;
            }
            // HDR: c is nits in the source primaries (image) or an SDR code (graphics).
            const bool picture = p.mode == ViewMode::Image;
            float n[3];
            for (int k = 0; k < 3; ++k) {
                if (picture) n[k] = handle ? ceiling - c[k] : c[k];
                else n[k] = graphics_white * srgb_to_linear(handle ? 1.0f - c[k] : c[k]);
            }
            const Mat3f& m3 = picture ? picture_m : graphics_m;
            for (int k = 0; k < 3; ++k) {
                const float v = m3[std::size_t(k) * 3] * n[0] + m3[std::size_t(k) * 3 + 1] * n[1] + m3[std::size_t(k) * 3 + 2] * n[2];
                out.at(k, y, x) = encode(p.target, v);
            }
        }
    }
    return out;
}

Rgb8Image render_view_rgb8(const NetworkLinearImage& model, const NetworkLinearImage& baseline,
                           const ViewParams& p, const SdrImage* sdr) {
    const PlanarBuffer f = render_view(model, baseline, p, sdr);
    Rgb8Image out{f.width(), f.height(), std::vector<std::uint8_t>(f.plane_size() * 3)};
    const std::size_t n = f.plane_size();
    for (std::size_t i = 0; i < n; ++i)
        for (int k = 0; k < 3; ++k) {
            const float v = std::clamp(f.plane(k)[i], 0.0f, 1.0f);
            out.rgb[i * 3 + std::size_t(k)] = std::uint8_t(std::lround(v * 255.0f));
        }
    return out;
}

Reductions reduce_ladder(const PlanarBuffer& rgb) {
    int w = rgb.width(), h = rgb.height();
    std::vector<float> mx(std::size_t(w) * h), sm;
    for (std::size_t i = 0; i < mx.size(); ++i)
        mx[i] = std::max(std::max(rgb.plane(0)[i], rgb.plane(1)[i]), rgb.plane(2)[i]);
    sm = mx;
    while (w > 1 || h > 1) {
        const int dw = std::max(1, (w + 1) / 2), dh = std::max(1, (h + 1) / 2);
        std::vector<float> nm(std::size_t(dw) * dh), ns(std::size_t(dw) * dh);
        for (int y = 0; y < dh; ++y)
            for (int x = 0; x < dw; ++x) {
                float am = -1e30f, as = 0.0f;
                for (int j = 0; j < 2; ++j)
                    for (int i = 0; i < 2; ++i) {
                        const int px = 2 * x + i, py = 2 * y + j;
                        if (px >= w || py >= h) continue;
                        const std::size_t k = std::size_t(py) * w + px;
                        am = std::max(am, mx[k]);
                        as = as + sm[k];
                    }
                nm[std::size_t(y) * dw + x] = am;
                ns[std::size_t(y) * dw + x] = as;
            }
        mx.swap(nm);
        sm.swap(ns);
        w = dw;
        h = dh;
    }
    return {mx[0], sm[0]};
}

Probe probe_pixel(const NetworkLinearImage& model, const NetworkLinearImage& baseline, double x, double y) {
    const int w = model.width(), h = model.height();
    // Math.round: half up.
    const int px = std::clamp(int(std::floor(x + 0.5)), 0, w - 1);
    const int py = std::clamp(int(std::floor(y + 0.5)), 0, h - 1);
    auto one = [&](const NetworkLinearImage& img) {
        ProbeSample s;
        s.x = px;
        s.y = py;
        const float r = img.buffer().at(0, py, px), g = img.buffer().at(1, py, px), b = img.buffer().at(2, py, px);
        s.rgb_nits[0] = double(r) * 10000.0;
        s.rgb_nits[1] = double(g) * 10000.0;
        s.rgb_nits[2] = double(b) * 10000.0;
        s.nits = (double(r) * 0.2627 + double(g) * 0.6780 + double(b) * 0.0593) * 10000.0;
        return s;
    };
    return {one(model), one(baseline)};
}

// ---- RUDRA 1.1 priority 4 (5 Nov 2026) --------------------------------------

Rgb8Image exposure_bracket(const NetworkLinearImage& picture, double ev, Primaries source) {
    ViewParams v = view_params(ViewMode::Image, 203.0);
    v.view_ev = ev;
    v.source = source;
    return render_view_rgb8(picture, picture, v);
}

CodeDelta code_delta(const Rgb8Image& a, const Rgb8Image& b) {
    if (a.width != b.width || a.height != b.height || a.rgb.size() != b.rgb.size()) return {256, 1.0};
    CodeDelta d;
    std::size_t differing = 0;
    const std::size_t n = std::size_t(a.width) * std::size_t(a.height);
    for (std::size_t i = 0; i < n; ++i) {
        int worst = 0;
        for (int c = 0; c < 3; ++c) worst = std::max(worst, std::abs(int(a.rgb[i * 3 + c]) - int(b.rgb[i * 3 + c])));
        d.max_code_delta = std::max(d.max_code_delta, worst);
        differing += worst > 0;
    }
    d.pixels_differing = n ? double(differing) / double(n) : 0.0;
    return d;
}

std::string display_signal_text(const DisplayTarget& t, double view_peak_nits) {
    auto nits = [](double v) {
        char b[32];
        std::snprintf(b, sizeof b, "%.0f", v);
        std::string s = b;
        for (int i = int(s.size()) - 3; i > 0; i -= 3) s.insert(std::size_t(i), ",");
        return s + " nits";
    };
    auto prim = [](Primaries p) {
        switch (p) {
            case Primaries::Rec709: return "Rec.709";
            case Primaries::Rec2020: return "Rec.2020";
            case Primaries::P3D65: return "P3-D65";
            default: return "wide gamut";
        }
    };
    const std::string white = "reference white " + nits(kDiffuseWhite.v);
    switch (t.path) {
        case OutputPath::ScRgb:
            return std::string("HDR \u00b7 scRGB linear (1.0 = 80 nits) \u00b7 ") + prim(t.primaries) + " \u00b7 " + white +
                   " \u00b7 display peak " + nits(t.peak_nits);
        case OutputPath::Hdr10:
            return std::string("HDR10 \u00b7 PQ (ST 2084) \u00b7 ") + prim(t.primaries) + " \u00b7 " + white +
                   " \u00b7 display peak " + nits(t.peak_nits);
        case OutputPath::Edr:
            return std::string("EDR \u00b7 linear (1.0 = 203 nits) \u00b7 ") + prim(t.primaries) + " \u00b7 " + white +
                   " \u00b7 display peak " + nits(t.peak_nits);
        case OutputPath::SdrPqSimulation:
        default:
            return std::string("SDR \u00b7 sRGB \u00b7 Rec.709 \u00b7 HDR simulated: ") + nits(view_peak_nits) +
                   " shown as SDR white";
    }
}

// ---- RUDRA 1.1: the region overlay and histogram ------------------------------------

namespace {
// The overlay's weight at SDR luma y: the region's own, or the analytic composite's gate.
class OverlayWeight {
public:
    OverlayWeight(const ReconstructionRegion& r, const RegionOverlayGate& g) : r_(r), g_(g) {
        p_.mode = g.mode;
        p_.strength = g.strength;
        p_.region = r;
    }
    float operator()(float y) const {
        if (g_.analytic) return std::clamp(reconstruction_gate(y, g_.shadow_weight, p_), 0.0f, 1.0f);
        float wh = 0.0f, ws = 0.0f;
        region_weights(y, r_, wh, ws);
        return std::clamp(std::max(wh, ws), 0.0f, 1.0f);
    }
    // Which side of the region acts at this luma (8 Nov 2026): the gate's shadows are below 0.5;
    // the region's own, where its shadow weight is the larger.
    bool shadow(float y) const {
        if (g_.analytic) return y < 0.5f;
        float wh = 0.0f, ws = 0.0f;
        region_weights(y, r_, wh, ws);
        return ws > wh;
    }
    static float luma(const PlanarBuffer& s, std::size_t i) {
        auto code = [&](int c) { return std::clamp(s.plane(c)[i], 0.0f, 1.0f); };
        return 0.2126f * code(0) + 0.7152f * code(1) + 0.0722f * code(2);   // as composite.cpp
    }
    float at(const PlanarBuffer& s, std::size_t i) const { return (*this)(luma(s, i)); }

private:
    ReconstructionRegion r_;
    RegionOverlayGate g_;
    CompositeParams p_;
};
}  // namespace

std::vector<std::uint8_t> region_overlay_rgba8(const SdrImage* sdr, const ReconstructionRegion& region, int width, int height,
                                               const RegionOverlayGate& gate) {
    const std::size_t n = std::size_t(std::max(width, 1)) * std::size_t(std::max(height, 1));
    std::vector<std::uint8_t> out(n * 4, 0);
    if (!region.enabled || !sdr || sdr->width() != width || sdr->height() != height) return out;
    const PlanarBuffer& s = sdr->buffer();
    const OverlayWeight weight(region, gate);
    for (std::size_t i = 0; i < n; ++i) {
        const float y = OverlayWeight::luma(s, i);
        out[i * 4] = std::uint8_t(std::lround(weight(y) * 255.0f));
        out[i * 4 + 1] = weight.shadow(y) ? 255 : 0;
    }
    return out;
}

RegionHistogram region_histogram(const SdrImage& sdr, const ReconstructionRegion& region, int bins, const RegionOverlayGate& gate) {
    bins = std::max(bins, 2);
    RegionHistogram h;
    h.counts.assign(std::size_t(bins), 0.0);
    h.weight.assign(std::size_t(bins), 0.0f);
    const PlanarBuffer& s = sdr.buffer();
    const std::size_t n = std::size_t(sdr.width()) * std::size_t(sdr.height());
    std::size_t reached = 0, strong = 0;
    const OverlayWeight weight(region, gate);
    for (std::size_t i = 0; i < n; ++i) {
        auto code = [&](int c) { return std::clamp(s.plane(c)[i], 0.0f, 1.0f); };
        const float y = 0.2126f * code(0) + 0.7152f * code(1) + 0.0722f * code(2);
        h.counts[std::size_t(std::min(bins - 1, int(y * float(bins))))] += 1.0;
        // as the tint: a pixel is reached when its 8-bit weight is not 0
        const float w = region.enabled || gate.analytic ? weight(y) : 1.0f;
        reached += std::lround(w * 255.0f) > 0;
        strong += w >= 0.5f;
    }
    for (double& c : h.counts) c = n ? c / double(n) : 0.0;
    h.shadow.assign(std::size_t(bins), 0);
    for (int b = 0; b < bins; ++b) {
        const float y = (float(b) + 0.5f) / float(bins);
        h.weight[std::size_t(b)] = region.enabled || gate.analytic ? weight(y) : 1.0f;
        h.shadow[std::size_t(b)] = weight.shadow(y) ? 1 : 0;
    }
    h.reached = n ? double(reached) / double(n) : 0.0;
    h.strong = n ? double(strong) / double(n) : 0.0;
    return h;
}

}  // namespace rudra
