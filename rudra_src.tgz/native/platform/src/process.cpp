#include "rudra/platform/process.hpp"

#include <cstdlib>
#include <cstring>
#include <mutex>
#include <thread>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <cerrno>
#include <csignal>
#include <fcntl.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>
extern char** environ;
#endif

namespace rudra {
namespace fs = std::filesystem;

std::optional<fs::path> find_executable(const std::string& name) {
    if (name.find('/') != std::string::npos || name.find('\\') != std::string::npos) {
        std::error_code ec;
        if (fs::is_regular_file(name, ec)) return fs::path(name);
        return std::nullopt;
    }
    const char* path = std::getenv("PATH");
    if (!path) return std::nullopt;
#ifdef _WIN32
    constexpr char sep = ';';
    // No ".bat": CreateProcessW hands one to cmd.exe, which reads the arguments again as a command line.
    const std::vector<std::string> exts = {".exe", ".com", ""};
#else
    constexpr char sep = ':';
    const std::vector<std::string> exts = {""};
#endif
    std::string p(path);
    std::size_t at = 0;
    while (at <= p.size()) {
        const std::size_t end = std::min(p.find(sep, at), p.size());
        const std::string dir = p.substr(at, end - at);
        at = end + 1;
        if (dir.empty()) continue;
        for (const auto& ext : exts) {
            const fs::path cand = fs::path(dir) / (name + ext);
            std::error_code ec;
            if (!fs::is_regular_file(cand, ec)) continue;
#ifndef _WIN32
            if (::access(cand.c_str(), X_OK) != 0) continue;
#endif
            return cand;
        }
    }
    return std::nullopt;
}

#ifdef _WIN32

namespace {

std::wstring widen(const std::string& s) {
    if (s.empty()) return {};
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), int(s.size()), nullptr, 0);
    std::wstring w(std::size_t(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), int(s.size()), w.data(), n);
    return w;
}

// One argument quoted as CommandLineToArgvW / the MSVC runtime parse it.
void append_quoted(std::wstring& cmd, const std::wstring& arg) {
    if (!arg.empty() && arg.find_first_of(L" \t\n\v\"") == std::wstring::npos) {
        cmd += arg;
        return;
    }
    cmd += L'"';
    for (auto it = arg.begin();; ++it) {
        std::size_t backslashes = 0;
        while (it != arg.end() && *it == L'\\') {
            ++it;
            ++backslashes;
        }
        if (it == arg.end()) {
            cmd.append(backslashes * 2, L'\\');
            break;
        }
        if (*it == L'"') {
            cmd.append(backslashes * 2 + 1, L'\\');
            cmd += L'"';
        } else {
            cmd.append(backslashes, L'\\');
            cmd += *it;
        }
    }
    cmd += L'"';
}

// The program to start, as a full path (security review, 11 Nov 2026). Given a bare name
// ("ffmpeg"), CreateProcessW searches the application's folder, then the CURRENT folder, then the
// system folders and the PATH: a project folder holding its own ffmpeg.exe had it run. The name is
// resolved here instead, on the PATH (where the package puts its ffmpeg\ first) and then beside
// this program; when it is nowhere, the path beside this program is still what is passed, so the
// start fails rather than falling back to the current folder.
std::wstring program_path(const std::string& name) {
    if (name.find('/') != std::string::npos || name.find('\\') != std::string::npos) return widen(name);
    if (auto found = find_executable(name)) return found->wstring();
    std::wstring self(32768, L'\0');
    const DWORD n = GetModuleFileNameW(nullptr, self.data(), DWORD(self.size()));
    if (n == 0 || n >= self.size()) return widen(name);
    self.resize(n);
    fs::path beside = fs::path(self).parent_path() / fs::path(widen(name));
    if (!beside.has_extension()) beside += L".exe";
    return beside.wstring();
}

std::wstring command_line(const std::vector<std::string>& argv) {
    std::wstring cmd;
    for (std::size_t i = 0; i < argv.size(); ++i) {
        if (i) cmd += L' ';
        append_quoted(cmd, i == 0 ? program_path(argv[i]) : widen(argv[i]));
    }
    return cmd;
}

std::string drain(HANDLE h) {
    std::string out;
    char buf[65536];
    DWORD n = 0;
    while (ReadFile(h, buf, sizeof buf, &n, nullptr) && n > 0) out.append(buf, n);
    return out;
}

}  // namespace

struct Process::Impl {
    PROCESS_INFORMATION pi{};
    HANDLE out = nullptr;
    HANDLE in = nullptr;
    bool done = false;
    int code = -1;
};

Result<std::unique_ptr<Process>> Process::start_writer(const std::vector<std::string>& argv, const fs::path& stderr_file) {
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 1 << 20)) return make_error(ErrorCode::IoError, "Could not create a pipe.");
    SetHandleInformation(wr, HANDLE_FLAG_INHERIT, 0);
    HANDLE err = !stderr_file.empty()
                     ? CreateFileW(stderr_file.wstring().c_str(), GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS,
                                   FILE_ATTRIBUTE_NORMAL, nullptr)
                     : CreateFileW(L"NUL", GENERIC_WRITE, FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, nullptr);
    HANDLE out = CreateFileW(L"NUL", GENERIC_WRITE, FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, nullptr);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = rd;
    si.hStdOutput = out;
    si.hStdError = err;
    std::wstring cmd = command_line(argv);
    auto impl = std::make_unique<Impl>();
    const BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si,
                                   &impl->pi);
    CloseHandle(rd);
    if (err != INVALID_HANDLE_VALUE) CloseHandle(err);
    if (out != INVALID_HANDLE_VALUE) CloseHandle(out);
    if (!ok) {
        CloseHandle(wr);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0]);
    }
    impl->in = wr;
    std::unique_ptr<Process> p(new Process());
    p->d_ = std::move(impl);
    return p;
}

bool Process::write(std::span<const std::uint8_t> data) {
    if (!d_->in) return false;
    std::size_t put = 0;
    while (put < data.size()) {
        DWORD n = 0;
        if (!WriteFile(d_->in, data.data() + put, DWORD(std::min<std::size_t>(data.size() - put, 1u << 30)), &n, nullptr))
            return false;
        put += n;
    }
    return true;
}

void Process::close_input() {
    if (d_->in) CloseHandle(d_->in);
    d_->in = nullptr;
}

Result<std::unique_ptr<Process>> Process::start(const std::vector<std::string>& argv, const fs::path& stderr_file) {
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 1 << 20)) return make_error(ErrorCode::IoError, "Could not create a pipe.");
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
    HANDLE err = INVALID_HANDLE_VALUE;
    if (!stderr_file.empty())
        err = CreateFileW(stderr_file.wstring().c_str(), GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS,
                          FILE_ATTRIBUTE_NORMAL, nullptr);
    else
        err = CreateFileW(L"NUL", GENERIC_WRITE, FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, nullptr);
    HANDLE in = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ, &sa, OPEN_EXISTING, 0, nullptr);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = in;
    si.hStdOutput = wr;
    si.hStdError = err;
    std::wstring cmd = command_line(argv);
    auto impl = std::make_unique<Impl>();
    const BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si,
                                   &impl->pi);
    CloseHandle(wr);
    if (err != INVALID_HANDLE_VALUE) CloseHandle(err);
    if (in != INVALID_HANDLE_VALUE) CloseHandle(in);
    if (!ok) {
        CloseHandle(rd);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0]);
    }
    impl->out = rd;
    std::unique_ptr<Process> p(new Process());
    p->d_ = std::move(impl);
    return p;
}

std::size_t Process::read(std::span<std::uint8_t> out) {
    std::size_t got = 0;
    while (got < out.size()) {
        DWORD n = 0;
        if (!ReadFile(d_->out, out.data() + got, DWORD(std::min<std::size_t>(out.size() - got, 1u << 30)), &n, nullptr) ||
            n == 0)
            break;
        got += n;
    }
    return got;
}

int Process::wait() {
    if (!d_->done) {
        WaitForSingleObject(d_->pi.hProcess, INFINITE);
        DWORD code = 0;
        GetExitCodeProcess(d_->pi.hProcess, &code);
        d_->code = int(code);
        d_->done = true;
    }
    return d_->code;
}

void Process::kill() {
    if (running()) TerminateProcess(d_->pi.hProcess, 1);
}

bool Process::running() const {
    return !d_->done && WaitForSingleObject(d_->pi.hProcess, 0) == WAIT_TIMEOUT;
}

Process::~Process() {
    if (!d_) return;
    if (running()) kill();
    wait();
    if (d_->out) CloseHandle(d_->out);
    if (d_->in) CloseHandle(d_->in);
    CloseHandle(d_->pi.hThread);
    CloseHandle(d_->pi.hProcess);
}

Result<ProcessOutput> run_process(const std::vector<std::string>& argv, rudra::stop_token stop) {
    if (stop.stop_requested()) return make_error(ErrorCode::Cancelled, "Program was cancelled");
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE ord = nullptr, owr = nullptr, erd = nullptr, ewr = nullptr;
    if (!CreatePipe(&ord, &owr, &sa, 0) || !CreatePipe(&erd, &ewr, &sa, 0))
        return make_error(ErrorCode::IoError, "Could not create a pipe.");
    SetHandleInformation(ord, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(erd, HANDLE_FLAG_INHERIT, 0);
    HANDLE in = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ, &sa, OPEN_EXISTING, 0, nullptr);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = in;
    si.hStdOutput = owr;
    si.hStdError = ewr;
    std::wstring cmd = command_line(argv);
    PROCESS_INFORMATION pi{};
    const BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(owr);
    CloseHandle(ewr);
    if (in != INVALID_HANDLE_VALUE) CloseHandle(in);
    if (!ok) {
        CloseHandle(ord);
        CloseHandle(erd);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0]);
    }
    ProcessOutput r;
    {
        // The handle stays valid until the callback has finished. Killing the
        // leaf child unblocks both pipe readers and the final exit wait.
        rudra::stop_callback interrupt(stop, [&] { TerminateProcess(pi.hProcess, 1); });
        std::thread t([&] { r.err = drain(erd); });
        r.out = drain(ord);
        t.join();
        WaitForSingleObject(pi.hProcess, INFINITE);
    }
    DWORD code = 0;
    GetExitCodeProcess(pi.hProcess, &code);
    r.exit_code = int(code);
    CloseHandle(ord);
    CloseHandle(erd);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    if (stop.stop_requested()) return make_error(ErrorCode::Cancelled, "Program was cancelled");
    return r;
}

#else  // POSIX

namespace {

std::vector<char*> c_argv(const std::vector<std::string>& argv) {
    std::vector<char*> v;
    for (const auto& a : argv) v.push_back(const_cast<char*>(a.c_str()));
    v.push_back(nullptr);
    return v;
}

std::string drain(int fd) {
    std::string out;
    char buf[65536];
    for (;;) {
        const ssize_t n = ::read(fd, buf, sizeof buf);
        if (n > 0) out.append(buf, std::size_t(n));
        else if (n < 0 && errno == EINTR) continue;
        else break;
    }
    return out;
}

int exit_code_of(int status) {
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return -1;
}

}  // namespace

struct Process::Impl {
    pid_t pid = -1;
    int out = -1;
    int in = -1;
    bool done = false;
    int code = -1;
};

Result<std::unique_ptr<Process>> Process::start_writer(const std::vector<std::string>& argv, const fs::path& stderr_file) {
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    // A reader that quits early must give this side EPIPE, not kill it
    // (the Python's BrokenPipeError).
    std::signal(SIGPIPE, SIG_IGN);
    int fds[2];
    if (::pipe(fds) != 0) return make_error(ErrorCode::IoError, "Could not create a pipe.");
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addclose(&fa, fds[1]);
    posix_spawn_file_actions_adddup2(&fa, fds[0], 0);
    posix_spawn_file_actions_addclose(&fa, fds[0]);
    posix_spawn_file_actions_addopen(&fa, 1, "/dev/null", O_WRONLY, 0);
    const std::string err = stderr_file.empty() ? std::string("/dev/null") : stderr_file.string();
    posix_spawn_file_actions_addopen(&fa, 2, err.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
    auto args = c_argv(argv);
    pid_t pid = -1;
    const int rc = posix_spawnp(&pid, argv[0].c_str(), &fa, nullptr, args.data(), environ);
    posix_spawn_file_actions_destroy(&fa);
    ::close(fds[0]);
    if (rc != 0) {
        ::close(fds[1]);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0] + ": " + std::strerror(rc));
    }
    ::fcntl(fds[1], F_SETFD, FD_CLOEXEC);
    std::unique_ptr<Process> p(new Process());
    p->d_ = std::make_unique<Impl>();
    p->d_->pid = pid;
    p->d_->in = fds[1];
    return p;
}

bool Process::write(std::span<const std::uint8_t> data) {
    if (d_->in < 0) return false;
    std::size_t put = 0;
    while (put < data.size()) {
        const ssize_t n = ::write(d_->in, data.data() + put, data.size() - put);
        if (n > 0) put += std::size_t(n);
        else if (n < 0 && errno == EINTR) continue;
        else return false;
    }
    return true;
}

void Process::close_input() {
    if (d_->in >= 0) ::close(d_->in);
    d_->in = -1;
}

Result<std::unique_ptr<Process>> Process::start(const std::vector<std::string>& argv, const fs::path& stderr_file) {
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    int fds[2];
    if (::pipe(fds) != 0) return make_error(ErrorCode::IoError, "Could not create a pipe.");
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addclose(&fa, fds[0]);
    posix_spawn_file_actions_adddup2(&fa, fds[1], 1);
    posix_spawn_file_actions_addclose(&fa, fds[1]);
    posix_spawn_file_actions_addopen(&fa, 0, "/dev/null", O_RDONLY, 0);
    const std::string err = stderr_file.empty() ? std::string("/dev/null") : stderr_file.string();
    posix_spawn_file_actions_addopen(&fa, 2, err.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
    auto args = c_argv(argv);
    pid_t pid = -1;
    const int rc = posix_spawnp(&pid, argv[0].c_str(), &fa, nullptr, args.data(), environ);
    posix_spawn_file_actions_destroy(&fa);
    ::close(fds[1]);
    if (rc != 0) {
        ::close(fds[0]);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0] + ": " + std::strerror(rc));
    }
    std::unique_ptr<Process> p(new Process());
    p->d_ = std::make_unique<Impl>();
    p->d_->pid = pid;
    p->d_->out = fds[0];
    return p;
}

std::size_t Process::read(std::span<std::uint8_t> out) {
    std::size_t got = 0;
    while (got < out.size()) {
        const ssize_t n = ::read(d_->out, out.data() + got, out.size() - got);
        if (n > 0) got += std::size_t(n);
        else if (n < 0 && errno == EINTR) continue;
        else break;
    }
    return got;
}

int Process::wait() {
    if (!d_->done) {
        int status = 0;
        while (::waitpid(d_->pid, &status, 0) < 0 && errno == EINTR) {
        }
        d_->code = exit_code_of(status);
        d_->done = true;
    }
    return d_->code;
}

void Process::kill() {
    if (!d_->done) ::kill(d_->pid, SIGKILL);
}

bool Process::running() const {
    if (d_->done) return false;
    int status = 0;
    const pid_t r = ::waitpid(d_->pid, &status, WNOHANG);
    if (r == d_->pid) {
        d_->code = exit_code_of(status);
        d_->done = true;
        return false;
    }
    return true;
}

Process::~Process() {
    if (!d_) return;
    if (d_->out >= 0) ::close(d_->out);   // a writer blocked on a full pipe gets SIGPIPE
    if (d_->in >= 0) ::close(d_->in);
    if (!d_->done) {
        kill();
        wait();
    }
}

Result<ProcessOutput> run_process(const std::vector<std::string>& argv, rudra::stop_token stop) {
    if (stop.stop_requested()) return make_error(ErrorCode::Cancelled, "Program was cancelled");
    if (argv.empty()) return make_error(ErrorCode::InvalidArgument, "No program to run.");
    int o[2], e[2];
    if (::pipe(o) != 0) return make_error(ErrorCode::IoError, "Could not create a pipe.");
    if (::pipe(e) != 0) {
        ::close(o[0]);
        ::close(o[1]);
        return make_error(ErrorCode::IoError, "Could not create a pipe.");
    }
    posix_spawn_file_actions_t fa;
    posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addclose(&fa, o[0]);
    posix_spawn_file_actions_addclose(&fa, e[0]);
    posix_spawn_file_actions_adddup2(&fa, o[1], 1);
    posix_spawn_file_actions_adddup2(&fa, e[1], 2);
    posix_spawn_file_actions_addclose(&fa, o[1]);
    posix_spawn_file_actions_addclose(&fa, e[1]);
    posix_spawn_file_actions_addopen(&fa, 0, "/dev/null", O_RDONLY, 0);
    auto args = c_argv(argv);
    pid_t pid = -1;
    const int rc = posix_spawnp(&pid, argv[0].c_str(), &fa, nullptr, args.data(), environ);
    posix_spawn_file_actions_destroy(&fa);
    ::close(o[1]);
    ::close(e[1]);
    if (rc != 0) {
        ::close(o[0]);
        ::close(e[0]);
        return make_error(ErrorCode::NotFound, "Could not start the program.", argv[0] + ": " + std::strerror(rc));
    }
    ProcessOutput r;
    int status = 0;
    {
        // Serialize reaping and cancellation so a reused PID cannot be killed.
        std::mutex lifecycle;
        bool reaped = false, wait_failed = false;
        int wait_errno = 0;
        rudra::stop_callback interrupt(stop, [&] {
            std::lock_guard lock(lifecycle);
            if (!reaped) ::kill(pid, SIGKILL);
        });
        std::thread t([&] { r.err = drain(e[0]); });
        r.out = drain(o[0]);
        t.join();
        ::close(o[0]); ::close(e[0]);
        if (!stop.stop_possible()) {
            for (;;) {
                if (::waitpid(pid, &status, 0) >= 0) break;
                if (errno != EINTR) { wait_failed = true; wait_errno = errno; break; }
            }
        } else for (;;) {
            {
                std::lock_guard lock(lifecycle);
                const auto got = ::waitpid(pid, &status, WNOHANG);
                if (got == pid) { reaped = true; break; }
                // A lost child (ECHILD: SIGCHLD ignored, another reaper) is an
                // error, never a run that exited 0.
                if (got < 0 && errno != EINTR) { reaped = true; wait_failed = true; wait_errno = errno; break; }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        if (wait_failed)
            return make_error(ErrorCode::IoError, "Could not read the program's exit status.",
                              argv[0] + ": " + std::strerror(wait_errno));
    }
    if (stop.stop_requested()) return make_error(ErrorCode::Cancelled, "Program was cancelled");
    r.exit_code = exit_code_of(status);
    return r;
}

#endif

Result<std::filesystem::path> require_executable(const std::string& name) {
    if (auto found = find_executable(name)) return *found;
    return make_error(ErrorCode::NotFound, name + " is required on PATH");
}

Result<std::string> run_tool(const std::vector<std::string>& argv, rudra::stop_token stop) {
    auto r = run_process(argv, stop);
    if (!r) return r.error();
    if (r->exit_code != 0) {
        const std::string& err = r->err;
        const std::string tail = err.size() > 4000 ? err.substr(err.size() - 4000) : err;
        return make_error(ErrorCode::IoError, std::filesystem::path(argv.front()).filename().string() + " failed: " + tail);
    }
    return std::move(r->out);
}

}  // namespace rudra
