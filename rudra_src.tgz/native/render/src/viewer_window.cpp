#include "rudra/render/viewer_window.hpp"
#include "rudra/render/gl_format.hpp"

#include <QDropEvent>
#include <QMimeData>
#include <QUrl>
#include <QExposeEvent>
#include <QGuiApplication>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QOffscreenSurface>
#include <QPlatformSurfaceEvent>
#include <QWheelEvent>
#include <rhi/qrhi.h>

#include "rudra/render/qt_vulkan.hpp"
#if RUDRA_QT_VULKAN
#include <QVulkanInstance>
#endif
#include <QScreen>

#ifdef Q_OS_WIN
#include <dxgi1_6.h>
#endif

#include <algorithm>
#include <cmath>
#include <cstring>
#include <optional>

#include "passes.hpp"
#include "rudra/core/baseline.hpp"
#include "rudra/core/hdr10.hpp"

namespace rudra {
namespace {

using detail::load_shader;

// The Blit block of shaders/blit.vert.
struct BlitUbo {
    float clip_corr[16];
    float rect[4];
    float window[4];   // width, height, y-up, SDR white encoded
    float guides[4];   // action, title, centre, aspect
};
static_assert(sizeof(BlitUbo) == 28 * sizeof(float));

// The surround: neutral grey #121212, a graphic at the SDR white.
constexpr float kSurroundCode = 0x12 / 255.0f;

float code_to_linear(float c) {
    return c > 0.04045f ? std::pow((c + 0.055f) / 1.055f, 2.4f) : c / 12.92f;
}

QSurface::SurfaceType surface_for(GpuApi api) {
    switch (api) {
        case GpuApi::D3D12:
        case GpuApi::D3D11: return QSurface::Direct3DSurface;
        case GpuApi::Metal: return QSurface::MetalSurface;
        case GpuApi::Vulkan: return QSurface::VulkanSurface;
        default: return QSurface::OpenGLSurface;
    }
}

GpuApi resolve(GpuApi api) {
    if (api != GpuApi::Auto) return api;
#if defined(Q_OS_WIN)
    return GpuApi::D3D12;
#elif defined(Q_OS_MACOS)
    return GpuApi::Metal;
#elif RUDRA_QT_VULKAN
    return GpuApi::Vulkan;
#else
    return GpuApi::OpenGL;
#endif
}

const char* swapchain_name(QRhiSwapChain::Format f, bool display_referred) {
    switch (f) {
        case QRhiSwapChain::HDRExtendedSrgbLinear: return display_referred ? "EDR" : "scRGB";
        case QRhiSwapChain::HDR10: return "HDR10";
        case QRhiSwapChain::HDRExtendedDisplayP3Linear: return "EDR";
        default: return "SDR";
    }
}

#ifdef Q_OS_WIN
// The peak Windows reports for the output under `native_geometry`, from DXGI.
// Qt's Vulkan and OpenGL swapchains report placeholder limits (1 000 nits),
// so on Windows the viewer asks the OS directly (as rudra-hdr-probe does).
std::optional<double> dxgi_peak(const QRect& native_geometry) {
    std::optional<double> peak;
    IDXGIFactory1* factory = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), reinterpret_cast<void**>(&factory)))) return peak;
    IDXGIAdapter1* adapter = nullptr;
    for (UINT a = 0; factory->EnumAdapters1(a, &adapter) != DXGI_ERROR_NOT_FOUND; ++a) {
        IDXGIOutput* output = nullptr;
        for (UINT o = 0; adapter->EnumOutputs(o, &output) != DXGI_ERROR_NOT_FOUND; ++o) {
            IDXGIOutput6* output6 = nullptr;
            if (SUCCEEDED(output->QueryInterface(__uuidof(IDXGIOutput6), reinterpret_cast<void**>(&output6)))) {
                DXGI_OUTPUT_DESC1 d{};
                if (SUCCEEDED(output6->GetDesc1(&d))) {
                    const RECT r = d.DesktopCoordinates;
                    if (QRect(r.left, r.top, r.right - r.left, r.bottom - r.top).intersects(native_geometry) && !peak)
                        peak = double(d.MaxLuminance);
                }
                output6->Release();
            }
            output->Release();
        }
        adapter->Release();
    }
    factory->Release();
    return peak;
}
#endif

}  // namespace

struct ViewerWindow::Impl {
    ViewerWindow* w = nullptr;
    GpuApi api = GpuApi::OpenGL;
    bool prefer_hdr = true;

#if RUDRA_QT_VULKAN
    std::unique_ptr<QVulkanInstance> vk;
#endif
    std::unique_ptr<QOffscreenSurface> fallback;
    std::unique_ptr<QRhi> rhi;
    std::unique_ptr<QRhiSwapChain> sc;
    std::unique_ptr<QRhiRenderPassDescriptor> sc_rp;
    QRhiSwapChain::Format format = QRhiSwapChain::SDR;
    bool initialized = false, has_swapchain = false;

    QShader vert, composite_frag, display_frag, blit_vert, blit_frag, hold_frag;
    std::unique_ptr<QRhiSampler> nearest, trilinear, fetch, linear;
    std::unique_ptr<QRhiBuffer> composite_ubo, view_ubo, blit_ubo;

    // Frame-sized resources, rebuilt when the frame size changes.
    QSize frame_size;
    std::unique_ptr<QRhiTexture> in_a, in_b, model_t, base_t, picture, mask_t;
    std::unique_ptr<QRhiTexture> light_t;   // revision 6: the SDR as light and its clamp flags (binding 4)
    std::unique_ptr<QRhiTexture> region_t;  // RUDRA 1.1: the region overlay's weights (binding 5)
    ReconstructionRegion uploaded_region;   // what region_t holds (enabled false: nothing yet)
    RegionOverlayGate uploaded_gate;        // ... and with which gate (7 Nov 2026)
    bool region_dirty = true;
    bool light_dirty = true, light_bound = false;
    std::vector<float> light_knots;         // the anchor knots light_t was made with
    std::shared_ptr<const MaskSet> uploaded_masks;   // what mask_t holds (3.3); null for none
    bool masks_dirty = false;
    std::unique_ptr<QRhiTextureRenderTarget> model_rt, picture_rt;
    std::unique_ptr<QRhiRenderPassDescriptor> model_rp, picture_rp;
    std::unique_ptr<QRhiShaderResourceBindings> composite_srb, display_srb, blit_srb_nearest, blit_srb_trilinear;
    std::unique_ptr<QRhiGraphicsPipeline> composite_pipe, display_pipe, blit_pipe;

    // The static hold while playing (ViewerHold, shaders/hold.frag): made the
    // first time a held frame is shown, at the frame's size. Holding, the
    // composite renders into raw_t and the hold pass writes model_t and the
    // state; the state ping-pongs, hold_rt[k] writing state_t[k] and reading
    // state_t[1 - k].
    std::unique_ptr<QRhiBuffer> hold_ubo;
    std::unique_ptr<QRhiTexture> raw_t, state_t[2];
    std::unique_ptr<QRhiTextureRenderTarget> raw_rt, hold_rt[2];
    std::unique_ptr<QRhiRenderPassDescriptor> raw_rp, hold_rp[2];
    std::unique_ptr<QRhiShaderResourceBindings> hold_srb[2];
    std::unique_ptr<QRhiGraphicsPipeline> raw_pipe, hold_pipe[2];
    bool hold_failed = false;     // the resources could not be made: frames show their own composite
    int hold_last = -1;           // the state texture the last held frame wrote; -1: none to read
    bool hold_pending = true;     // a new held frame: choose its state textures when it is composited
    int hold_write = 0;           // this frame's: the state it writes ...
    bool hold_read = false;       // ... and whether it reads the one before (false: the shot's first frame)
    long long hold_frame = -1;    // ViewerHold::frame of the frame shown

    // What is shown, kept on the host so a lost device is rebuilt from it.
    bool has_frame = false;
    bool precomposited = false;   // set_composited: model_t is uploaded, not rendered
    std::vector<float> pre_codes; // its SDR's largest code per pixel, when given (the Invented layer)
    std::optional<SdrImage> pre_sdr;   // revision 6: its SDR, when given (the Sdr source, zebras, Range)
    NetworkLinearImage precomposite;
    ViewerFrame frame;
    NetworkLinearImage baseline;
    CompositeParams composite;
    ViewParams view;
    ViewportState viewport;
    GuideOptions guides;
    bool upload_dirty = false, composite_dirty = false, view_dirty = true;

    // Interaction.
    bool input = true;
    bool wipe_dragging = false, flip_held_key = false, flip_held_mouse = false;
    bool panning = false;
    QPointF pan_from;
    double pan_x0 = 0, pan_y0 = 0;

    std::string peak_from = "swapchain";   // swapchain, DXGI, or placeholder (unknown)

    std::function<void(const ViewerStatus&)> status_cb;
    std::function<void(const ViewerWindow::Hover&)> hover_cb;
    std::function<void(const QStringList&)> drop_cb;
    std::function<void(double, double)> pick_cb;
    bool pick_mode = false;
    std::function<void(double, double, double, double, bool)> paint_cb;
    std::function<void()> paint_end_cb;
    std::function<void(double)> brush_cb;
    bool paint_mode = false, painting = false;
    double paint_x = 0.0, paint_y = 0.0;
    // The frame pixel under a window position, or nullopt off the picture.
    std::optional<std::pair<double, double>> frame_pixel(const QPointF& at) const {
        const PlacedRect r = placed();
        const ViewSize f = frame_view_size();
        if (!(has_frame && r.width > 0 && r.height > 0 && at.x() >= r.left && at.y() >= r.top &&
              at.x() < r.left + r.width && at.y() < r.top + r.height))
            return std::nullopt;
        return std::pair{(at.x() - r.left) / r.width * f.width, (at.y() - r.top) / r.height * f.height};
    }
    void hover(const QPointF& at, bool alt) {
        if (!hover_cb) return;
        ViewerWindow::Hover h;
        h.window = at;
        h.alt = alt;
        const PlacedRect r = placed();
        const ViewSize f = frame_view_size();
        if (has_frame && r.width > 0 && r.height > 0 && at.x() >= r.left && at.y() >= r.top &&
            at.x() < r.left + r.width && at.y() < r.top + r.height) {
            h.x = (at.x() - r.left) / r.width * f.width;
            h.y = (at.y() - r.top) / r.height * f.height;
        }
        hover_cb(h);
    }
    std::function<void(const Grab&)> grab_cb;
    QRhiReadbackResult grab_rb;
    bool grab_pending = false, grab_y_up = false;
    long long updates = 0, frames = 0, begin_failures = 0;
    int last_begin = 0;

    ViewSize viewer_size() const { return {double(w->width()), double(w->height())}; }
    ViewSize frame_view_size() const {
        return has_frame ? ViewSize{double(baseline.width()), double(baseline.height())} : ViewSize{};
    }
    PlacedRect placed() const { return place(viewport, viewer_size(), frame_view_size()); }

    ViewParams effective_view() const {
        ViewParams v = view;
        v.masks = composite.masks;   // the display pass reads the composite's mask texture (3.3)
        if (flip_held_key || flip_held_mouse) v.show = ViewSource::Baseline;
        if (precomposited) v.anchor = false;   // a card has no SDR behind it to anchor to
        return v;
    }

    bool init() {
        switch (api) {
            case GpuApi::OpenGL: {
                fallback.reset(QRhiGles2InitParams::newFallbackSurface(rhi_gl_format()));
                QRhiGles2InitParams p;
                p.format = rhi_gl_format();
                p.fallbackSurface = fallback.get();
                p.window = w;
                rhi.reset(QRhi::create(QRhi::OpenGLES2, &p));
                break;
            }
            case GpuApi::Vulkan: {
#if RUDRA_QT_VULKAN
                QRhiVulkanInitParams p;
                p.inst = w->vulkanInstance();
                p.window = w;
                rhi.reset(QRhi::create(QRhi::Vulkan, &p));
#endif
                break;
            }
            case GpuApi::D3D11: {
#ifdef Q_OS_WIN
                QRhiD3D11InitParams p;
                rhi.reset(QRhi::create(QRhi::D3D11, &p));
#endif
                break;
            }
            case GpuApi::D3D12: {
#ifdef Q_OS_WIN
                QRhiD3D12InitParams p;
                rhi.reset(QRhi::create(QRhi::D3D12, &p));
#endif
                break;
            }
            case GpuApi::Metal: {
#if QT_CONFIG(metal)
                QRhiMetalInitParams p;
                rhi.reset(QRhi::create(QRhi::Metal, &p));
#endif
                break;
            }
            case GpuApi::Auto: break;
        }
        if (!rhi) return false;
        vert = load_shader(":/rudra/shaders/fullscreen.vert.qsb");
        composite_frag = load_shader(":/rudra/shaders/composite.frag.qsb");
        display_frag = load_shader(":/rudra/shaders/display.frag.qsb");
        blit_vert = load_shader(":/rudra/shaders/blit.vert.qsb");
        blit_frag = load_shader(":/rudra/shaders/blit.frag.qsb");
        hold_frag = load_shader(":/rudra/shaders/hold.frag.qsb");   // optional: no hold without it
        hold_failed = !hold_frag.isValid();
        if (!vert.isValid() || !composite_frag.isValid() || !display_frag.isValid() || !blit_vert.isValid() ||
            !blit_frag.isValid())
            return false;
        fetch.reset(rhi->newSampler(QRhiSampler::Nearest, QRhiSampler::Nearest, QRhiSampler::None,
                                    QRhiSampler::ClampToEdge, QRhiSampler::ClampToEdge));
        nearest.reset(rhi->newSampler(QRhiSampler::Nearest, QRhiSampler::Nearest, QRhiSampler::None,
                                      QRhiSampler::ClampToEdge, QRhiSampler::ClampToEdge));
        trilinear.reset(rhi->newSampler(QRhiSampler::Linear, QRhiSampler::Linear, QRhiSampler::Linear,
                                        QRhiSampler::ClampToEdge, QRhiSampler::ClampToEdge));
        linear.reset(rhi->newSampler(QRhiSampler::Linear, QRhiSampler::Linear, QRhiSampler::None,
                                     QRhiSampler::ClampToEdge, QRhiSampler::ClampToEdge));
        composite_ubo.reset(rhi->newBuffer(QRhiBuffer::Dynamic, QRhiBuffer::UniformBuffer, sizeof(detail::CompositeUbo)));
        view_ubo.reset(rhi->newBuffer(QRhiBuffer::Dynamic, QRhiBuffer::UniformBuffer, sizeof(detail::ViewUbo)));
        blit_ubo.reset(rhi->newBuffer(QRhiBuffer::Dynamic, QRhiBuffer::UniformBuffer, sizeof(BlitUbo)));
        hold_ubo.reset(rhi->newBuffer(QRhiBuffer::Dynamic, QRhiBuffer::UniformBuffer, sizeof(detail::HoldUbo)));
        if (!fetch->create() || !nearest->create() || !trilinear->create() || !linear->create() || !composite_ubo->create() ||
            !view_ubo->create() || !blit_ubo->create() || !hold_ubo->create())
            return false;

        sc.reset(rhi->newSwapChain());
        sc->setWindow(w);
        choose_format();
        sc_rp.reset(sc->newCompatibleRenderPassDescriptor());
        sc->setRenderPassDescriptor(sc_rp.get());
        return build_blit_pipeline();
    }

    void choose_format() {
        // HDR when the display offers it: scRGB (Windows, Linux Vulkan) or
        // EDR (macOS) first, then HDR10, else SDR. The status says which.
        format = QRhiSwapChain::SDR;
        if (prefer_hdr)
            for (auto f : {QRhiSwapChain::HDRExtendedSrgbLinear, QRhiSwapChain::HDRExtendedDisplayP3Linear,
                           QRhiSwapChain::HDR10})
                if (sc->isFormatSupported(f)) {
                    format = f;
                    break;
                }
        sc->setFormat(format);
    }

    void update_target() {
        const QRhiSwapChainHdrInfo info = sc->hdrInfo();
        const bool display_referred = info.luminanceBehavior == QRhiSwapChainHdrInfo::DisplayReferred;
        double nits = info.limitsType == QRhiSwapChainHdrInfo::LuminanceInNits
                          ? double(info.limits.luminanceInNits.maxLuminance)
                          : double(info.limits.colorComponentValue.maxColorComponentValue) * kDiffuseWhite.v;
        peak_from = "swapchain";
        // Qt's placeholder limits (Vulkan, OpenGL): 1 000 / 0 nits, not the display's.
        const bool placeholder = info.limitsType == QRhiSwapChainHdrInfo::LuminanceInNits &&
                                 info.limits.luminanceInNits.maxLuminance == 1000.0f &&
                                 info.limits.luminanceInNits.minLuminance == 0.0f;
        if (placeholder && format != QRhiSwapChain::SDR) {
            peak_from = "placeholder";
#ifdef Q_OS_WIN
            if (const QScreen* scr = w->screen()) {
                const qreal dpr = scr->devicePixelRatio();
                const QRect native(scr->geometry().topLeft() * dpr, scr->geometry().size() * dpr);
                if (auto p = dxgi_peak(native)) {
                    nits = *p;
                    peak_from = "DXGI";
                }
            }
#endif
        }
        DisplayTarget t = DisplayTarget::sdr();
        switch (format) {
            case QRhiSwapChain::HDRExtendedSrgbLinear:
                t = display_referred ? DisplayTarget::edr(nits, Primaries::Rec709) : DisplayTarget::scrgb(nits);
                break;
            case QRhiSwapChain::HDRExtendedDisplayP3Linear: t = DisplayTarget::edr(nits, Primaries::P3D65); break;
            case QRhiSwapChain::HDR10: t = DisplayTarget::hdr10(nits); break;
            default: break;
        }
        if (t.path != view.target.path || t.peak_nits != view.target.peak_nits || t.primaries != view.target.primaries) {
            view.target = t;
            view_dirty = true;
            notify();
        }
    }

    bool build_blit_pipeline() {
        blit_pipe.reset();
        if (!picture) return true;
        blit_srb_nearest.reset(rhi->newShaderResourceBindings());
        blit_srb_nearest->setBindings({
            QRhiShaderResourceBinding::uniformBuffer(0, QRhiShaderResourceBinding::VertexStage | QRhiShaderResourceBinding::FragmentStage,
                                                     blit_ubo.get()),
            QRhiShaderResourceBinding::sampledTexture(1, QRhiShaderResourceBinding::FragmentStage, picture.get(), nearest.get()),
        });
        blit_srb_trilinear.reset(rhi->newShaderResourceBindings());
        blit_srb_trilinear->setBindings({
            QRhiShaderResourceBinding::uniformBuffer(0, QRhiShaderResourceBinding::VertexStage | QRhiShaderResourceBinding::FragmentStage,
                                                     blit_ubo.get()),
            QRhiShaderResourceBinding::sampledTexture(1, QRhiShaderResourceBinding::FragmentStage, picture.get(), trilinear.get()),
        });
        if (!blit_srb_nearest->create() || !blit_srb_trilinear->create()) return false;
        blit_pipe.reset(rhi->newGraphicsPipeline());
        blit_pipe->setTopology(QRhiGraphicsPipeline::TriangleStrip);
        blit_pipe->setShaderStages({{QRhiShaderStage::Vertex, blit_vert}, {QRhiShaderStage::Fragment, blit_frag}});
        blit_pipe->setVertexInputLayout({});
        blit_pipe->setShaderResourceBindings(blit_srb_nearest.get());
        blit_pipe->setRenderPassDescriptor(sc_rp.get());
        return blit_pipe->create();
    }

    void release_hold() {
        raw_pipe.reset();
        raw_rt.reset();
        raw_rp.reset();
        raw_t.reset();
        for (int k = 0; k < 2; ++k) {
            hold_pipe[k].reset();
            hold_srb[k].reset();
            hold_rt[k].reset();
            hold_rp[k].reset();
            state_t[k].reset();
        }
        hold_last = -1;
        hold_pending = true;
    }

    // The hold's targets at the frame's size, made on first use: three
    // RGBA32F frames the viewer does not pay for until something plays held.
    bool ensure_hold() {
        if (hold_failed) return false;
        if (hold_pipe[0] && hold_pipe[1] && raw_pipe) return true;
        release_hold();
        auto fail = [&] {
            release_hold();
            hold_failed = true;   // until the next frame size or device
            return false;
        };
        const QRhiTexture::Flags rt_flags = QRhiTexture::RenderTarget;
        raw_t.reset(rhi->newTexture(QRhiTexture::RGBA32F, frame_size, 1, rt_flags));
        if (!raw_t->create()) return fail();
        for (auto& t : state_t) {
            t.reset(rhi->newTexture(QRhiTexture::RGBA32F, frame_size, 1, rt_flags));
            if (!t->create()) return fail();
        }
        raw_rt.reset(rhi->newTextureRenderTarget({QRhiColorAttachment(raw_t.get())}));
        raw_rp.reset(raw_rt->newCompatibleRenderPassDescriptor());
        raw_rt->setRenderPassDescriptor(raw_rp.get());
        if (!raw_rt->create()) return fail();
        raw_pipe.reset(rhi->newGraphicsPipeline());
        raw_pipe->setShaderStages({{QRhiShaderStage::Vertex, vert}, {QRhiShaderStage::Fragment, composite_frag}});
        raw_pipe->setVertexInputLayout({});
        raw_pipe->setShaderResourceBindings(composite_srb.get());
        raw_pipe->setRenderPassDescriptor(raw_rp.get());
        if (!raw_pipe->create()) return fail();
        for (int k = 0; k < 2; ++k) {
            QRhiTextureRenderTargetDescription desc;
            desc.setColorAttachments({QRhiColorAttachment(model_t.get()), QRhiColorAttachment(state_t[k].get())});
            hold_rt[k].reset(rhi->newTextureRenderTarget(desc));
            hold_rp[k].reset(hold_rt[k]->newCompatibleRenderPassDescriptor());
            hold_rt[k]->setRenderPassDescriptor(hold_rp[k].get());
            if (!hold_rt[k]->create()) return fail();
            hold_srb[k].reset(rhi->newShaderResourceBindings());
            hold_srb[k]->setBindings({
                QRhiShaderResourceBinding::uniformBuffer(0, QRhiShaderResourceBinding::FragmentStage, hold_ubo.get()),
                QRhiShaderResourceBinding::sampledTexture(1, QRhiShaderResourceBinding::FragmentStage, raw_t.get(), fetch.get()),
                QRhiShaderResourceBinding::sampledTexture(2, QRhiShaderResourceBinding::FragmentStage, in_a.get(), fetch.get()),
                QRhiShaderResourceBinding::sampledTexture(3, QRhiShaderResourceBinding::FragmentStage, state_t[1 - k].get(),
                                                          fetch.get()),
            });
            if (!hold_srb[k]->create()) return fail();
            hold_pipe[k].reset(rhi->newGraphicsPipeline());
            hold_pipe[k]->setShaderStages({{QRhiShaderStage::Vertex, vert}, {QRhiShaderStage::Fragment, hold_frag}});
            hold_pipe[k]->setVertexInputLayout({});
            hold_pipe[k]->setTargetBlends({QRhiGraphicsPipeline::TargetBlend(), QRhiGraphicsPipeline::TargetBlend()});
            hold_pipe[k]->setShaderResourceBindings(hold_srb[k].get());
            hold_pipe[k]->setRenderPassDescriptor(hold_rp[k].get());
            if (!hold_pipe[k]->create()) return fail();
        }
        return true;
    }

    bool build_frame_resources(QSize size) {
        release_hold();
        hold_failed = !hold_frag.isValid();
        composite_pipe.reset();
        display_pipe.reset();
        blit_pipe.reset();
        composite_srb.reset();
        display_srb.reset();
        model_rt.reset();
        picture_rt.reset();
        model_rp.reset();
        picture_rp.reset();
        in_a.reset(rhi->newTexture(QRhiTexture::RGBA32F, size));
        in_b.reset(rhi->newTexture(QRhiTexture::RGBA32F, size));
        mask_t.reset(rhi->newTexture(QRhiTexture::RGBA8, size));
        light_t.reset(rhi->newTexture(QRhiTexture::RGBA32F, size));
        region_t.reset(rhi->newTexture(QRhiTexture::RGBA8, size));
        region_dirty = true;
        light_dirty = true;
        light_bound = false;
        uploaded_masks.reset();
        masks_dirty = true;
        base_t.reset(rhi->newTexture(QRhiTexture::RGBA32F, size));
        model_t.reset(rhi->newTexture(QRhiTexture::RGBA32F, size, 1, QRhiTexture::RenderTarget));   // uploads too (set_composited)
        picture.reset(rhi->newTexture(QRhiTexture::RGBA16F, size, 1,
                                      QRhiTexture::RenderTarget | QRhiTexture::MipMapped |
                                          QRhiTexture::UsedWithGenerateMips));
        if (!in_a->create() || !in_b->create() || !mask_t->create() || !base_t->create() || !model_t->create() ||
            !light_t->create() || !region_t->create() || !picture->create())
            return false;
        model_rt.reset(rhi->newTextureRenderTarget({QRhiColorAttachment(model_t.get())}));
        model_rp.reset(model_rt->newCompatibleRenderPassDescriptor());
        model_rt->setRenderPassDescriptor(model_rp.get());
        picture_rt.reset(rhi->newTextureRenderTarget({QRhiColorAttachment(picture.get())}));
        picture_rp.reset(picture_rt->newCompatibleRenderPassDescriptor());
        picture_rt->setRenderPassDescriptor(picture_rp.get());
        if (!model_rt->create() || !picture_rt->create()) return false;

        composite_srb.reset(rhi->newShaderResourceBindings());
        composite_srb->setBindings({
            QRhiShaderResourceBinding::uniformBuffer(0, QRhiShaderResourceBinding::FragmentStage, composite_ubo.get()),
            QRhiShaderResourceBinding::sampledTexture(1, QRhiShaderResourceBinding::FragmentStage, in_a.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(2, QRhiShaderResourceBinding::FragmentStage, in_b.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(3, QRhiShaderResourceBinding::FragmentStage, mask_t.get(), linear.get()),
        });
        display_srb.reset(rhi->newShaderResourceBindings());
        display_srb->setBindings({
            QRhiShaderResourceBinding::uniformBuffer(0, QRhiShaderResourceBinding::FragmentStage, view_ubo.get()),
            QRhiShaderResourceBinding::sampledTexture(1, QRhiShaderResourceBinding::FragmentStage, model_t.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(2, QRhiShaderResourceBinding::FragmentStage, base_t.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(3, QRhiShaderResourceBinding::FragmentStage, mask_t.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(4, QRhiShaderResourceBinding::FragmentStage, light_t.get(), fetch.get()),
            QRhiShaderResourceBinding::sampledTexture(5, QRhiShaderResourceBinding::FragmentStage, region_t.get(), fetch.get()),
        });
        if (!composite_srb->create() || !display_srb->create()) return false;
        auto pipeline = [&](const QShader& frag, QRhiShaderResourceBindings* srb, QRhiRenderPassDescriptor* rp) {
            std::unique_ptr<QRhiGraphicsPipeline> p(rhi->newGraphicsPipeline());
            p->setShaderStages({{QRhiShaderStage::Vertex, vert}, {QRhiShaderStage::Fragment, frag}});
            p->setVertexInputLayout({});
            p->setShaderResourceBindings(srb);
            p->setRenderPassDescriptor(rp);
            return p->create() ? std::move(p) : nullptr;
        };
        composite_pipe = pipeline(composite_frag, composite_srb.get(), model_rp.get());
        display_pipe = pipeline(display_frag, display_srb.get(), picture_rp.get());
        if (!composite_pipe || !display_pipe) return false;
        frame_size = size;
        return build_blit_pipeline();
    }

    void resize_swapchain() {
        has_swapchain = sc->createOrResize();
        if (has_swapchain) update_target();
    }

    void release_swapchain() {
        if (has_swapchain) {
            has_swapchain = false;
            sc->destroy();
        }
    }

    // White as a graphic (the SDR white) in the swapchain's encoding.
    float graphic_white() const {
        if (view.target.path == OutputPath::SdrPqSimulation) return 1.0f;
        const float nits = float(kDiffuseWhite.v);
        return view.target.path == OutputPath::Hdr10 ? pq_oetf(nits) : nits / float(view.target.unit_nits);
    }

    // The surround as the swapchain wants it: a graphic at the SDR white.
    QColor surround() const {
        if (view.target.path == OutputPath::SdrPqSimulation) return QColor::fromRgbF(kSurroundCode, kSurroundCode, kSurroundCode);
        const float nits = float(kDiffuseWhite.v) * code_to_linear(kSurroundCode);
        const float v = view.target.path == OutputPath::Hdr10 ? pq_oetf(nits) : nits / float(view.target.unit_nits);
        return QColor::fromRgbF(v, v, v);
    }

    void render() {
        if (!has_swapchain) return;
        if (sc->currentPixelSize() != sc->surfacePixelSize()) resize_swapchain();
        if (!has_swapchain) return;
        ++updates;
        QRhi::FrameOpResult r = rhi->beginFrame(sc.get());
        if (r == QRhi::FrameOpSwapChainOutOfDate) {
            resize_swapchain();
            if (!has_swapchain) return;
            r = rhi->beginFrame(sc.get());
        }
        last_begin = int(r);
        if (r != QRhi::FrameOpSuccess) ++begin_failures;
        if (r == QRhi::FrameOpDeviceLost) {
            recover_device();
            return;
        }
        if (r != QRhi::FrameOpSuccess) {
            w->requestUpdate();
            return;
        }
        QRhiCommandBuffer* cb = sc->currentFrameCommandBuffer();
        QRhiResourceUpdateBatch* u = rhi->nextResourceUpdateBatch();

        if (has_frame && upload_dirty) {
            const QSize size(baseline.width(), baseline.height());
            if (size != frame_size && !build_frame_resources(size)) {
                has_frame = false;
            } else {
                auto upload = [&](QRhiTexture* t, const std::vector<float>& v) {
                    u->uploadTexture(t, QRhiTextureUploadDescription(QRhiTextureUploadEntry(
                        0, 0, QRhiTextureSubresourceUploadDescription(v.data(), quint32(v.size() * sizeof(float))))));
                };
                upload(base_t.get(), precomposited ? detail::baseline_rgba(baseline.buffer(), pre_codes)
                                                   : detail::baseline_rgba(baseline.buffer(), &frame.sdr));
                if (precomposited) {
                    upload(model_t.get(), detail::rgba_of(precomposite.buffer()));
                    composite_dirty = false;
                } else {
                    std::vector<float> a, b;
                    detail::interleave_inputs(frame.sdr, frame.fields, a, b);
                    upload(in_a.get(), a);
                    upload(in_b.get(), b);
                    composite_dirty = true;
                }
                view_dirty = true;
                light_dirty = true;
                region_dirty = true;   // a new frame: its own region weights
            }
            upload_dirty = false;
        }

        const QSize px = sc->currentPixelSize();
        if (has_frame && frame_size.isValid()) {
            if (masks_dirty) {
                // The painted masks (3.3): one RGBA8 texture at the frame's size,
                // read by both passes; uploaded on a stroke, not per frame.
                const std::vector<std::uint8_t> bytes = detail::masks_rgba8(composite, frame_size.width(), frame_size.height());
                u->uploadTexture(mask_t.get(), QRhiTextureUploadDescription(QRhiTextureUploadEntry(
                    0, 0, QRhiTextureSubresourceUploadDescription(bytes.data(), quint32(bytes.size())))));
                uploaded_masks = composite.masks;
                masks_dirty = false;
                composite_dirty = true;
                view_dirty = true;
            }
            if (composite_dirty && !precomposited) {
                // Playing held (ViewerHold): the composite into raw_t, then the
                // hold pass into model_t. A new frame picks its state textures
                // once; drawing the same frame again (a slider moved) reads the
                // same state, so it re-renders the frame and does not step the hold.
                const bool holding = frame.hold.on && ensure_hold();
                if (!holding) hold_last = -1;
                if (holding && hold_pending) {
                    hold_write = hold_last < 0 ? 0 : 1 - hold_last;
                    hold_read = hold_last >= 0 && !frame.hold.reset;
                    hold_last = hold_write;
                    hold_pending = false;
                }
                const detail::CompositeUbo cu = detail::composite_ubo(frame.scalars, frame.model, composite,
                                                                     frame_size.width(), frame_size.height());
                u->updateDynamicBuffer(composite_ubo.get(), 0, sizeof(cu), &cu);
                cb->beginPass(holding ? raw_rt.get() : model_rt.get(), Qt::black, {1.0f, 0}, u);
                u = nullptr;
                cb->setGraphicsPipeline(holding ? raw_pipe.get() : composite_pipe.get());
                cb->setViewport({0, 0, float(frame_size.width()), float(frame_size.height())});
                cb->setShaderResources(composite_srb.get());
                cb->draw(3);
                cb->endPass();
                if (holding) {
                    QRhiResourceUpdateBatch* hu = rhi->nextResourceUpdateBatch();
                    const detail::HoldUbo hb = detail::hold_ubo(frame.hold.strength, !hold_read);
                    hu->updateDynamicBuffer(hold_ubo.get(), 0, sizeof(hb), &hb);
                    cb->beginPass(hold_rt[hold_write].get(), Qt::black, {1.0f, 0}, hu);
                    cb->setGraphicsPipeline(hold_pipe[hold_write].get());
                    cb->setViewport({0, 0, float(frame_size.width()), float(frame_size.height())});
                    cb->setShaderResources(hold_srb[hold_write].get());
                    cb->draw(3);
                    cb->endPass();
                }
                composite_dirty = false;
                view_dirty = true;
            }
            if (view_dirty) {
                if (!u) u = rhi->nextResourceUpdateBatch();
                const ViewParams ev = effective_view();
                const bool needs_light = view_needs_sdr_light(ev);
                if (needs_light && (light_dirty || ev.anchor_knots != light_knots)) {
                    // Revision 6: made on the host by core's own function, so the
                    // pass reads what render_view reads; only when a view needs it.
                    const SdrImage* s = precomposited ? (pre_sdr ? &*pre_sdr : nullptr) : &frame.sdr;
                    light_bound = s && s->width() == frame_size.width() && s->height() == frame_size.height();
                    if (light_bound) {
                        const std::vector<float> l = sdr_light_rgba(s, ev.anchor_knots);
                        u->uploadTexture(light_t.get(), QRhiTextureUploadDescription(QRhiTextureUploadEntry(
                            0, 0, QRhiTextureSubresourceUploadDescription(l.data(), quint32(l.size() * sizeof(float))))));
                    }
                    light_knots = ev.anchor_knots;
                    light_dirty = false;
                }
                if (ev.region_overlay && ev.overlay_region.enabled &&
                    (region_dirty || !(ev.overlay_region == uploaded_region) || !(ev.overlay_gate == uploaded_gate))) {
                    // RUDRA 1.1: the region's weights, made on the host by core (render_view reads the same bytes).
                    const SdrImage* s = precomposited ? (pre_sdr ? &*pre_sdr : nullptr) : &frame.sdr;
                    const std::vector<std::uint8_t> rb =
                        region_overlay_rgba8(s, ev.overlay_region, frame_size.width(), frame_size.height(), ev.overlay_gate);
                    u->uploadTexture(region_t.get(), QRhiTextureUploadDescription(QRhiTextureUploadEntry(
                        0, 0, QRhiTextureSubresourceUploadDescription(rb.data(), quint32(rb.size())))));
                    uploaded_region = ev.overlay_region;
                    uploaded_gate = ev.overlay_gate;
                    region_dirty = false;
                }
                const detail::ViewUbo vu = detail::view_ubo(ev, frame_size.width(), needs_light && light_bound);
                u->updateDynamicBuffer(view_ubo.get(), 0, sizeof(vu), &vu);
                cb->beginPass(picture_rt.get(), Qt::black, {1.0f, 0}, u);
                u = nullptr;
                cb->setGraphicsPipeline(display_pipe.get());
                cb->setViewport({0, 0, float(frame_size.width()), float(frame_size.height())});
                cb->setShaderResources(display_srb.get());
                cb->draw(3);
                QRhiResourceUpdateBatch* mips = rhi->nextResourceUpdateBatch();
                mips->generateMips(picture.get());
                cb->endPass(mips);
                view_dirty = false;
            }
        }

        if (!u) u = rhi->nextResourceUpdateBatch();
        const double dpr = w->devicePixelRatio();
        const PlacedRect rect = placed();
        BlitUbo bu{};
        const QMatrix4x4 corr = rhi->clipSpaceCorrMatrix();
        std::memcpy(bu.clip_corr, corr.constData(), sizeof(bu.clip_corr));
        bu.rect[0] = float(rect.left * dpr);
        bu.rect[1] = float(rect.top * dpr);
        bu.rect[2] = float((rect.left + rect.width) * dpr);
        bu.rect[3] = float((rect.top + rect.height) * dpr);
        bu.window[0] = float(px.width());
        bu.window[1] = float(px.height());
        bu.window[2] = rhi->isYUpInFramebuffer() ? 1.0f : 0.0f;
        bu.window[3] = graphic_white();
        bu.guides[0] = guides.action_safe ? 1.0f : 0.0f;
        bu.guides[1] = guides.title_safe ? 1.0f : 0.0f;
        bu.guides[2] = guides.centre ? 1.0f : 0.0f;
        bu.guides[3] = float(guides.aspect);
        u->updateDynamicBuffer(blit_ubo.get(), 0, sizeof(bu), &bu);

        cb->beginPass(sc->currentFrameRenderTarget(), surround(), {1.0f, 0}, u);
        if (has_frame && blit_pipe) {
            cb->setGraphicsPipeline(blit_pipe.get());
            cb->setViewport({0, 0, float(px.width()), float(px.height())});
            // Pixels stay pixels from 1:1 up; below it, trilinear over the mips.
            cb->setShaderResources(rect.scale * dpr >= 1.0 - 1e-9 ? blit_srb_nearest.get() : blit_srb_trilinear.get());
            cb->draw(4);
        }
        QRhiResourceUpdateBatch* after = nullptr;
        if (grab_cb && !grab_pending) {
            grab_pending = true;
            grab_rb = {};
            grab_y_up = rhi->isYUpInFramebuffer();
            grab_rb.completed = [this] { finish_grab(); };
            after = rhi->nextResourceUpdateBatch();
            after->readBackTexture(QRhiReadbackDescription(), &grab_rb);
        }
        cb->endPass(after);
        rhi->endFrame(sc.get());
        ++frames;
        // With frames in flight (D3D12, Vulkan, Metal) a readback completes
        // only when its frame slot comes round again, so a grab would report
        // an older frame, or never. Wait for it here: grabs are for tests and
        // Gate B, never the interactive path. On D3D12 even that is not
        // enough: the result is handed over at a later beginFrame (Gate B,
        // 24 Sep: every window check waited two frames that nothing asked
        // for), so while a readback is out the viewer keeps drawing.
        if (grab_pending) rhi->finish();
        if (grab_pending) w->requestUpdate();
    }

    void finish_grab() {
        grab_pending = false;
        auto cb = std::move(grab_cb);
        grab_cb = nullptr;
        if (!cb) return;
        Grab g;
        g.width = grab_rb.pixelSize.width();
        g.height = grab_rb.pixelSize.height();
        switch (grab_rb.format) {
            case QRhiTexture::RGBA16F: g.format = "RGBA16F"; g.bytes_per_pixel = 8; break;
            case QRhiTexture::RGB10A2: g.format = "RGB10A2"; break;
            case QRhiTexture::BGRA8: g.format = "BGRA8"; break;
            default: g.format = "RGBA8"; break;
        }
        const int row = g.height > 0 ? int(grab_rb.data.size()) / g.height : 0;
        g.bytes.resize(std::size_t(g.width) * std::size_t(g.height) * std::size_t(g.bytes_per_pixel));
        const bool y_up = grab_y_up;
        for (int y = 0; y < g.height; ++y) {
            const int src = y_up ? g.height - 1 - y : y;
            std::memcpy(g.bytes.data() + std::size_t(y) * std::size_t(g.width) * std::size_t(g.bytes_per_pixel),
                        grab_rb.data.constData() + std::size_t(src) * std::size_t(row),
                        std::size_t(g.width) * std::size_t(g.bytes_per_pixel));
        }
        cb(g);
    }

    void recover_device() {
        // Everything GPU-side goes; the host copies stay, and the next frame
        // rebuilds from them.
        release_all();
        initialized = false;
        if (init()) {
            initialized = true;
            resize_swapchain();
            if (has_frame) upload_dirty = true;
            frame_size = {};
            view_dirty = true;
        }
        w->requestUpdate();
    }

    void release_all() {
        // A readback still in flight completes while the QRhi is torn down:
        // it must not call back into a half-destroyed viewer.
        grab_rb.completed = nullptr;
        grab_cb = nullptr;
        grab_pending = false;
        blit_pipe.reset();
        release_hold();
        hold_ubo.reset();
        composite_pipe.reset();
        display_pipe.reset();
        blit_srb_nearest.reset();
        blit_srb_trilinear.reset();
        composite_srb.reset();
        display_srb.reset();
        model_rt.reset();
        picture_rt.reset();
        model_rp.reset();
        picture_rp.reset();
        in_a.reset();
        in_b.reset();
        mask_t.reset();
        light_t.reset();
        region_t.reset();
        base_t.reset();
        model_t.reset();
        picture.reset();
        composite_ubo.reset();
        view_ubo.reset();
        blit_ubo.reset();
        nearest.reset();
        trilinear.reset();
        fetch.reset();
        linear.reset();
        release_swapchain();
        sc_rp.reset();
        sc.reset();
        rhi.reset();
        frame_size = {};
    }

    void notify() {
        if (status_cb) status_cb(status());
    }

    ViewerStatus status() const {
        ViewerStatus s;
        s.backend = rhi ? rhi->backendName() : "";
        const bool display_referred =
            sc && has_swapchain && sc->hdrInfo().luminanceBehavior == QRhiSwapChainHdrInfo::DisplayReferred;
        s.swapchain = swapchain_name(format, display_referred);
        s.target = view.target;
        // In device pixels: 100 % is one frame pixel per screen pixel.
        s.zoom_percent = int(std::floor(displayed_scale(viewport, viewer_size(), frame_view_size()) *
                                        w->devicePixelRatio() * 100.0 + 0.5));
        s.peak_from = peak_from;
        s.device_pixel_ratio = w->devicePixelRatio();
        s.has_frame = has_frame;
        s.wiping = view.wipe >= 0.0;
        s.updates = updates;
        s.frames = frames;
        s.begin_failures = begin_failures;
        s.last_begin = last_begin;
        s.grab_waiting = bool(grab_cb);
        s.grab_pending = grab_pending;
        return s;
    }

    void changed_view() {
        view_dirty = true;
        w->requestUpdate();
    }
    void moved() {
        notify();
        w->requestUpdate();
    }
};

ViewerWindow::ViewerWindow(GpuApi api, bool prefer_hdr) : d_(std::make_unique<Impl>()) {
    d_->w = this;
    d_->api = resolve(api);
    d_->prefer_hdr = prefer_hdr;
#if RUDRA_QT_VULKAN
    if (d_->api == GpuApi::Vulkan) {
        d_->vk = std::make_unique<QVulkanInstance>();
        d_->vk->setExtensions(QRhiVulkanInitParams::preferredInstanceExtensions());
        d_->vk->setApiVersion(d_->vk->supportedApiVersion());   // 0 is refused by the validation layer
        if (d_->vk->create()) setVulkanInstance(d_->vk.get());
        else d_->api = GpuApi::OpenGL;   // no Vulkan here: the fallback
    }
#else
    if (d_->api == GpuApi::Vulkan) d_->api = GpuApi::OpenGL;
#endif
    setSurfaceType(surface_for(d_->api));
#ifdef __APPLE__
    if (d_->api == GpuApi::OpenGL) setFormat(rhi_gl_format());
#endif
}

ViewerWindow::~ViewerWindow() {
    d_->release_all();
    // The platform window's Vulkan surface is destroyed with the window; the
    // instance it was made from is ours and goes with d_, so the surface goes
    // first. Without this ~QWindow destroys it against a freed instance.
    destroy();
}

void ViewerWindow::set_frame(ViewerFrame frame) {
    d_->baseline = corrected_baseline(frame.sdr, frame.model.corpus_ev, baseline_curve_params(frame.scalars, d_->composite, frame.model.corpus_ev));
    // The static hold: a frame shown unheld drops the state; a new held frame
    // steps it when it is composited; the same one again does not.
    if (!frame.hold.on) {
        d_->hold_last = -1;
        d_->hold_frame = -1;
        d_->hold_pending = true;
    } else if (frame.hold.frame != d_->hold_frame || frame.hold.frame < 0) {
        d_->hold_frame = frame.hold.frame;
        d_->hold_pending = true;
    }
    d_->frame = std::move(frame);
    d_->precomposited = false;
    d_->has_frame = true;
    d_->upload_dirty = true;
    d_->moved();
}

void ViewerWindow::set_composited(NetworkLinearImage model, NetworkLinearImage baseline) {
    set_composited(std::move(model), std::move(baseline), {});
}

void ViewerWindow::set_composited(NetworkLinearImage model, NetworkLinearImage baseline, std::vector<float> sdr_max_codes) {
    d_->pre_codes = std::move(sdr_max_codes);
    d_->pre_sdr.reset();   // set_source_sdr after this gives it again
    d_->hold_last = -1;   // a card or a master: nothing held across it
    d_->hold_frame = -1;
    d_->hold_pending = true;
    d_->precomposite = std::move(model);
    d_->baseline = std::move(baseline);
    d_->precomposited = true;
    d_->has_frame = true;
    d_->upload_dirty = true;
    d_->moved();
}

void ViewerWindow::set_source_sdr(SdrImage sdr) {
    d_->pre_sdr = std::move(sdr);
    d_->light_dirty = true;
    d_->region_dirty = true;
    d_->changed_view();
}

void ViewerWindow::clear_frame() {
    d_->has_frame = false;
    d_->moved();
}

void ViewerWindow::set_composite(const CompositeParams& params) {
    // The source curve (3.1) is part of the baseline, so the baseline texture
    // the Baseline view and the Changes tint read follows it; the composite
    // shader recomputes its own from the uniforms either way.
    const bool rebase = (params.source != d_->composite.source || params.calibration != d_->composite.calibration ||
                         params.reference != d_->composite.reference) &&
                        d_->has_frame && !d_->precomposited;
    if (params.masks != d_->composite.masks && !(params.masks && d_->composite.masks && *params.masks == *d_->composite.masks))
        d_->masks_dirty = true;
    d_->composite = params;
    if (rebase) {
        d_->baseline = corrected_baseline(d_->frame.sdr, d_->frame.model.corpus_ev,
                                          baseline_curve_params(d_->frame.scalars, params, d_->frame.model.corpus_ev));
        d_->upload_dirty = true;
    }
    d_->composite_dirty = true;
    requestUpdate();
}

void ViewerWindow::set_view(const ViewParams& params) {
    const DisplayTarget target = d_->view.target;
    d_->view = params;
    d_->view.target = target;
    d_->changed_view();
    d_->notify();
}

ViewParams ViewerWindow::view() const { return d_->view; }
const ViewportState& ViewerWindow::viewport() const { return d_->viewport; }

void ViewerWindow::set_viewport(const ViewportState& v) {
    d_->viewport = v;
    d_->moved();
}

void ViewerWindow::set_guides(const GuideOptions& g) {
    d_->guides = g;
    requestUpdate();
}

GuideOptions ViewerWindow::guides() const { return d_->guides; }

void ViewerWindow::zoom_fit() {
    rudra::zoom_fit(d_->viewport);
    d_->moved();
}

void ViewerWindow::zoom_actual() {
    // Actual pixels are the screen's: one frame pixel per device pixel, so a
    // 150 % display scale does not turn 1:1 into 1.5:1.
    d_->viewport = {1.0 / devicePixelRatio(), 0.0, 0.0};
    d_->moved();
}

ViewerStatus ViewerWindow::status() const { return d_->status(); }
void ViewerWindow::on_status(std::function<void(const ViewerStatus&)> cb) { d_->status_cb = std::move(cb); }

void ViewerWindow::set_input_enabled(bool on) {
    d_->input = on;
    if (!on) d_->wipe_dragging = d_->panning = d_->flip_held_key = d_->flip_held_mouse = false;
}

void ViewerWindow::grab(std::function<void(const Grab&)> done) {
    d_->grab_cb = std::move(done);
    requestUpdate();
}

void ViewerWindow::exposeEvent(QExposeEvent*) {
    if (isExposed() && !d_->initialized) {
        if (!d_->init()) return;
        d_->initialized = true;
        d_->resize_swapchain();
    }
    if (d_->initialized && isExposed() && !size().isEmpty()) d_->render();
}

bool ViewerWindow::event(QEvent* e) {
    switch (e->type()) {
        case QEvent::UpdateRequest:
            if (d_->initialized && isExposed()) d_->render();
            break;
        case QEvent::PlatformSurface:
            if (static_cast<QPlatformSurfaceEvent*>(e)->surfaceEventType() ==
                QPlatformSurfaceEvent::SurfaceAboutToBeDestroyed)
                d_->release_swapchain();
            break;
        case QEvent::Leave:
            if (d_->hover_cb) d_->hover_cb(Hover{});
            break;
        case QEvent::DragEnter:
        case QEvent::DragMove: {
            auto* de = static_cast<QDragMoveEvent*>(e);
            if (d_->drop_cb && de->mimeData()->hasUrls()) {
                de->acceptProposedAction();
                return true;
            }
            break;
        }
        case QEvent::Drop: {
            auto* de = static_cast<QDropEvent*>(e);
            if (!d_->drop_cb) break;
            QStringList paths;
            for (const auto& u : de->mimeData()->urls())
                if (u.isLocalFile()) paths << u.toLocalFile();
            de->acceptProposedAction();
            if (!paths.isEmpty()) d_->drop_cb(paths);
            return true;
        }
        case QEvent::Resize:
            // Fit follows the window; a zoom keeps its scale and pan.
            d_->notify();
            requestUpdate();
            break;
        default: break;
    }
    return QWindow::event(e);
}

void ViewerWindow::wheelEvent(QWheelEvent* e) {
    if (!d_->input) return;
    if (!d_->has_frame) return;
    const double notches = e->angleDelta().y() / 120.0;
    if (notches == 0.0) return;
    if (d_->paint_mode) {
        if (d_->brush_cb) d_->brush_cb(notches);
        return;
    }
    // One wheel notch is the Studio's step; a trackpad's fractions scale it.
    zoom_about(d_->viewport, d_->viewer_size(), d_->frame_view_size(), e->position().x(), e->position().y(),
               std::pow(kWheelStep, notches));
    d_->moved();
}

void ViewerWindow::mousePressEvent(QMouseEvent* e) {
    if (!d_->input) return;
    if (e->button() == Qt::MiddleButton && d_->has_frame) {
        d_->panning = true;
        d_->pan_from = e->position();
        if (!d_->viewport.scale) pan_by(d_->viewport, d_->viewer_size(), d_->frame_view_size(), 0, 0);
        d_->pan_x0 = d_->viewport.pan_x;
        d_->pan_y0 = d_->viewport.pan_y;
        return;
    }
    if (e->button() != Qt::LeftButton || !d_->has_frame) return;
    if (d_->paint_mode) {
        if (const auto px = d_->frame_pixel(e->position())) {
            d_->painting = true;
            d_->paint_x = px->first;
            d_->paint_y = px->second;
            if (d_->paint_cb) d_->paint_cb(px->first, px->second, px->first, px->second, e->modifiers() & Qt::AltModifier);
        }
        return;
    }
    if (d_->pick_mode) {
        if (const auto px = d_->frame_pixel(e->position())) {
            d_->pick_mode = false;
            setCursor(Qt::ArrowCursor);
            if (d_->pick_cb) d_->pick_cb(px->first, px->second);
        }
        return;
    }
    // While the wipe is up, left drag moves the seam; otherwise holding shows
    // the baseline. One gesture, one meaning (ui/app.js).
    if (d_->view.wipe >= 0.0) {
        d_->wipe_dragging = true;
        d_->view.wipe = wipe_at(d_->placed(), e->position().x());
        d_->changed_view();
        d_->notify();   // the session keeps the seam, so a peak or exposure change does not reset it
        return;
    }
    d_->flip_held_mouse = true;
    d_->changed_view();
}

void ViewerWindow::on_hover(std::function<void(const Hover&)> cb) { d_->hover_cb = std::move(cb); }

void ViewerWindow::set_pick_mode(bool on) {
    d_->pick_mode = on;
    setCursor(on ? Qt::CrossCursor : Qt::ArrowCursor);
}

bool ViewerWindow::pick_mode() const { return d_->pick_mode; }

void ViewerWindow::set_paint_mode(bool on) {
    d_->paint_mode = on;
    if (!on) d_->painting = false;
    setCursor(on ? Qt::CrossCursor : (d_->pick_mode ? Qt::CrossCursor : Qt::ArrowCursor));
}

bool ViewerWindow::paint_mode() const { return d_->paint_mode; }

void ViewerWindow::on_paint(std::function<void(double, double, double, double, bool)> cb) { d_->paint_cb = std::move(cb); }
void ViewerWindow::on_paint_end(std::function<void()> cb) { d_->paint_end_cb = std::move(cb); }
void ViewerWindow::on_brush_wheel(std::function<void(double)> cb) { d_->brush_cb = std::move(cb); }

void ViewerWindow::on_pick(std::function<void(double, double)> cb) { d_->pick_cb = std::move(cb); }

void ViewerWindow::on_drop(std::function<void(const QStringList&)> cb) { d_->drop_cb = std::move(cb); }

void ViewerWindow::mouseMoveEvent(QMouseEvent* e) {
    if (!d_->input) return;
    if (!d_->panning && !d_->wipe_dragging) d_->hover(e->position(), e->modifiers() & Qt::AltModifier);
    if (d_->painting) {
        // Off the picture the stroke clamps to the edge, like a brush dragged past the frame.
        const PlacedRect r = d_->placed();
        const ViewSize f = d_->frame_view_size();
        if (r.width > 0 && r.height > 0) {
            const double x = std::clamp((e->position().x() - r.left) / r.width, 0.0, 1.0) * f.width;
            const double y = std::clamp((e->position().y() - r.top) / r.height, 0.0, 1.0) * f.height;
            if (d_->paint_cb) d_->paint_cb(d_->paint_x, d_->paint_y, x, y, e->modifiers() & Qt::AltModifier);
            d_->paint_x = x;
            d_->paint_y = y;
        }
        return;
    }
    if (d_->panning) {
        d_->viewport.pan_x = d_->pan_x0 + (e->position().x() - d_->pan_from.x());
        d_->viewport.pan_y = d_->pan_y0 + (e->position().y() - d_->pan_from.y());
        d_->moved();
        return;
    }
    if (d_->wipe_dragging) {
        d_->view.wipe = wipe_at(d_->placed(), e->position().x());
        d_->changed_view();
    }
}

void ViewerWindow::mouseReleaseEvent(QMouseEvent* e) {
    if (!d_->input) return;
    if (e->button() == Qt::MiddleButton) d_->panning = false;
    if (e->button() == Qt::LeftButton && d_->painting) {
        d_->painting = false;
        if (d_->paint_end_cb) d_->paint_end_cb();
        return;
    }
    if (e->button() == Qt::LeftButton) {
        if (d_->wipe_dragging) d_->notify();   // where the seam was let go
        d_->wipe_dragging = false;
        if (d_->flip_held_mouse) {
            d_->flip_held_mouse = false;
            d_->changed_view();
        }
    }
}

void ViewerWindow::mouseDoubleClickEvent(QMouseEvent* e) {
    if (!d_->input) return;
    if (e->button() == Qt::LeftButton) zoom_fit();
}

void ViewerWindow::keyPressEvent(QKeyEvent* e) {
    if (!d_->input) return;
    switch (e->key()) {
        case Qt::Key_B:
            if (!e->isAutoRepeat()) {
                d_->flip_held_key = true;
                d_->changed_view();
            }
            return;
        case Qt::Key_W:
            d_->view.wipe = d_->view.wipe >= 0.0 ? -1.0 : 0.5;
            d_->flip_held_key = d_->flip_held_mouse = false;
            d_->changed_view();
            d_->notify();
            return;
        case Qt::Key_Left:
        case Qt::Key_Right:
            if (d_->view.wipe >= 0.0) {
                const double step = (e->modifiers() & Qt::ShiftModifier) ? 0.01 : 0.05;
                d_->view.wipe = std::clamp(d_->view.wipe + (e->key() == Qt::Key_Right ? step : -step), 0.0, 1.0);
                d_->changed_view();
                d_->notify();
                return;
            }
            break;
        case Qt::Key_Escape:
            if (d_->view.wipe >= 0.0) {
                d_->view.wipe = -1.0;
                d_->changed_view();
                d_->notify();
                return;
            }
            break;
        default: break;
    }
    QWindow::keyPressEvent(e);
}

void ViewerWindow::keyReleaseEvent(QKeyEvent* e) {
    if (!d_->input) return;
    if (e->key() == Qt::Key_B && !e->isAutoRepeat()) {
        d_->flip_held_key = false;
        d_->changed_view();
        return;
    }
    QWindow::keyReleaseEvent(e);
}

}  // namespace rudra
