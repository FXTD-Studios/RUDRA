#pragma once
// The viewer (Phase 2 step 9, ADR-010): a QWindow with its own QRhi swapchain,
// embedded in the widget layout with QWidget::createWindowContainer. It owns
// the frame on the GPU and runs the passes every other part of render/ is
// held to: composite.frag into an fp32 target, display.frag into the picture
// (SDR, scRGB, HDR10 or EDR, whatever the swapchain is), and blit into the
// window at the place core/viewport.hpp computes. The controls of the browser
// Studio's plate work the same: wheel zooms about the cursor, middle drag
// pans, double click fits; W toggles the wipe and left drag moves it; B or a
// held left button shows the baseline; arrows nudge the wipe; Esc leaves it.
// Placement is the Studio's, in logical pixels; "actual pixels" and the zoom
// readout are in device pixels, so 1:1 is true 1:1 on a scaled display.
//
// QRhi stays behind the pimpl: this header includes only QtGui.

#include <QWindow>

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "rudra/core/composite.hpp"
#include "rudra/core/fields.hpp"
#include "rudra/core/guides.hpp"
#include "rudra/core/image.hpp"
#include "rudra/core/view.hpp"
#include "rudra/core/viewport.hpp"
#include "rudra/render/gpu_composite.hpp"

namespace rudra {

struct ViewerStatus {
    std::string backend;     // QRhi backend name
    std::string swapchain;   // SDR, scRGB, HDR10, EDR
    DisplayTarget target;
    std::string peak_from;           // swapchain, DXGI (Windows, when Qt only has placeholders), placeholder
    double device_pixel_ratio = 1.0;
    int zoom_percent = 100;          // in device pixels: 100 is one frame pixel per screen pixel
    bool has_frame = false;
    bool wiping = false;
    // Frame accounting, for the check tools: where a stalled run stopped.
    long long updates = 0;           // UpdateRequest and expose events seen
    long long frames = 0;            // frames presented
    long long begin_failures = 0;    // beginFrame results other than success
    int last_begin = 0;              // the last QRhi::FrameOpResult
    bool grab_waiting = false;       // a grab asked for and not yet read back
    bool grab_pending = false;       // its readback is in flight
};

// The static hold while playing (11 Oct 2026; ShadowSmoother::hold_pixels,
// shaders/hold.frag): where the source is still from the frame shown before,
// the HDR's gain over it is held, so a still part of a shot plays as the
// export holds it. engine/PlaybackHold says when (PlaybackHold::pixel_step).
struct ViewerHold {
    bool on = false;          // off: the frame's own composite, and the state is dropped
    double strength = 0.0;    // retention^frames since the previous frame shown
    bool reset = true;        // the shot's first frame: its own, and the state starts again
    long long frame = -1;     // which frame: the same one again re-renders it, it does not step the hold
};

// One frame on the GPU: the SDR the network saw, its fields, and the
// per-frame scalars. The baseline is computed from them once per frame.
struct ViewerFrame {
    SdrImage sdr;
    Fields fields;
    FrameScalars scalars;
    ModelConstants model;
    ViewerHold hold{};
};

class ViewerWindow : public QWindow {
public:
    // Auto: D3D12 on Windows, Metal on macOS, Vulkan then OpenGL elsewhere.
    // prefer_hdr: take an HDR swapchain format when the display offers one.
    explicit ViewerWindow(GpuApi api = GpuApi::Auto, bool prefer_hdr = true);
    ~ViewerWindow() override;

    void set_frame(ViewerFrame frame);
    // A picture that is already composited (a master, a test card): shown
    // through the display pass as it is, with no composite pass.
    void set_composited(NetworkLinearImage model, NetworkLinearImage baseline);
    // The same, with the SDR's largest code per pixel ([0, 1], width x height),
    // so the Invented layer tells invented (clipped or crushed) from reinterpreted
    // pixels on a precomposited picture too (the learned ACES 2.0 route, 28 Oct 2026).
    void set_composited(NetworkLinearImage model, NetworkLinearImage baseline, std::vector<float> sdr_max_codes);
    // Revision 6: the SDR of a precomposited frame (the learned ACES route), for
    // the Sdr source, the clamp zebra and the Range layer. Call after
    // set_composited, which forgets the previous one. set_frame needs none.
    void set_source_sdr(SdrImage sdr);
    void clear_frame();
    void set_composite(const CompositeParams& params);
    // Mode, view peak, source, wipe and difference gain; the target is the
    // swapchain's own and is filled in by the window.
    void set_view(const ViewParams& params);
    ViewParams view() const;
    const ViewportState& viewport() const;
    void set_viewport(const ViewportState& v);
    void zoom_fit();
    void zoom_actual();
    // Safe areas, centre cross, aspect mask: screen space, over the picture.
    void set_guides(const GuideOptions& g);
    GuideOptions guides() const;

    ViewerStatus status() const;
    void on_status(std::function<void(const ViewerStatus&)> cb);

    // The pointer over the picture, in frame pixels (fractional; nullopt off
    // the frame or out of the window), with the window position and whether
    // Alt is held: the probe reads the frame there.
    struct Hover {
        std::optional<double> x, y;
        QPointF window;
        bool alt = false;
    };
    void on_hover(std::function<void(const Hover&)> cb);

    // Picking (roadmap 3.2): while on, a left click on the picture reports the
    // frame pixel under it instead of flipping to the baseline; off again
    // after the click. Clicks off the picture report nothing and leave it on.
    void set_pick_mode(bool on);
    bool pick_mode() const;
    void on_pick(std::function<void(double x, double y)> cb);

    // Painting (roadmap 3.3): while on, a left drag on the picture reports
    // stroke segments in frame pixels (press: a zero-length one), Alt held
    // means erase, the wheel reports brush-size notches instead of zooming,
    // and the release ends the stroke. Stays on until set off.
    void set_paint_mode(bool on);
    bool paint_mode() const;
    void on_paint(std::function<void(double x0, double y0, double x1, double y1, bool erase)> cb);
    void on_paint_end(std::function<void()> cb);
    void on_brush_wheel(std::function<void(double notches)> cb);

    // Files dropped on the picture (the page's window drop); local paths.
    void on_drop(std::function<void(const QStringList&)> cb);

    // Off: mouse, wheel and keys do nothing (the check tools, so a wheel or a
    // click that lands on the window while it runs cannot move the picture).
    void set_input_enabled(bool on);

    // The next presented frame, read back from the swapchain (tests, Gate B).
    // Pixels are top-down RGBA in the swapchain's format: 8-bit sRGB codes
    // for SDR, half floats for scRGB and EDR, 10-bit PQ words for HDR10.
    struct Grab {
        int width = 0, height = 0;
        std::string format;         // RGBA8, BGRA8, RGBA16F, RGB10A2
        std::vector<unsigned char> bytes;
        int bytes_per_pixel = 4;
    };
    void grab(std::function<void(const Grab&)> done);

protected:
    void exposeEvent(QExposeEvent*) override;
    bool event(QEvent* e) override;
    void wheelEvent(QWheelEvent* e) override;
    void mousePressEvent(QMouseEvent* e) override;
    void mouseMoveEvent(QMouseEvent* e) override;
    void mouseReleaseEvent(QMouseEvent* e) override;
    void mouseDoubleClickEvent(QMouseEvent* e) override;
    void keyPressEvent(QKeyEvent* e) override;
    void keyReleaseEvent(QKeyEvent* e) override;

private:
    struct Impl;
    std::unique_ptr<Impl> d_;
};

}  // namespace rudra
