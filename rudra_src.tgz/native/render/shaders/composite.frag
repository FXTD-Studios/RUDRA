#version 440
// The composite on the GPU (docs/composite.spec.md section 2). A line-for-line
// port of native/core/src/composite.cpp, which is the reference it is held to
// (rudra-gpu-parity), and of ui/compositor.js, which it replaces.
//
// Inputs are fetched by pixel, never filtered: texture row r, framebuffer row r
// and readback row r are the same pixel on every API.

layout(location = 0) out vec4 frag;

layout(std140, binding = 0) uniform Composite {
    vec4 model;     // x log_scale, y max_hdr, z baseline scale (2^-ev * 203/10000), w strength
    vec4 control;   // x mode (0 all, 1 highlights, 2 shadows, 3 off), y preserve, z shadow weight, w region softness (stops)
    vec4 counts;    // x curve knots (0: no curve), y region bands, z 1 when painted masks are bound (3.3), w frame width
    vec4 curve[72]; // curve params, packed four to a vec4: [0] exposure, [1..] knots. Up to 287
                    // knots: the CurveHead's 8, or the source curve's one per 8-bit code (3.1)
    vec4 bands[8];  // x log2(low nits), y log2(high nits), z ev, w the band's mask channel (0..3) or -1
    vec4 frame;     // x width, y height of the frame (the masks sample by normalised position), z the exposure gain 2^ev (13 Oct 2026),
                    // w 1 when the anchor's target has knots
    vec4 anchor[64];   // the anchor's target over the sRGB reading, log2, one per 8-bit code (core anchor_target_knots)
    vec4 region[3];    // spec rev 2: the reconstruction region (render/src/passes.hpp); region[0].x 0 = off
};

layout(binding = 1) uniform sampler2D sdrShadow;   // rgb SDR code values, a shadow mask
layout(binding = 3) uniform sampler2D masks;       // painted masks (3.3), RGBA8, a band per channel; sampled bilinear
layout(binding = 2) uniform sampler2D fields;      // rgb log residual (scale folded in), a highlight mask

float curveParam(int i) { return curve[i >> 2][i & 3]; }

float srgbToLinear(float x) {
    x = clamp(x, 0.0, 1.0);
    return x <= 0.04045 ? x / 12.92 : pow((x + 0.055) / 1.055, 2.4);
}

// inverse_aces_approx: the larger root, input clamped just below one.
float inverseAces(float y) {
    y = clamp(y, 0.0, 0.995);
    float qa = y * 2.43 - 2.51;
    float qb = y * 0.59 - 0.03;
    float qc = y * 0.14;
    float disc = max(qb * qb - 4.0 * qa * qc, 0.0);
    float den = min(2.0 * qa, -1e-7);
    float s = sqrt(disc);
    return max(max((-qb - s) / den, (-qb + s) / den), 0.0);
}

float curveLog2(float code) {
    int knots = int(counts.x);
    float pos = clamp(code, 0.0, 1.0) * float(knots - 1);
    int lo = min(int(floor(pos)), knots - 2);
    float frac = pos - float(lo);
    float v0 = curveParam(1 + lo);
    float v1 = curveParam(2 + lo);
    return curveParam(0) + v0 + (v1 - v0) * frac;
}

float baselineOf(float code) {
    float b = inverseAces(srgbToLinear(code)) * model.z;
    return counts.x >= 2.0 ? b * exp2(curveLog2(code)) : b;
}

// The anchor's target light of one code (diffuse white 1.0): the sRGB
// reading, times the Source picker's factor when it has one (13 Oct 2026;
// core/src/composite.cpp anchor_target_log2).
float anchorLight(float code) {
    float l = srgbToLinear(code);
    if (frame.w < 0.5) return l;
    float pos = clamp(code, 0.0, 1.0) * 255.0;
    int lo = min(int(floor(pos)), 254);
    float frac = pos - float(lo);
    float v0 = anchor[lo >> 2][lo & 3];
    float v1 = anchor[(lo + 1) >> 2][(lo + 1) & 3];
    return l * exp2(v0 + (v1 - v0) * frac);
}

// log1p / expm1 without the cancellation of log(1 + x) near zero (Kahan).
float log1pAccurate(float x) {
    float u = 1.0 + x;
    return u == 1.0 ? x : log(u) * (x / (u - 1.0));
}
float expm1Accurate(float x) {
    float u = exp(x);
    if (u == 1.0) return x;
    float um1 = u - 1.0;
    return um1 == -1.0 ? -1.0 : um1 * (x / log(u));
}

float sigmoid(float x) { return 1.0 / (1.0 + exp(-x)); }

// core/src/composite.cpp region_ramp_up / region_ramp_down (spec rev 2).
float rampUp(float y, float at, float soft) {
    if (!(soft > 0.0)) return y >= at ? 1.0 : 0.0;
    float t = clamp((y - (at - 0.5 * soft)) / soft, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}
float rampDown(float y, float at, float soft) {
    if (!(soft > 0.0)) return y <= at ? 1.0 : 0.0;
    float t = clamp(((at + 0.5 * soft) - y) / soft, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

// qualifier_mask and region_ev_gain (rudra/delivery/controls.py), in fp32.
float maskChannel(vec4 m, int c) { return c == 0 ? m.x : c == 1 ? m.y : c == 2 ? m.z : m.w; }

float regionGain(vec3 nits, vec2 uv) {
    float y = max(dot(max(nits, vec3(0.0)), vec3(0.2627, 0.6780, 0.0593)), 1e-6);
    float logY = log2(y);
    float soft = max(control.w, 1e-3);
    float total = 0.0;
    int n = int(counts.y);
    vec4 mv = counts.z > 0.5 ? texture(masks, uv) : vec4(1.0);
    for (int i = 0; i < n; ++i) {
        float rise = clamp((logY - (bands[i].x - soft)) / soft, 0.0, 1.0);
        float fall = clamp(((bands[i].y + soft) - logY) / soft, 0.0, 1.0);
        float m = min(rise, fall);
        float term = bands[i].z * (m * m * (3.0 - 2.0 * m));
        if (bands[i].w >= 0.0) term *= maskChannel(mv, int(bands[i].w + 0.5));   // the painted mask (3.3)
        total += term;
    }
    return exp2(total);
}

// One colour channel of the reconstruction (the body of the former per-channel loop, unchanged).
float channelOf(float sc, float fc, bool outside, float gate, float logScale, float logCeiling, float recovery, bool recover) {
    float base = baselineOf(sc);
    if (outside) return base;
    float pl = clamp(log1pAccurate(base * logScale) + fc * gate, 0.0, logCeiling);
    float v = expm1Accurate(pl) / logScale;
    if (recover) v = base + recovery * (v - base);
    return v;
}

void main() {
    ivec2 p = ivec2(gl_FragCoord.xy);
    vec4 a = texelFetch(sdrShadow, p, 0);
    vec4 f = texelFetch(fields, p, 0);
    vec3 s = clamp(a.rgb, 0.0, 1.0);
    float shadow = a.a;
    float highlight = f.a;

    float logScale = model.x;
    float y = 0.2126 * s.r + 0.7152 * s.g + 0.0722 * s.b;
    float hp = sigmoid((y - 0.82) * 24.0);
    float sp = sigmoid((0.10 - y) * 24.0) * control.z;
    bool regionOn = region[0].x > 0.5;
    if (regionOn) {   // core region_weights
        if (region[0].y > 0.5) {
            float b = rampUp(y, region[2].x, region[2].z) * rampDown(y, region[2].y, region[2].z);
            hp *= b * region[1].x;
            sp *= b * region[1].w;
        } else {
            hp *= rampUp(y, region[0].z, region[0].w) * region[1].x;
            sp *= rampDown(y, region[1].y, region[1].z) * region[1].w;
        }
    }
    int mode = int(control.x);
    float gate = mode == 0 ? max(hp, sp) : mode == 1 ? hp : mode == 2 ? sp : 0.0;
    gate *= model.w;
    float recovery = max(highlight, shadow);
    float logCeiling = log1pAccurate(model.y * logScale);

    // One channel at a time through channelOf, assembled as a vec3: no indexed write into a
    // local array inside a loop. Direct3D's HLSL compiler cannot unroll such a loop when it
    // also exits early ("X3500 array reference cannot be used as an l-value ... X3511
    // unrolling failed"), and the viewer then draws nothing on Windows (6 Nov 2026).
    bool outside = regionOn && gate == 0.0;   // outside the region: the baseline itself
    bool recover = control.y > 0.5;
    vec3 pred = vec3(channelOf(s.r, f.r, outside, gate, logScale, logCeiling, recovery, recover),
                     channelOf(s.g, f.g, outside, gate, logScale, logCeiling, recovery, recover),
                     channelOf(s.b, f.b, outside, gate, logScale, logCeiling, recovery, recover));
    float grade = 1.0;
    if (counts.y > 0.0 || frame.z != 1.0) {
        // The exposure first; the bands read the exposed nits (core/composite.cpp).
        vec3 nits = pred * 10000.0;
        vec2 uv = (vec2(p) + 0.5) / frame.xy;
        grade = (counts.y > 0.0 ? regionGain(nits * frame.z, uv) : 1.0) * frame.z;
        pred = clamp(nits * grade, vec3(0.0), vec3(model.y * 10000.0)) / 10000.0;
    }
    // a: the SDR's Rec.2020 luma of its linearised codes (anchorLight), the anchor's target
    // for the display pass (roadmap 3.3), times the Region EV gain: the master
    // grades after its anchor (9 Oct 2026), so the anchor must not divide the
    // grade back out (core/view.cpp, ViewParams::grade_gain). The CPU
    // composite is rgb only and hands the gain over separately.
    frag = vec4(pred, grade * dot(vec3(anchorLight(s.r), anchorLight(s.g), anchorLight(s.b)), vec3(0.2627, 0.6780, 0.0593)));
}
